CREATE TRIGGER PREINSUPD_ACD
  
 BEFORE INSERT OR UPDATE 
	
  ON R5ACCOUNTDETAIL
  
 FOR EACH ROW 
DECLARE

     v_desc               r5install.ins_desc%TYPE;
     v_accounted          r5accountdetail.acd_accounted%TYPE;
     db_error             EXCEPTION;
     no_value             EXCEPTION;
     chk                  VARCHAR2( 4 );
     errortext            VARCHAR2( 255 );
     caction              VARCHAR2( 10 );



   BEGIN

   IF INSERTING THEN
     caction := 'INSERT';
   ELSIF UPDATING THEN
     caction := 'UPDATE';
   END IF;

     BEGIN
       SELECT ins_desc
       INTO v_desc
       FROM r5install
       WHERE ins_code = 'ACCOUNT';
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
         v_desc := 'NO';
       WHEN OTHERS THEN
         v_desc := NULL;
     END;

     v_accounted := :new.acd_accounted;

     IF v_accounted IS NULL THEN
       v_accounted := '*';
     END IF;

     IF (v_desc = 'NO' AND v_accounted IN ('DR','CR')) THEN
       errortext := SUBSTR('Install parameter is NO for ACCOUNT and acd_accounted cannot be DR or CR',1,255);
       RAISE db_error;
     END IF;

     IF (v_desc = 'YES' AND v_accounted NOT IN ('DR','CR','TP')) THEN
       errortext := SUBSTR('Install parameter is YES for ACCOUNT and acd_accounted should be either DR or CR',1,255);
       RAISE db_error;
     END IF;

     IF (v_desc IS NULL OR v_accounted NOT IN ('*','DR','CR','TP')) THEN
       errortext := SUBSTR('Either there is no value for ACCOUNT in install parameter or there is no value for acd_accounted',1,255);
       RAISE no_value;
     END IF;
   EXCEPTION
     WHEN db_error THEN
       RAISE_APPLICATION_ERROR(-20001, errortext);
     WHEN no_value THEN
       RAISE_APPLICATION_ERROR(-20002, errortext);
     WHEN OTHERS THEN
       RAISE_APPLICATION_ERROR(-20001, SQLERRM);
   END;
/
