CREATE TRIGGER PREINS_ACI
  
 BEFORE INSERT 
	
  ON R5ACCOUNTDETAILINTERFACE
  
 FOR EACH ROW 
DECLARE
  chk VARCHAR2(3);
BEGIN
 IF o7gtsusr <> 'SYS' THEN
  r5o7.o7maxseq( :new.aci_transid, 'INTERFACE', '1', chk );
  o7interface.astint ( 'INSERT',
                   :new.aci_sessionid,
                   :new.aci_trans,
                   'R5ACCOUNTDETAILINTERFACE',
                   :new.aci_transid,
                   NULL,
                   NULL,
                   :new.aci_transorgid,
                   :new.aci_transgroup,
                   NULL,
                   NULL );
 END IF;
END preins_aci;
/
