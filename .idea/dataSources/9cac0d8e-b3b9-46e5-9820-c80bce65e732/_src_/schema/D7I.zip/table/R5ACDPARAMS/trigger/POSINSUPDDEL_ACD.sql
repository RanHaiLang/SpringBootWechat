CREATE TRIGGER POSINSUPDDEL_ACD
  
 AFTER INSERT OR UPDATE OR DELETE 
	
  ON R5ACDPARAMS
  
declare
  -- local variables here
begin
 IF o7gtsusr <> 'SYS' THEN
       update r5pagecache set pgc_updatecount=pgc_updatecount
         WHERE PGC_TABNAME='ACD';

 END IF;
end posinsupddel_acd;
/
