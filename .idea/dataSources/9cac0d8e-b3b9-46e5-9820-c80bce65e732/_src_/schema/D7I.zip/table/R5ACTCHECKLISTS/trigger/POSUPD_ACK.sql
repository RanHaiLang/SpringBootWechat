CREATE TRIGGER POSUPD_ACK
  
 AFTER UPDATE 
	
  ON R5ACTCHECKLISTS
  
 FOR EACH ROW 
DECLARE
   checkresult VARCHAR2(  4 );
   cerrsource  VARCHAR2( 32 );
   cerrtype    VARCHAR2(  4 );
   db_error    EXCEPTION;
BEGIN
   IF o7gtsusr <> 'SYS' THEN
     IF :new.ack_act = 0 THEN
         -- Reset Permit To Work esignature information
         UPDATE r5permittowork SET ptw_reviewed = null, ptw_reviewedby = null, ptw_reviewedtype = null WHERE ptw_code = :new.ack_event;
     END IF;
  END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posupd_ack;
/
