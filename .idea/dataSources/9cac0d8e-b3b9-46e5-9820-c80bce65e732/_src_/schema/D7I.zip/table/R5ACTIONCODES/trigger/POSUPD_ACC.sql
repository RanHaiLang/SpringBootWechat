CREATE TRIGGER POSUPD_ACC
  
 AFTER UPDATE 
	
  ON R5ACTIONCODES
  
 FOR EACH ROW 
DECLARE
   checkresult VARCHAR2(  4 );
   cerrsource  VARCHAR2( 32 );
   cerrtype    VARCHAR2(  4 );
   x           VARCHAR2(  1 );
   db_error    EXCEPTION;
BEGIN
  IF o7gtsusr <> 'SYS' THEN
   /* Initialize */
    checkresult := '0';
    x           := NULL;
   /* A0824 Update r5descriptions */
     o7descs( 'UPD', x, 'ACCO', x, '*', :new.acc_code, '', :new.acc_desc, checkresult );
     IF checkresult <> '0' THEN
        cerrsource := 'O7DESCS';
        cerrtype   := 'PROC';
        RAISE db_error;
     END IF;
  END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posupd_acc;
/
