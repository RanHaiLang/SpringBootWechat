CREATE TRIGGER POSINSUPD_ACT
  
 AFTER INSERT OR UPDATE OR DELETE 
	
  ON R5ACTIVITIES
  
BEGIN
  --IF o7gtsusr <> 'SYS' THEN
    o7eventtemp.cleartemptable;
  --END IF;
END posinsupd_act;
/
