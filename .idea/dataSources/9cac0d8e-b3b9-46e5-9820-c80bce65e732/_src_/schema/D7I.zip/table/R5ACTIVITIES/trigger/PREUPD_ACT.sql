CREATE TRIGGER PREUPD_ACT
  
 BEFORE UPDATE 
	
  ON R5ACTIVITIES
  
 FOR EACH ROW 
DECLARE
   nntrate      NUMBER;                 /* Normal Time Rate of Activity          */
   crstatord    r5ucodes.uco_code%TYPE; /* Order status code defined for order   */
   crtypeord    r5ucodes.uco_code%TYPE; /* Order type code defined for order     */
   corg         r5events.evt_org%TYPE;  /* Organization of event                 */
   checkresult  VARCHAR2(  4 );
   cerrsource   VARCHAR2( 32 );
   cerrortype   VARCHAR2(  4 );
   db_error     EXCEPTION;
BEGIN
 --IF o7gtsusr <> 'SYS' THEN
/* Initialize */
   checkresult := '0';
   cerrsource  := NULL;
   cerrortype  := NULL;
/* W01211 - Event, Act No not updateable  */
   IF :new.act_event <> :old.act_event
   OR :new.act_act <> :old.act_act THEN
      o7err.raise_error( 'R5', 'TRIG', 1 );
   END IF;
/* W0122A - If supplier is not null then Hire Flag = '+'  */
   IF :new.act_supplier is not null AND
      :new.act_supplier <> '*' THEN
      :new.act_hire     := '+';
   END IF;
/* Call o7preact procedure                           */
   o7preact( 'UPD',
             :new.act_event,
             :new.act_start,
             :new.act_duration,
             :new.act_mrc,
             :new.act_trade,
             :new.act_supplier,
             :new.act_supplier_org,
             :new.act_nt,
             :new.act_ot,
             :new.act_est,
             :new.act_rem,
             nntrate,
             :new.act_otrate,
             :new.act_project,
             :new.act_projbud,
             checkresult
           );
   IF checkresult <> '0'  THEN
      cerrsource := 'O7PREACT';
      cerrortype := 'PROC';
      RAISE db_error;
   END IF;

   IF :new.act_hire = '+' AND
      :new.act_order IS NULL AND
      :new.act_req IS NULL THEN
      /* Get org of event */
      SELECT evt_org
      INTO   corg
      FROM   r5events
      WHERE  evt_code = :new.act_event;
      /* Check whether service catalogue price exists. */
      nntrate := o7srvcat( :new.act_task, :new.act_taskrev, :new.act_supplier,
                           :new.act_supplier_org, :new.act_trade, corg,
                           :new.act_start, :new.act_ordrtype, :new.act_qty );
      IF nntrate IS NOT NULL THEN
         :new.act_ntrate := nntrate;
      END IF;
   END IF;

   IF NVL(:new.act_updatecount,-1) = NVL(:old.act_updatecount,-1) THEN
      :new.act_updatecount := NVL(:new.act_updatecount,-1) + 1;
   ELSE
      cerrsource   := 'UPDCOUNT';
      cerrortype   := 'TRIG';
      checkresult  := '1';
      RAISE db_error;
   END IF;

 --END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrortype, checkresult, SQLCODE );
END preupd_act;
/
