CREATE TRIGGER POSDEL_AQU
  
 AFTER DELETE 
	
  ON R5ACTQUALIFICATIONS
  
 FOR EACH ROW 
DECLARE
   rstatus         r5events.evt_rstatus%TYPE;
   rtype           r5events.evt_rtype%TYPE;
   jobtype         r5events.evt_jobtype%TYPE;
   parent          r5events.evt_parent%TYPE;
   org             r5events.evt_org%TYPE;
   evtintout       r5events.evt_interface%TYPE;
   cnt             NUMBER;
   syncwo          VARCHAR2( 30 );
   eventout        r5events.evt_code%TYPE;
   chk1            VARCHAR2(  6 );
BEGIN
  --IF o7gtsusr <> 'SYS' THEN
     BEGIN
       SELECT evt_rstatus, evt_rtype, evt_jobtype, evt_parent, evt_org, evt_interface
       INTO   rstatus, rtype, jobtype, parent, org, evtintout
       FROM   r5events
       WHERE  evt_code = :old.aqu_event;
     EXCEPTION
       -- This exception section is intended for the case that deleting wo will cascade-delete activities
       -- in which case no databridge event should be generated.
       WHEN OTHERS THEN RETURN;
     END;

     IF rstatus IN ( 'R', 'C' ) AND
       rtype IN ( 'JOB', 'PPM' ) THEN
       syncwo := o7dflt( '@SYNCWO', chk1 );
       IF syncwo IN ( 'Y', 'A' ) THEN
         SELECT count(*)
         INTO   cnt
         FROM   r5ucodes
         WHERE  uco_rentity = 'JBTP'
         AND    uco_code    = jobtype
         AND    uco_rcode IN ( '*', 'BR', 'ST', 'PM', 'CAL', 'RP', 'MEC' );
         IF cnt > 0 THEN
           IF syncwo = 'A' AND parent IS NOT NULL THEN
             eventout := parent;
             SELECT evt_interface
             INTO   evtintout
             FROM   r5events
             WHERE  evt_code = parent;
           ELSE
             eventout  := :old.aqu_event;
           END IF;
           INSERT INTO r5xmltranstatus(
                  xts_trantype, xts_table, xts_keyfld1, xts_keyfld2,xts_org, xts_orig_messageid )
      	   SELECT 'SYNCMAINTORDER', 'R5EVENTS', eventout,
                  CASE WHEN evtintout IS NULL THEN 'A' ELSE 'R' END,
                  org, o7sess.get_messageid()
           FROM   dual
           WHERE NOT EXISTS( SELECT 1
                             FROM   r5xmltranstatus
                             WHERE  xts_trantype = 'SYNCMAINTORDER'
                             AND    xts_keyfld1  = eventout );
         END IF;
       END IF;
     END IF;

  --END IF;
EXCEPTION
    WHEN OTHERS THEN NULL;
END posdel_aqu;
/
