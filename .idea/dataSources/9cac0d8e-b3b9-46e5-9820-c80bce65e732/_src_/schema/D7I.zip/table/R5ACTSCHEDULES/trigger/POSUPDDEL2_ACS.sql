CREATE TRIGGER POSUPDDEL2_ACS
  
 AFTER UPDATE OR DELETE 
	
  ON R5ACTSCHEDULES
  
DECLARE
   perresp r5actschedules.acs_responsible%TYPE;
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    FOR i in 1..o7acstemp.acstemptable.count LOOP
      BEGIN
        perresp := null;
        SELECT a.acs_responsible
        INTO  perresp
        FROM  r5actschedules a
        WHERE a.acs_code in (SELECT min(b.acs_code)
                    FROM r5actschedules b
                    WHERE  b.acs_event   = o7acstemp.acstemptable(i).acs_event
                    AND    b.acs_activity = o7acstemp.acstemptable(i).acs_activity
                    AND    b.acs_responsible IS NOT NULL);
      EXCEPTION
        WHEN OTHERS THEN perresp := NULL ;
      END;

      BEGIN
        UPDATE r5activities
        SET    act_perresp = perresp
        WHERE  act_event   = o7acstemp.acstemptable(i).acs_event
        AND    act_act     = o7acstemp.acstemptable(i).acs_activity
        AND    nvl(act_perresp,'-') <> nvl(perresp,'-');
      EXCEPTION
        WHEN OTHERS THEN NULL;
      END;
    END LOOP;
    o7acstemp.acstemptable := o7acstemp.acsemptytable;
  END IF;
END posupddel2_acs;
/
