CREATE TRIGGER PREUPD_ACS
  
 BEFORE UPDATE 
	
  ON R5ACTSCHEDULES
  
 FOR EACH ROW 
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    :new.acs_updated := sysdate;
  END IF;
END preupd_acs;
/
