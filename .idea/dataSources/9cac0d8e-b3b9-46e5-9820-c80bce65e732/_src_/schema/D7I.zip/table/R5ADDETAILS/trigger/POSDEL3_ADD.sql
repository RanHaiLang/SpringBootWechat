CREATE TRIGGER POSDEL3_ADD
  
 AFTER DELETE 
	
  ON R5ADDETAILS
  
 FOR EACH ROW 
BEGIN
  IF O7gtsusr <> 'SYS' THEN

  o7mobile_sync_event ( 'R5ADDETAILS','DELETE', 'ADD_CODE' || CHR(13) || 'ADD_LANG' || CHR(13) || 'ADD_LINE' || CHR(13) || 'ADD_RENTITY' || CHR(13) || 'ADD_TYPE', :old.ADD_CODE || CHR(13) || :old.ADD_LANG || CHR(13) || :old.ADD_LINE || CHR(13) || :old.ADD_RENTITY || CHR(13) || :old.ADD_TYPE, :old.ADD_RENTITY );

  END IF;
END posdel_ADD;
/
