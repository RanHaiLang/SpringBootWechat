CREATE TRIGGER POSINS3_ADD
  
 AFTER INSERT 
	
  ON R5ADDETAILS
  
 FOR EACH ROW 
BEGIN
  IF O7gtsusr <> 'SYS' THEN

  o7mobile_sync_event ( 'R5ADDETAILS','INSERT', 'ADD_CODE' || CHR(13) || 'ADD_LANG' || CHR(13) || 'ADD_LINE' || CHR(13) || 'ADD_RENTITY' || CHR(13) || 'ADD_TYPE', :new.ADD_CODE || CHR(13) || :new.ADD_LANG || CHR(13) || :new.ADD_LINE || CHR(13) || :new.ADD_RENTITY || CHR(13) || :new.ADD_TYPE, :new.ADD_RENTITY );

  END IF;
END posins_ADD;
/
