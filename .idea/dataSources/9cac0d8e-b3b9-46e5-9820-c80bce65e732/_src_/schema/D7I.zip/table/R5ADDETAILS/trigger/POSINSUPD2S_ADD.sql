CREATE TRIGGER POSINSUPD2S_ADD
  
 AFTER INSERT OR UPDATE 
	
  ON R5ADDETAILS
  
BEGIN
   IF o7gtsusr <> 'SYS' THEN
--     RETURN;  It does not make sense.
     o7eventtemp.cleartemptable_add;
   END IF;
END posinsupd2s_add;
/
