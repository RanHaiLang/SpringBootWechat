CREATE TRIGGER POSINSUPD_ADD
  
 AFTER INSERT OR UPDATE 
	
  ON R5ADDETAILS
  
 FOR EACH ROW 
DECLARE
   permitorg    VARCHAR2(15);
   eventcode    VARCHAR2(30);

BEGIN
   IF o7gtsusr <> 'SYS' THEN
     IF :NEW.add_rentity = 'EVNT' AND :NEW.add_updatecount <> -1 AND INSTR( :NEW.add_code, '#' ) = 0 THEN
       o7eventtemp.addevent_add( :new.add_code, SYSDATE );
     END IF;
     IF :NEW.add_rentity = 'OBJ' THEN
       UPDATE r5objects
       SET    obj_updated = SYSDATE
       WHERE  obj_code = SUBSTR( :NEW.add_code, 1, INSTR( :NEW.add_code, '#' )-1 )
       AND    obj_org  = SUBSTR( :NEW.add_code, INSTR( :NEW.add_code, '#' ) + 1 )
       AND    obj_created <= sysdate - 0.00003;
     END IF;
     IF :NEW.add_rentity = 'PERM' THEN
       o7eventtemp.addpermevent_add( :NEW.add_code, SYSDATE );
     END IF;
     IF :NEW.add_rentity = 'PRME' THEN
       BEGIN
         -- first, get Permit Org, permit workorder
         SELECT pev_permit_org, pev_event INTO permitorg, eventcode FROM r5permevents WHERE pev_code = :new.add_code;

         UPDATE r5permevents
         SET pev_reviewed = null, pev_reviewedby = null, pev_reviewedname = null, pev_reviewedtype = null, pev_updated = o7gttime(permitorg), pev_updatedby = :NEW.add_user
         WHERE pev_code = :new.add_code;
         UPDATE r5events
         SET evt_permitreviewed = null, evt_permitreviewedby = null, evt_permitreviewedname = null, evt_permitreviewedtype = null
         WHERE evt_code = eventcode;
       END;
     END IF;
     IF :new.add_rentity = 'EVNT' THEN
            DELETE FROM r5eventsignature WHERE ets_event = :new.add_code and ets_updatecount <> -999;
     END IF;
     -- Reset Permit To Work esignature information
     IF :new.add_rentity IN ('PTW', 'SFWO', 'LTPW') THEN
            UPDATE r5permittowork
            SET ptw_reviewed = null, ptw_reviewedby = null, ptw_reviewedtype = null
            WHERE ptw_code = :new.add_code;
     END IF;
   END IF;
END posinsupd_add;
/
