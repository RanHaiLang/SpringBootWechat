CREATE TRIGGER POSUPD3_ADD
  
 AFTER UPDATE 
	
  ON R5ADDETAILS
  
 FOR EACH ROW 
BEGIN
  IF O7gtsusr <> 'SYS' THEN

  o7mobile_sync_event ( 'R5ADDETAILS','UPDATE', 'ADD_CODE' || CHR(13) || 'ADD_LANG' || CHR(13) || 'ADD_LINE' || CHR(13) || 'ADD_RENTITY' || CHR(13) || 'ADD_TYPE', :new.ADD_CODE || CHR(13) || :new.ADD_LANG || CHR(13) || :new.ADD_LINE || CHR(13) || :new.ADD_RENTITY || CHR(13) || :new.ADD_TYPE, :new.ADD_RENTITY );

  END IF;
END posupd_ADD;
/
