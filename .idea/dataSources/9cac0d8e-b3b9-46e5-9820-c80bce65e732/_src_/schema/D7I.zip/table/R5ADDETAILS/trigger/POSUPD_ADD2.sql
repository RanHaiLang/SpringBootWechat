CREATE TRIGGER POSUPD_ADD2
  
 AFTER UPDATE 
	
  ON R5ADDETAILS
  
 FOR EACH ROW 
DECLARE ten VARCHAR2 (50) := NULL; BEGIN ten := o7getten; IF (ten IS NOT NULL) AND (TO_NUMBER(ten) <> -1) THEN    RETURN; END IF; INSERT INTO r5trigtemp (tmp_table, tmp_action, tmp_sessionid, tmp_storeval1) VALUES ( 'R5ADDETAILS', 'POST-UPDATE', USERENV('SESSIONID'), :new.rowid); END; 
/
