CREATE TRIGGER PREINS_ADD
  
 BEFORE INSERT 
	
  ON R5ADDETAILS
  
 FOR EACH ROW 
BEGIN
 IF o7gtsusr <> 'SYS' THEN
-- B16101 Check (text) type
  IF :new.add_rtype is null THEN
    :new.add_type  := '*';
    :new.add_rtype := '*';
  END IF;
  IF :new.add_rtype <> '*' THEN
    NULL; -- include here a test on text types
  END IF;
  :new.add_user    := NVL(:new.add_user, NVL(o7sess.cur_user,'R5'));
  :new.add_created := NVL(:new.add_created, sysdate);
 END IF;
END preins_add;
/
