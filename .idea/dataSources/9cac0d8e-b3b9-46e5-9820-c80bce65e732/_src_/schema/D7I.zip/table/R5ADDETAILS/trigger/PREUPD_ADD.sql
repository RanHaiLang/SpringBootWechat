CREATE TRIGGER PREUPD_ADD
  
 BEFORE UPDATE 
	
  ON R5ADDETAILS
  
 FOR EACH ROW 
BEGIN
 IF o7gtsusr <> 'SYS' THEN
-- B16211 Only Text and print flag are updateable
-- Exception for changing of N-material code, then the add_code field
-- can be updated
  IF   :new.add_code    <> :old.add_code
    OR :new.add_rentity <> :old.add_rentity
    OR :new.add_type    <> :old.add_type THEN
       IF :old.add_rentity IN ( 'PART', 'CATL', 'FBIL', 'STOC', 'PERS' )  THEN
       -- Should be possible to update add code
          IF    :new.add_rentity <> :old.add_rentity
             OR :new.add_type    <> :old.add_type
             OR :new.add_lang    <> :old.add_lang THEN
                  o7err.raise_error( 'R5', 'TRIG', 1 );
          END IF;
       ELSE
          o7err.raise_error( 'R5', 'TRIG', 1 );
       END IF;
  END IF;
  :new.add_upduser := NVL(:new.add_upduser, NVL(o7sess.cur_user,'R5'));
  :new.add_updated := NVL(:new.add_updated, sysdate);
 END IF;
END preupd_add;
/
