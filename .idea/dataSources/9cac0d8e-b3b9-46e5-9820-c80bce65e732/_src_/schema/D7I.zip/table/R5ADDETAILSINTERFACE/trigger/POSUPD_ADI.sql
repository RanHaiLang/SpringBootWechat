CREATE TRIGGER POSUPD_ADI
  
 AFTER UPDATE 
	
  ON R5ADDETAILSINTERFACE
  
 FOR EACH ROW 
BEGIN
  IF o7gtsusr <> 'SYS' THEN
     INSERT INTO r5archivetemp
       ( art_sessionid,
         art_action,
         art_transapiid,
         art_transorgid,
         art_transgroup,
         art_trans,
         art_apirtype,
         art_apitable,
         art_apiprefix )
      SELECT USERENV('SESSIONID'),
         'POST-UPDATE',
         :new.adi_transid,
         :new.adi_transorgid,
         :new.adi_transgroup,
         :new.adi_trans,
         'C',
         'R5ADDETAILSINTERFACE',
         'ADI'
      FROM DUAL;
  END IF;
END posupd_adi;
/
