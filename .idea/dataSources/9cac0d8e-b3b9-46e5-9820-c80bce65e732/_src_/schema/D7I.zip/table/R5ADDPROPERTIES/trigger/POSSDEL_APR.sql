CREATE TRIGGER POSSDEL_APR
  
 AFTER DELETE 
	
  ON R5ADDPROPERTIES
  
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    -- delete the LOV elements if an LOV exists for this added
    -- property and is not in use by another one.
    o7prop.delete_lovs;
    o7prop.clear_aprdel_tab;
  END IF;
END possdel_apr;
/
