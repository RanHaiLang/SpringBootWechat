CREATE TRIGGER PRESDEL_APR
  
 BEFORE DELETE 
	
  ON R5ADDPROPERTIES
  
BEGIN
 IF o7gtsusr <> 'SYS' THEN
  o7prop.clear_aprdel_tab;
 END IF;
END presdel_apr;
/
