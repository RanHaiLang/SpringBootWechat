CREATE TRIGGER POSDEL_AGR
  
 AFTER DELETE 
	
  ON R5AGREEMENTS
  
 FOR EACH ROW 
DECLARE
   chk           VARCHAR2(  4 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
  /* Delete descriptions (r5descriptions) and other data   */
     o7descs( 'DEL', null, 'AGR', null, '*', :OLD.agr_code,  :OLD.agr_org, null, chk );
  /* Delete property values (r5propertyvalues) */
     o7delprv( 'DEL', 'AGR', :OLD.agr_code||'#'||:OLD.agr_org, :OLD.agr_class, :NEW.agr_class,
	     :OLD.agr_class_org, :NEW.agr_class_org);
  END IF;
END posdel_agr;
/
