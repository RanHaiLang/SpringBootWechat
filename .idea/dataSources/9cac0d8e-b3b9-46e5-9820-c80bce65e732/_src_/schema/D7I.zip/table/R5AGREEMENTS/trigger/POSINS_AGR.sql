CREATE TRIGGER POSINS_AGR
  
 AFTER INSERT 
	
  ON R5AGREEMENTS
  
 FOR EACH ROW 
DECLARE
   chk         VARCHAR2(  4 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Copy descriptions (r5descriptions) */
     o7descs( 'INS', null, 'AGR', null, '*', :NEW.agr_code, :NEW.agr_org, :NEW.agr_desc, chk );
    /* Add to the package for post-statement processing */
     o7agr.posrow (:NEW.rowid);
  END IF;
END posins_agr;
/
