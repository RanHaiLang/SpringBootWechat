CREATE TRIGGER POSUPD_AGR
  
 AFTER UPDATE 
	
  ON R5AGREEMENTS
  
 FOR EACH ROW 
DECLARE
   chk         VARCHAR2(  4 );
BEGIN
   IF o7gtsusr <> 'SYS' THEN
     /* Update descriptions (r5descriptions)   */
     o7descs( 'UPD', null, 'AGR', null, '*', :NEW.agr_code, :NEW.agr_org, :NEW.agr_desc, chk );
     /* If class is updated then check property values of old class */
     o7delprv( 'UPD', 'AGR', :OLD.agr_code||'#'||:OLD.agr_org, :OLD.agr_class, :NEW.agr_class,
              :OLD.agr_class_org, :NEW.agr_class_org);
     /* Add to the package for post-statement processing */
     o7agr.posrow (:NEW.rowid);
   END IF;
END posupd_agr;
/
