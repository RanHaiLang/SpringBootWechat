CREATE TRIGGER PREINS_ADO
  
 BEFORE INSERT 
	
  ON R5ALERTDATAOBJ
  
 FOR EACH ROW 
DECLARE
chk1 VARCHAR2(3);
BEGIN
   IF o7gtsusr <> 'SYS' THEN
      IF (:new.ado_pk IS NULL ) or (:new.ado_pk = '') THEN
         r5o7.o7maxseq(:new.ado_pk, 'ADO', '1', chk1 );
      END IF;
   END IF;
END preins_ado;
/
