CREATE TRIGGER POSDEL_ALT
  
 AFTER DELETE 
	
  ON R5ALERTS
  
 FOR EACH ROW 
DECLARE
  checkresult  VARCHAR2(  4 );
  cerrsource   VARCHAR2( 32 );
  cerrtype     VARCHAR2(  4 );
  db_error     EXCEPTION;
  x            VARCHAR2(  1 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Initialize */
    checkresult := '0';
    x           := NULL;

    /* Delete associated description (r5descriptions) */
    o7descs( 'DEL', x, 'ALRT', x, '*', :old.alt_code, x, x, checkresult );
    IF checkresult <> '0' THEN
      cerrsource := 'O7DESCS';
      cerrtype   := 'PROC';
      RAISE db_error;
    END IF;
  END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posdel_alt;
/
