CREATE TRIGGER POSINS_ALT
  
 AFTER INSERT 
	
  ON R5ALERTS
  
 FOR EACH ROW 
DECLARE
  checkresult VARCHAR2(  4 );
  cerrsource  VARCHAR2( 32 );
  cerrtype    VARCHAR2(  4 );
  x           VARCHAR2(  4 );
  db_error    EXCEPTION;
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Initialize */
    checkresult := '0';
    x           := NULL;

    /*  copy descriptions (r5descriptions) */
    o7descs( 'INS', x, 'ALRT', x, '*', :new.alt_code, x, :new.alt_desc, checkresult );
    IF checkresult <> '0' THEN
      cerrsource := 'O7DESCS';
      cerrtype   := 'PROC';
      RAISE db_error;
    END IF;

    /* Create detail records */
    INSERT INTO r5alertsql(als_alert, als_rtype, als_abortonfailure) VALUES (:new.alt_code, 'B', '+');
    INSERT INTO r5alertsql(als_alert, als_rtype, als_abortonfailure) VALUES (:new.alt_code, 'A', '-');
    INSERT INTO r5alertwo(alw_alert, alw_delay, alw_delayuom) VALUES (:new.alt_code, 1, 'MM');

    o7alert.syncgridparameters(:new.alt_code, :new.alt_gridid);
  END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posins_alt;
/
