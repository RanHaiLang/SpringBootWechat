CREATE TRIGGER PREINS_ALT
  
 BEFORE INSERT 
	
  ON R5ALERTS
  
 FOR EACH ROW 
DECLARE
chk1 VARCHAR2(3);
BEGIN
   IF o7gtsusr <> 'SYS' THEN
      IF (:new.alt_code IS NULL ) or (:new.alt_code = '') THEN
         r5o7.o7maxseq(:new.alt_code, 'ALT', '1', chk1 );
      END IF;
   END IF;
END preins_alt;
/
