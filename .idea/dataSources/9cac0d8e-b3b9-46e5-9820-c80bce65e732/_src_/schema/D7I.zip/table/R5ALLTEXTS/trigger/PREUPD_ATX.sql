CREATE TRIGGER PREUPD_ATX
  
 BEFORE UPDATE 
	
  ON R5ALLTEXTS
  
 FOR EACH ROW 
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    :new.atx_lastmodified := sysdate;
  END IF;
END preupd_atx;
/
