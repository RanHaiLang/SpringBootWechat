CREATE TRIGGER POSDEL_AOR
  
 AFTER DELETE 
	
  ON R5ARCORDERS
  
 FOR EACH ROW 
DECLARE
   checkresult  VARCHAR2(  4 ) := '0';
   cerrsource   VARCHAR2( 32 );
   cerrtype     VARCHAR2(  4 );
   db_error     EXCEPTION;
   x            VARCHAR2(  1 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
   /* Delete dependant data */
     o7descs( 'DEL', x, 'AORD', x, '*', :old.aor_code, x, x, checkresult );
     IF checkresult <> '0' THEN
       cerrsource := 'O7DESCS';
       cerrtype   := 'PROC';
       RAISE db_error;
     END IF;
  END IF;
EXCEPTION
   WHEN db_error THEN
        o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posdel_aor;
/
