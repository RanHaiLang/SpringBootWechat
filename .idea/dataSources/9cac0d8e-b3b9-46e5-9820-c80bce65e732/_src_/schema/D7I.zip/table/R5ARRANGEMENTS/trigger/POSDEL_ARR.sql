CREATE TRIGGER POSDEL_ARR
  
 AFTER DELETE 
	
  ON R5ARRANGEMENTS
  
 FOR EACH ROW 
DECLARE
   chk           VARCHAR2(  4 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
   /* Delete descriptions (r5descriptions) and other data   */
     o7descs( 'DEL', null, 'ARR', null, '*', :OLD.arr_code, :OLD.arr_org, null, chk );
   /* Delete property values (r5propertyvalues) */
     o7delprv( 'DEL', 'ARR', :OLD.arr_code||'#'||:OLD.arr_org, :OLD.arr_class, :NEW.arr_class,
	      :OLD.arr_class_org, :NEW.arr_class_org);
  END IF;
END posdel_arr;
/
