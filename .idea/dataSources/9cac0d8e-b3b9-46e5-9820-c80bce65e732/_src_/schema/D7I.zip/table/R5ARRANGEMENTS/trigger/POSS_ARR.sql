CREATE TRIGGER POSS_ARR
  
 AFTER INSERT OR UPDATE 
	
  ON R5ARRANGEMENTS
  
DECLARE
   cmode VARCHAR2 (3);
BEGIN
  IF o7gtsusr <> 'SYS' THEN
   /* Process the data saved in the package */
   IF INSERTING THEN
      cmode := 'INS';
   ELSIF UPDATING THEN
      cmode := 'UPD';
   ELSIF DELETING THEN
      cmode := 'DEL';
   END IF;
   o7arr.posstmt (cmode);
  END IF;
END poss_arr;
/
