CREATE TRIGGER POSUPD_ARR
  
 AFTER UPDATE 
	
  ON R5ARRANGEMENTS
  
 FOR EACH ROW 
DECLARE
   chk         VARCHAR2(  4 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Update descriptions (r5descriptions)   */
     o7descs( 'UPD', null, 'ARR', null, '*', :NEW.arr_code, :NEW.arr_org, :NEW.arr_desc, chk );
    /* If class is updated then check property values of old class */
     o7delprv( 'UPD', 'ARR', :OLD.arr_code||'#'||:OLD.arr_org, :OLD.arr_class, :NEW.arr_class,
 	     :OLD.arr_class_org, :NEW.arr_class_org);
    /* Add to the package for post-statement processing */
     o7arr.posrow (:NEW.rowid);
   END IF;
END posupd_arr;
/
