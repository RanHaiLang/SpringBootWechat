CREATE TRIGGER PRES_ARR
  
 BEFORE INSERT OR UPDATE 
	
  ON R5ARRANGEMENTS
  
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Initialise the package for post-statement processing */
   o7arr.prestmt;
 END IF;
END pres_arr;
/
