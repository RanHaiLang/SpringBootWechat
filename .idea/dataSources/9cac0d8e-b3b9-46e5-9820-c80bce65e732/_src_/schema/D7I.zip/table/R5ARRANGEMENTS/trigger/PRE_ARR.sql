CREATE TRIGGER PRE_ARR
  
 BEFORE INSERT OR UPDATE OR DELETE 
	
  ON R5ARRANGEMENTS
  
 FOR EACH ROW 
DECLARE
   insupddel VARCHAR2 (3);
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Determine mode */
   IF INSERTING THEN
      insupddel := 'INS';
   ELSIF UPDATING THEN
      insupddel := 'UPD';
   ELSIF DELETING THEN
      insupddel := 'DEL';
   END IF;
/* Call dedicated procedure for further processing */
   o7prearr (
         insupddel,
         old_arr_class => :OLD.arr_class,
         old_arr_clsorg => :OLD.arr_class_org,
         old_arr_code => :OLD.arr_code,
         old_arr_custom_tariff => :OLD.arr_custom_tariff,
         old_arr_desc => :OLD.arr_desc,
         old_arr_dma_charge => :OLD.arr_dma_charge,
         old_arr_fix_charge => :OLD.arr_fix_charge,
         old_arr_hir_charge => :OLD.arr_hir_charge,
         old_arr_lab_charge => :OLD.arr_lab_charge,
         old_arr_mat_charge => :OLD.arr_mat_charge,
         old_arr_tol_charge => :OLD.arr_tol_charge,
         old_arr_mat_specific => :OLD.arr_mat_specific,
         old_arr_min_time => :OLD.arr_min_time,
         old_arr_time_roundup => :OLD.arr_time_roundup,
         new_arr_class => :NEW.arr_class,
         new_arr_clsorg => :NEW.arr_class_org,
         new_arr_code => :NEW.arr_code,
         new_arr_custom_tariff => :NEW.arr_custom_tariff,
         new_arr_desc => :NEW.arr_desc,
         new_arr_dma_charge => :NEW.arr_dma_charge,
         new_arr_fix_charge => :NEW.arr_fix_charge,
         new_arr_hir_charge => :NEW.arr_hir_charge,
         new_arr_lab_charge => :NEW.arr_lab_charge,
         new_arr_mat_charge => :NEW.arr_mat_charge,
         new_arr_tol_charge => :NEW.arr_tol_charge,
         new_arr_mat_specific => :NEW.arr_mat_specific,
         new_arr_min_time => :NEW.arr_min_time,
         new_arr_time_roundup => :NEW.arr_time_roundup);
 END IF;
END pre_arr;
/
