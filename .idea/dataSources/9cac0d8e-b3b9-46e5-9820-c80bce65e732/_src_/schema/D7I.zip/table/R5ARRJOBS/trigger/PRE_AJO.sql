CREATE TRIGGER PRE_AJO
  
 BEFORE INSERT OR UPDATE 
	
  ON R5ARRJOBS
  
 FOR EACH ROW 
DECLARE
   insupddel VARCHAR2 (3);
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Determine mode */
   IF INSERTING THEN
      insupddel := 'INS';
   ELSIF UPDATING THEN
      insupddel := 'UPD';
   END IF;
/* Call dedicated procedure for further processing */
   o7preajo (
         insupddel,
         old_ajo_arrangement => :OLD.ajo_arrangement,
         old_ajo_jobtype => :OLD.ajo_jobtype,
         old_ajo_mrc => :OLD.ajo_mrc,
         old_ajo_objclass => :OLD.ajo_objclass,
	 old_ajo_objclsorg => :OLD.ajo_objclass_org,
         new_ajo_arrangement => :NEW.ajo_arrangement,
         new_ajo_jobtype => :NEW.ajo_jobtype,
         new_ajo_mrc => :NEW.ajo_mrc,
         new_ajo_objclass => :NEW.ajo_objclass,
	 new_ajo_objclsorg => :NEW.ajo_objclass_org);
 END IF;
END pre_ajo;
/
