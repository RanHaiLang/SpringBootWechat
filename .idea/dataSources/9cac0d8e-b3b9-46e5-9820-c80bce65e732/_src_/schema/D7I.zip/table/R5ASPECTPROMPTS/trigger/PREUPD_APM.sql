CREATE TRIGGER PREUPD_APM
  
 BEFORE UPDATE 
	
  ON R5ASPECTPROMPTS
  
 FOR EACH ROW 
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    :new.apm_updated := sysdate;
  END IF;
END preupd_apm;
/
