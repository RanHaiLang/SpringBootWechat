CREATE TRIGGER POSINS_ASP
  
 AFTER INSERT 
	
  ON R5ASPECTS
  
 FOR EACH ROW 
DECLARE
   checkresult VARCHAR2(  4 );
   cerrsource  VARCHAR2( 32 );
   cerrtype    VARCHAR2(  4 );
   x           VARCHAR2(  1 );
   db_error    EXCEPTION;

BEGIN
  IF o7gtsusr <> 'SYS' THEN
   /* Initialize */
     checkresult := '0';
     x           := NULL;
     o7descs( 'INS', x, 'ASPC', x, '*', :new.asp_code, x, :new.asp_desc, checkresult );
     IF checkresult <> '0' THEN
        cerrsource := 'O7DESCS';
        cerrtype   := 'PROC';
        RAISE db_error;
     END IF;
   END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posins_asp;
/
