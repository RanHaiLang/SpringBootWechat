CREATE TRIGGER POSUPD_ASP
  
 AFTER UPDATE 
	
  ON R5ASPECTS
  
 FOR EACH ROW 
DECLARE
   checkresult VARCHAR2(  4 ) := '0';
   x           VARCHAR2(  1 );
   chk         VARCHAR2(3);
   ndeforg     r5install.ins_desc%TYPE := o7dflt('DEFORG', chk);
BEGIN
  IF o7gtsusr <> 'SYS' THEN
   /* I01231 - Update descriptions (r5descriptions)   */
     o7descs( 'UPD', x, 'ASPC', x, '*', :new.asp_code, x, :new.asp_desc, checkresult );
     IF checkresult <> '0' THEN
        o7err.raise_error('O7DESCS','PROC', checkresult );
     END IF;
   /* I01235 : If Class is updated then delete custom property values of old class */
     IF NVL( :old.asp_class, '*' ) <> '*' AND
        (NVL(:new.asp_class, '*') <> NVL(:old.asp_class, '*'))
        OR (NVL(:new.asp_class_org, ndeforg) <> NVL(:old.asp_class_org, ndeforg)) THEN
        DELETE FROM r5propertyvalues
        WHERE prv_rentity   = 'ASPC'
       AND   prv_class     = :old.asp_class
       AND   prv_class_org = :old.asp_class_org
       AND   prv_code      = :old.asp_code;
     END IF;
  END IF;
END posupd_asp;
/
