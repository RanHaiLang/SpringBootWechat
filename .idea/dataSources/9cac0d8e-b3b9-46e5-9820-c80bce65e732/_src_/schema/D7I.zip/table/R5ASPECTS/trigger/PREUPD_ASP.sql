CREATE TRIGGER PREUPD_ASP
  
 BEFORE UPDATE 
	
  ON R5ASPECTS
  
 FOR EACH ROW 
DECLARE
   checkresult  VARCHAR2(  4 ) := '0';
   x            VARCHAR2(  1 );
   countit      NUMBER  := 0;
   chk          VARCHAR2(  3 );
   ndeforg      r5install.ins_desc%TYPE := o7dflt('DEFORG', chk);
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* I01211 : Aspect code ( and Time dependence are) is not updatable */
   IF :new.asp_code <> :old.asp_code THEN
      o7err.raise_error( 'R5', 'TRIG', 1 );
   END IF;
/* I01221 : Class must exist ( r5classes, rentity = 'ASPC' ) */
   IF :new.asp_class IS NOT NULL
   AND (:new.asp_class <> NVL( :old.asp_class, '*' )
         OR :new.asp_class_org <> NVL( :old.asp_class_org, ndeforg )) THEN
      r5o7.o7exist( 'CLAS', 'ASPC', :new.asp_class,:new.asp_class_org, '*', x, x, x, x,
                    countit, checkresult );
      IF countit = 0 THEN
         o7err.raise_error( 'PREUPD_ASP', 'TRIG', 1 );
      END IF;
  END IF;
  :new.asp_updated := sysdate;
 END IF;
END preupd_asp;
/
