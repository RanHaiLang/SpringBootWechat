CREATE TRIGGER PREUPD_APK
  
 BEFORE UPDATE 
	
  ON R5AUDITPK
  
 FOR EACH ROW 
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    :new.apk_updated := sysdate;
  END IF;
END preupd_apk;
/
