CREATE TRIGGER POSDEL3_AUT
  
 AFTER DELETE 
	
  ON R5AUTH
  
 FOR EACH ROW 
BEGIN
  IF O7gtsusr <> 'SYS' THEN

  o7mobile_sync_event ( 'R5AUTH','DELETE', 'AUT_ENTITY' || CHR(13) || 'AUT_GROUP' || CHR(13) || 'AUT_STATNEW' || CHR(13) || 'AUT_STATUS' || CHR(13) || 'AUT_USER', :old.AUT_ENTITY || CHR(13) || :old.AUT_GROUP || CHR(13) || :old.AUT_STATNEW || CHR(13) || :old.AUT_STATUS || CHR(13) || :old.AUT_USER, NULL );

  END IF;
END posdel_AUT;
/
