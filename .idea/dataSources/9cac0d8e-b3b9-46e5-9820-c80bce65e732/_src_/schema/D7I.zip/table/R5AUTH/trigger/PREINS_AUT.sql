CREATE TRIGGER PREINS_AUT
  
 BEFORE INSERT 
	
  ON R5AUTH
  
 FOR EACH ROW 
DECLARE
   checkresult    VARCHAR2( 4 );
   x              VARCHAR2( 80 );
   cerrsource     VARCHAR2( 32 );
   cerrtype       VARCHAR2( 4 );
   db_error       EXCEPTION;
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Initialize */
   checkresult := '0';
   x           := NULL;
/* Get rentity for given entity   (or vice versa)           */
   IF :new.aut_rentity  IS NULL OR :new.aut_entity IS NULL THEN
     r5o7.o7ckcode( :new.aut_rentity, :new.aut_entity, 'ENT', checkresult );
     IF checkresult <> '0' THEN
        cerrsource  := 'O7CKCODE';
        cerrtype    := 'PROC';
        RAISE db_error;
     END IF;
   END IF;
   o7preaut( 'INS', :new.aut_group, :new.aut_user, :new.aut_entity,
             x, x, :new.aut_status, :new.aut_statnew,
             checkresult );
   IF checkresult <> '0'  THEN
      cerrsource  := 'O7PREAUT';
      cerrtype    := 'PROC';
      RAISE db_error;
   END IF;
 END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preins_aut;
/
