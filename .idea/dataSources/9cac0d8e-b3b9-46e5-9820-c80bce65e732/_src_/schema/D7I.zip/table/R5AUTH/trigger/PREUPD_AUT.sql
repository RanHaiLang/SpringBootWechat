CREATE TRIGGER PREUPD_AUT
  
 BEFORE UPDATE 
	
  ON R5AUTH
  
 FOR EACH ROW 
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* B11211 : Only Type is updateable */
   IF ( :new.aut_group   <> :old.aut_group   )
   OR ( :new.aut_user    <> :old.aut_user    )
   OR ( :new.aut_entity  <> :old.aut_entity  )
   OR ( :new.aut_rentity <> :old.aut_rentity )
   OR ( :new.aut_status  <> :old.aut_status  )
   OR ( :new.aut_statnew <> :old.aut_statnew ) THEN
      o7err.raise_error( 'R5', 'TRIG', 1 );
   END IF;
   :new.aut_updated := sysdate;
 END IF;
END preupd_aut;
/
