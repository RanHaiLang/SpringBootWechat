CREATE TRIGGER PREUPD_AVL
  
 BEFORE UPDATE 
	
  ON R5AVAILABILITY
  
 FOR EACH ROW 
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* W33211 - Updation of MRC, TRADE, DATE fields not allowed   */
   IF :new.avl_date  <> :old.avl_date
   OR :new.avl_mrc   <> :old.avl_mrc
   OR :new.avl_trade <> :old.avl_trade THEN
      o7err.raise_error( 'R5', 'TRIG', 1 );
   END IF;
 END IF;
END preupd_avl;
/
