CREATE TRIGGER POSUPD_BCR
  
 AFTER UPDATE 
	
  ON R5BARCODEREADERS
  
 FOR EACH ROW 
DECLARE
   checkresult VARCHAR2( 4 );
   cerrsource  VARCHAR2( 32 );
   cerrtype    VARCHAR2( 4 );
   x           VARCHAR2( 1 );
   db_error    EXCEPTION;
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Initialize */
     checkresult := '0';
     x           := NULL;
    /* S3924  Update r5descriptions */
     o7descs( 'UPD', x, 'BARR', x, '*', :new.bcr_code, x, :new.bcr_desc, checkresult );
     IF checkresult <> '0' THEN
        cerrsource := 'O7DESCS';
        cerrtype   := 'PROC';
        RAISE db_error;
     END IF;
  END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posupd_bcr;
/
