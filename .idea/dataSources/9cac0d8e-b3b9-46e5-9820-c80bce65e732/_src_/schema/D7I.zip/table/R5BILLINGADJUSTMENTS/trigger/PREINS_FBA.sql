CREATE TRIGGER PREINS_FBA
  
 BEFORE INSERT 
	
  ON R5BILLINGADJUSTMENTS
  
 FOR EACH ROW 
DECLARE
  checkresult   VARCHAR2( 4 );
  cerrsource    VARCHAR2( 32 );
  cerrtype      VARCHAR2( 4 );
  db_error      EXCEPTION;
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Initialize. */
    checkresult := '0';
    /* get next sequence number */
    IF :new.fba_pk IS NULL THEN
      r5o7.o7maxseq( :new.fba_pk , 'FLEET', '1', checkresult );
    END IF;
    /* Give date field a value. */
    :new.fba_date := o7gttime( '' );
  END IF;
EXCEPTION
  WHEN db_error THEN
    o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preins_fba;
/
