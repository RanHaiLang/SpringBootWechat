CREATE TRIGGER PREUPD2_FBA
  
 BEFORE UPDATE 
	
  ON R5BILLINGADJUSTMENTS
  
 FOR EACH ROW 
DECLARE
  db_error     EXCEPTION;
  checkresult  VARCHAR2(  4 ) := '0';
  cerrsource   VARCHAR2( 15 );
  cerrtype     VARCHAR2(  4 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    IF NVL( :new.fba_updatecount, -1 ) = NVL( :old.fba_updatecount, -1 ) THEN
      :new.fba_updatecount := NVL( :new.fba_updatecount, -1 ) + 1;
    ELSE
      cerrsource  := 'UPDCOUNT';
      cerrtype    := 'TRIG';
      checkresult := '1';
      RAISE db_error;
    END IF;
  END IF;
EXCEPTION
  WHEN db_error THEN
    o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preupd2_fba;
/
