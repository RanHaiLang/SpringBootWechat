CREATE TRIGGER PREUPD_FBA
  
 BEFORE UPDATE 
	
  ON R5BILLINGADJUSTMENTS
  
 FOR EACH ROW 
DECLARE
  checkresult   VARCHAR2( 4 );
  x             VARCHAR2( 1 );
  countit       NUMBER;
  cerrsource    VARCHAR2( 32 );
  cerrtype      VARCHAR2( 4 );
  db_error      EXCEPTION;
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Initialize. */
    checkresult := '0';
    x           := NULL;
    /* PK, original bill and ticket are not updateable. */
    IF :new.fba_pk <> :old.fba_pk OR
       :new.fba_originalbill <> :old.fba_originalbill OR
       :new.fba_ticket <> :old.fba_ticket THEN
      o7err.raise_error( 'R5', 'TRIG', 1 );
    END IF;
  END IF;
EXCEPTION
  WHEN db_error THEN
    o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preupd_fba;
/
