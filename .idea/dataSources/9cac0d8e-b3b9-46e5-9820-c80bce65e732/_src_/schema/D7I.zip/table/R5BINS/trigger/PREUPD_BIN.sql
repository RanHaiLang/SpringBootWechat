CREATE TRIGGER PREUPD_BIN
  
 BEFORE UPDATE 
	
  ON R5BINS
  
 FOR EACH ROW 
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* S27311 - Store, Bin not updateable     */
   IF :new.bin_code   <> :old.bin_code
   OR :new.bin_store <> :old.bin_store THEN
      o7err.raise_error( 'R5', 'TRIG', 1 );
   END IF;
   IF NVL( :old.bin_notused, '-' ) = '-' AND
      NVL( :new.bin_notused, '-' ) = '+' THEN
      /* Clear default bin. */
      UPDATE r5stock
      SET    sto_defaultbin = ''
      WHERE  sto_store      = :new.bin_store
      AND    sto_defaultbin = :new.bin_code;
   END IF;
 END IF;
END preupd_bin;
/
