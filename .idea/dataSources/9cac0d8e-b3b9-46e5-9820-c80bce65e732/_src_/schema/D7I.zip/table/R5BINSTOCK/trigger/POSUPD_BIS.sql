CREATE TRIGGER POSUPD_BIS
  
 AFTER UPDATE 
	
  ON R5BINSTOCK
  
 FOR EACH ROW 
DECLARE
   checkresult   VARCHAR2(  4 );
   cerrsource    VARCHAR2( 32 );
   cerrtype      VARCHAR2(  4 );
   db_error      EXCEPTION;
   nquantity     NUMBER;
   nrepairqty    NUMBER;
BEGIN
  IF o7gtsusr <> 'SYS' THEN
   /* Initialize  */
     checkresult := '0';
   /* S3233   Update stock quantity (r5stock)  */
     nquantity  := nvl( :old.bis_qty, 0 )       - nvl( :new.bis_qty, 0 );
     nrepairqty := nvl( :old.bis_repairqty, 0 ) - nvl( :new.bis_repairqty, 0 );
     o7upbis1( :new.bis_store, :new.bis_part, :new.bis_part_org,
             nquantity, nrepairqty, checkresult );
     IF checkresult <> '0' THEN
        cerrsource := 'O7UPBIS1';
        cerrtype   := 'PROC';
        RAISE db_error;
     END IF;
  END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posupd_bis;
/
