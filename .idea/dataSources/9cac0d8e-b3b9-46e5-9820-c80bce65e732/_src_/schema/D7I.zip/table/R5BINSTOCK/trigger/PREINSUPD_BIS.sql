CREATE TRIGGER PREINSUPD_BIS
  
 BEFORE INSERT OR UPDATE 
	
  ON R5BINSTOCK
  
 FOR EACH ROW 
BEGIN
   IF o7gtsusr <> 'SYS' THEN
     IF INSERTING THEN
        :new.bis_createdby    := NVL( o7sess.cur_user,'R5' );
        :new.bis_created      := sysdate;
     ELSE
        :new.bis_updatedby    := NVL( o7sess.cur_user,'R5' );
        :new.bis_updated      := sysdate;
     END IF;
   END IF;
END preinsupd_bis;
/
