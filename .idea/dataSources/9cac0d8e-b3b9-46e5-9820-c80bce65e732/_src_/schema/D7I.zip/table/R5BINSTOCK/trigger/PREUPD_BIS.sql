CREATE TRIGGER PREUPD_BIS
  
 BEFORE UPDATE 
	
  ON R5BINSTOCK
  
 FOR EACH ROW 
DECLARE
   checkresult   VARCHAR2(  4 );
   cerrsource    VARCHAR2( 32 );
   cerrtype      VARCHAR2(  4 );
   db_error      EXCEPTION;
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* S32311 - Store, Part, Bin, Lot not updateable   */
   IF :new.bis_store    <> :old.bis_store
   OR :new.bis_part     <> :old.bis_part
   OR :new.bis_part_org <> :old.bis_part_org
   OR :new.bis_bin      <> :old.bis_bin
   OR :new.bis_lot      <> :old.bis_lot THEN
     cerrsource   := 'R5';
     cerrtype     := 'TRIG';
     checkresult  := '1';
     RAISE db_error;
   END IF;
 END IF;

EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preupd_bis;
/
