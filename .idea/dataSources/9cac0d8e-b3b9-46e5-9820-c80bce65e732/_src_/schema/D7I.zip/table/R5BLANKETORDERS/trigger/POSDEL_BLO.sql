CREATE TRIGGER POSDEL_BLO
  
 AFTER DELETE 
	
  ON R5BLANKETORDERS
  
 FOR EACH ROW 
DECLARE
  cseqno       VARCHAR2( 30 );
  chk1         VARCHAR2(  6 );

BEGIN
   IF o7gtsusr <> 'SYS' THEN
     /* 21 CFR 11 BEGIN ================================================================== */
     BEGIN
       IF o7erecord ('DEL', 'BORD', :old.blo_status, '-' ) > 0 THEN
         r5o7.o7maxseq( cseqno, 'EREC', '1', chk1 );
         INSERT INTO r5elecarchive (  ELA_CODE,  ELA_USER,  ELA_DATE,   ELA_SIGNTYPE,ELA_CERTIFYNUM,ELA_CERTIFYTYPE,
                                  ELA_SCODE, ELA_ENTITY,ELA_ENTCODE,ELA_ENTORG,   ELA_STATUS, ELA_PARENT,
                                  ELA_FLD1,  ELA_FLD2,   ELA_FLD3,   ELA_FLD4,
                                  ELA_FLD5,  ELA_FLD6,   ELA_FLD7,   ELA_FLD8,
                                  ELA_FLD9,  ELA_FLD10,  ELA_FLD11,  ELA_FLD12,
                                  ELA_FLD13, ELA_FLD14,  ELA_FLD15,  ELA_FLD16,
                                  ELA_FLD17, ELA_FLD18,  ELA_FLD19,  ELA_FLD20,
                                  ELA_FLD21, ELA_FLD22,  ELA_FLD23,  ELA_FLD24,
                                  ELA_FLD25, ELA_FLD26,  ELA_FLD27,  ELA_FLD28,
                                  ELA_FLD29, ELA_FLD30,  ELA_FLD31 )
         VALUES ( cseqno,         o7esign.getuser,       o7gttime( :new.blo_org ), o7esign.getstype,
                  o7esign.getcertifynum,o7esign.getcertifytype,
                  '',       'BORD',         :OLD.blo_blanketorder, :OLD.blo_org,      :OLD.blo_status,    '',
                  :old.BLO_BLANKETORDER,    :old.BLO_DESC,     :old.BLO_CLASS,      :old.BLO_STATUS,
                  :old.BLO_RSTATUS, TO_CHAR(:old.BLO_CREATED,'DD-MON-YYYY'),
                  :old.BLO_SUPPLIER,:old.BLO_STORE,      :old.BLO_CURR,     :old.BLO_EXCH,
                  :old.BLO_BUYER,   :old.BLO_MAXAMOUNT,  :old.BLO_CURAMOUNTREL,  :old.BLO_NUMRELEASED,
                  TO_CHAR(:old.BLO_START,'DD-MON-YYYY'),
                  TO_CHAR(:old.BLO_END,'DD-MON-YYYY'),
                  TO_CHAR(:old.BLO_LASTRELEASED,'DD-MON-YYYY'),
                  :old.BLO_LASTORD,:old.BLO_APPROVEORDER,:old.BLO_PAYMENTTERMS,  :old.BLO_FREIGHTTERMS,
                  :old.BLO_SHIPVIA,:old.BLO_FOBPOINT,    :old.BLO_ORG,           :old.BLO_EXCHTODUAL,
                  :old.BLO_EXCHFROMDUAL,:old.BLO_CLASS_ORG,:old.BLO_SUPPLIER_ORG,:old.BLO_LASTORD_ORG,
                  :old.blo_updatecount,  :old.blo_paybymethod );                      -- PIR#19420
       END IF;
     END;
     /* 21CFR11 END */
   END IF;

END posdel_blo;
/
