CREATE TRIGGER POSINS_BLO
  
 AFTER INSERT 
	
  ON R5BLANKETORDERS
  
 FOR EACH ROW 
DECLARE
   checkresult VARCHAR2(  4 );
   cerrsource  VARCHAR2( 32 );
   cerrtype    VARCHAR2(  4 );
   x           VARCHAR2(  1 );
   db_error    EXCEPTION;

   cseqno       VARCHAR2( 30 );
   chk1         VARCHAR2(  6 );

BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Initialize */
    checkresult := '0';
    x           := NULL;
    /* M25130 - Copy descriptions (r5descriptions) */
    o7descs( 'INS', x, 'BORD', x, '*', :new.blo_blanketorder, :new.blo_org,
             :new.blo_desc, checkresult );
    IF checkresult <> '0' THEN
       cerrsource := 'O7DESCS';
       cerrtype   := 'PROC';
       RAISE db_error;
    END IF;
    /* 21CFR11 */
    BEGIN
      IF o7erecord ('NEW', 'BORD', '-', :new.blo_status ) > 0 THEN
        r5o7.o7maxseq( cseqno, 'EREC', '1', chk1 );
        INSERT INTO r5elecarchive ( ELA_CODE, ELA_USER, ELA_DATE,   ELA_SIGNTYPE, ELA_CERTIFYNUM,ELA_CERTIFYTYPE,
                                  ELA_SCODE, ELA_ENTITY,ELA_ENTCODE,ELA_ENTORG,   ELA_STATUS,  ELA_PARENT,
                                  ELA_FLD1,  ELA_FLD2,   ELA_FLD3,   ELA_FLD4,
                                  ELA_FLD5,  ELA_FLD6,   ELA_FLD7,   ELA_FLD8,
                                  ELA_FLD9,  ELA_FLD10,  ELA_FLD11,  ELA_FLD12,
                                  ELA_FLD13, ELA_FLD14,  ELA_FLD15,  ELA_FLD16,
                                  ELA_FLD17, ELA_FLD18,  ELA_FLD19,  ELA_FLD20,
                                  ELA_FLD21, ELA_FLD22,  ELA_FLD23,  ELA_FLD24,
                                  ELA_FLD25, ELA_FLD26,  ELA_FLD27,  ELA_FLD28,
                                  ELA_FLD29, ELA_FLD30,  ELA_FLD31)
        VALUES (  cseqno, o7esign.getuser, o7gttime( :new.blo_org ), o7esign.getstype,
                  o7esign.getcertifynum,o7esign.getcertifytype,
                  '',    'BORD',         :new.blo_blanketorder, :new.blo_org,        :new.blo_status,    '',
                  :new.BLO_BLANKETORDER, :new.BLO_DESC,  :new.BLO_CLASS,      :new.BLO_STATUS,
                  :new.BLO_RSTATUS,      TO_CHAR(:new.BLO_CREATED,'DD-MON-YYYY'),
                  :new.BLO_SUPPLIER,     :new.BLO_STORE, :new.BLO_CURR,       :new.BLO_EXCH,
                  :new.BLO_BUYER,        :new.BLO_MAXAMOUNT, :new.BLO_CURAMOUNTREL, :new.BLO_NUMRELEASED,
                  TO_CHAR(:new.BLO_START,'DD-MON-YYYY'),
                  TO_CHAR(:new.BLO_END,'DD-MON-YYYY'),
                  TO_CHAR(:new.BLO_LASTRELEASED,'DD-MON-YYYY'),
                  :new.BLO_LASTORD,      :new.BLO_APPROVEORDER, :new.BLO_PAYMENTTERMS, :new.BLO_FREIGHTTERMS,
                  :new.BLO_SHIPVIA,      :new.BLO_FOBPOINT,     :new.BLO_ORG,          :new.BLO_EXCHTODUAL,
                  :new.BLO_EXCHFROMDUAL, :new.BLO_CLASS_ORG,    :new.BLO_SUPPLIER_ORG, :new.BLO_LASTORD_ORG,
                  :new.blo_updatecount,  :new.blo_paybymethod );                       -- PIR#19420
      END IF;
    END;

  END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posins_blo;
/
