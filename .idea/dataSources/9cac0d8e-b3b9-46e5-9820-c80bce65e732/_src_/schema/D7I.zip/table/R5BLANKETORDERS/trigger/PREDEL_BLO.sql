CREATE TRIGGER PREDEL_BLO
  
 BEFORE DELETE 
	
  ON R5BLANKETORDERS
  
 FOR EACH ROW 
DECLARE
   checkresult   VARCHAR2(  4 );
   cerrsource    VARCHAR2( 32 );
   cerrtype      VARCHAR2(  4 );
   db_error      EXCEPTION;
BEGIN
IF o7gtsusr <> 'SYS' THEN
/* M253 - Deletion of blanket order is not allowed                         */
  checkresult := '990';
  cerrsource  := 'PREDEL_BLO';
  cerrtype    := 'TRIG';
  RAISE db_error;
END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END predel_blo;
/
