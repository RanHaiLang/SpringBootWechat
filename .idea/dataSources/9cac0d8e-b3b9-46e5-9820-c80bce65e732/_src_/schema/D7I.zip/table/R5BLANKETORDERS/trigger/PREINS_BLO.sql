CREATE TRIGGER PREINS_BLO
  
 BEFORE INSERT 
	
  ON R5BLANKETORDERS
  
 FOR EACH ROW 
DECLARE
   checkresult   VARCHAR2(  4 );
   x             VARCHAR2(  1 );
   countit       NUMBER;
   cerrsource    VARCHAR2( 32 );
   cerrtype      VARCHAR2(  4 );
   db_error      EXCEPTION;
BEGIN
IF o7gtsusr <> 'SYS' THEN
/* Initialize                                                              */
   checkresult := '0';
   x           := NULL;
/* M25121 - Buyer must exist(r5users), Flag = '+'                          */
   o7existp( 'USR', 'BYER', :new.blo_buyer, '*', x, x, x, x,
             countit, checkresult );
   IF countit > 0 THEN
      NULL;
   ELSIF countit = 0 THEN
      checkresult := '3';
      cerrsource  := 'PREINS_BLO';
      cerrtype    := 'TRIG';
      RAISE db_error;
   ELSE
     NULL;
   END IF;
/* M25124 - Class must exist ( r5classes, rEntity = 'BORD')               */
   IF :new.blo_class IS NOT NULL THEN
      r5o7.o7exist( 'CLAS',  'BORD', :new.blo_class, :new.blo_class_org,'*', x, x, x, x,
                    countit, checkresult );
      IF countit > 0 THEN
         NULL;
      ELSIF countit = 0 THEN
         checkresult := '4';
         cerrsource  := 'PREINS_BLO';
         cerrtype    := 'TRIG';
         RAISE db_error;
      ELSE
         NULL;
      END IF;
   END IF;
/* M2512B - Status, rStatus must exist(r5ucodes)                          */
   IF :new.blo_status IS NOT NULL THEN
      :new.blo_rstatus := x;
       r5o7.o7ckcode( :new.blo_rstatus, :new.blo_status, 'DOST',
                      checkresult );
      IF checkresult = '0' THEN
         NULL;
      ELSE
         checkresult:= '5';
         cerrsource := 'PREINS_BLO';
         cerrtype   := 'TRIG';
         RAISE db_error;
      END IF;
   END IF;
/* Check whether common organization is allowed. */
   o7ckocom( :new.blo_org, checkresult );
   IF checkresult <> '0'  THEN
      cerrsource := 'O7CKOCOM';
      cerrtype   := 'PROC';
      RAISE db_error;
   END IF;

END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preins_blo;
/
