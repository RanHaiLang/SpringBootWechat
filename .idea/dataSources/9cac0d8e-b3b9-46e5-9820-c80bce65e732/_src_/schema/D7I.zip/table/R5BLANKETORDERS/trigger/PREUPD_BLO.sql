CREATE TRIGGER PREUPD_BLO
  
 BEFORE UPDATE 
	
  ON R5BLANKETORDERS
  
 FOR EACH ROW 
DECLARE
   checkresult   VARCHAR2(  4 ) := '0';
   x             VARCHAR2(  1 );
   countit       NUMBER;
   cerrsource    VARCHAR2( 32 );
   cerrtype      VARCHAR2(  4 );
   db_error      EXCEPTION;
   chk         VARCHAR2(3);
   ndeforg     r5install.ins_desc%TYPE := o7dflt('DEFORG', chk);
BEGIN
IF o7gtsusr <> 'SYS' THEN
/* M25211 - Blanket Order Code is not updateable                           */
   IF :new.blo_blanketorder <> :old.blo_blanketorder THEN
      checkresult:= '6';
      cerrsource := 'PREUPD_BLO';
      cerrtype   := 'TRIG';
      RAISE db_error;
   END IF;
/* M25212 - Supplier is not updateable                                     */
   IF :new.blo_supplier     <> :old.blo_supplier OR
      :new.blo_supplier_org <> :old.blo_supplier_org OR
      :new.blo_org          <> :old.blo_org THEN
      o7err.raise_error( 'PREUPD_BLO', 'TRIG', 7 );
   END IF;
/* M25213 - Store is not updateable                                       */
   IF NVL( :new.blo_store, ' ' ) <> NVL( :old.blo_store, ' ' ) THEN
      o7err.raise_error( 'PREUPD_BLO', 'TRIG', 8 );
   END IF;
/* M25216 - Creation Date is not updateable                               */
   IF :new.blo_created <> :old.blo_created THEN
      o7err.raise_error( 'PREUPD_BLO', 'TRIG', 9 );
   END IF;
/* M25221 - Buyer must exist(r5users), Flag = '+'                          */
   IF  :new.blo_buyer IS NOT NULL
       AND :new.blo_buyer <> NVL( :old.blo_buyer, ' ' ) THEN
     o7existp( 'USR',   'BYER', :new.blo_buyer, '*', x, x, x, x,
                countit, checkresult );
     IF countit = 0 THEN
       o7err.raise_error( 'PREINS_BLO', 'TRIG', 3 );
     END IF;
   END IF;
/* M25223 - Class must exist ( r5classes, rEntity = 'BORD' )              */
   IF :new.blo_class IS NOT NULL
   AND (NVL( :old.blo_class, ' ' ) <> :new.blo_class
	OR :old.blo_class_org <> NVL(:new.blo_class_org, ndeforg)) THEN
     r5o7.o7exist( 'CLAS',  'BORD', :new.blo_class, :new.blo_class_org,'*', x, x, x, x,
                    countit, checkresult );
     IF countit = 0 THEN
       o7err.raise_error( 'PREUPD_BLO', 'TRIG', 4 );
     END IF;
   END IF;
/* M25229 - Updates can occur only if rStatus = 'U' or 'A'                */
  IF :old.blo_rstatus NOT IN ( 'U', 'A' ) OR
     :new.blo_rstatus = 'R' THEN
            checkresult := '900';
            cerrsource  := 'PREUPD_BLO';
            cerrtype    := 'TRIG';
            RAISE db_error;
  END IF;
/* M2522B - If(Max Amount IS NOT NULL and modified) and (Lines exist) then */
/* for each line UOM Price <= Max Amount and Max Line Amount <= Max Amount */
   IF  ( :new.blo_maxamount IS NOT NULL
   AND :new.blo_maxamount <> NVL( :old.blo_maxamount, 0 ) ) OR
      :new.blo_exch <> :old.blo_exch THEN
      BEGIN
         SELECT COUNT( * )
         INTO   countit
         FROM   r5blanketordlines b
         WHERE  b.bll_blanketorder  = :new.blo_blanketorder
         AND  ( ROUND(( b.bll_uomprice )/NVL(b.bll_exch, 1), 2 )*NVL(b.bll_qty, 1)
              > ROUND(( :new.blo_maxamount)/ NVL(:new.blo_exch, :old.blo_exch ),2)
         OR   ROUND(( b.bll_price )/NVL(b.bll_exch, 1), 2 )*NVL(b.bll_ordqty, 1)
            > ROUND(( :new.blo_maxamount)/ NVL(:new.blo_exch, :old.blo_exch ),2)
         OR   ROUND(( b.bll_maxlineamount)/NVL(b.bll_exch,1 ) , 2) > ROUND((:new.blo_maxamount)/ NVL(:new.blo_exch,:old.blo_exch ),2));
         IF countit = 0 THEN
            NULL;
         ELSE
            checkresult := '10';
            cerrsource  := 'PREUPD_BLO';
            cerrtype    := 'TRIG';
            RAISE db_error;
         END IF;

      EXCEPTION
         WHEN OTHERS THEN
            RAISE;
      END;
   END IF;
/* M2522E - Status, rStatus must exist(r5ucodes)                          */
   IF :new.blo_status IS NOT NULL
      AND NVL( :old.blo_status, ' ' ) <> :new.blo_status THEN
     :new.blo_rstatus := x;
     r5o7.o7ckcode( :new.blo_rstatus, :new.blo_status, 'DOST',
                    checkresult );
   END IF;
END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preupd_blo;
/
