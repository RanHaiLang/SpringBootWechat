CREATE TRIGGER PREDEL_BLL
  
 BEFORE DELETE 
	
  ON R5BLANKETORDLINES
  
 FOR EACH ROW 
DECLARE
   checkresult   VARCHAR2(  4 );
   cerrsource    VARCHAR2( 32 );
   cerrtype      VARCHAR2(  4 );
   db_error      EXCEPTION;
BEGIN
IF o7gtsusr <> 'SYS' THEN
/* Initialize                                                              */
   checkresult := '0';
/* M26311 - IF Number Release is 0 then delete entity                      */
   IF :old.bll_numreleased <> 0 THEN
      checkresult := '990';
      cerrsource  := 'PREDEL_BLL';
      cerrtype    := 'TRIG';
      RAISE db_error;
   END IF;
END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END predel_bll;
/
