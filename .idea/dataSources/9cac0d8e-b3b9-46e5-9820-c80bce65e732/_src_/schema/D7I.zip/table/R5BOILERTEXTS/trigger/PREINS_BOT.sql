CREATE TRIGGER PREINS_BOT
  
 BEFORE INSERT OR UPDATE 
	
  ON R5BOILERTEXTS
  
 FOR EACH ROW 
DECLARE
   devt   VARCHAR2( 1 );
BEGIN
IF o7gtsusr <> 'SYS' THEN
   SELECT SUBSTR( ins_desc, 1, 1 )
   INTO   devt
   FROM   r5install
   WHERE  ins_code = 'KEEPBOT';

   IF  devt  = '+'
   AND NVL( :new.bot_cloned, '-' ) = '-'
      THEN :new.bot_changed := '+';
   END IF;

   IF UPDATING THEN
      :new.bot_updated := sysdate;
   END IF;

   :new.bot_cloned := '-';

END IF;
END preins_bot;
/
