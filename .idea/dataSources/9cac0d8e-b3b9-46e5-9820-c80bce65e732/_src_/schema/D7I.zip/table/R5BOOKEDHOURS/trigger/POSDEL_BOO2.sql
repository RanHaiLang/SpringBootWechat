CREATE TRIGGER POSDEL_BOO2
  
 AFTER DELETE 
	
  ON R5BOOKEDHOURS
  
 FOR EACH ROW 
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    DELETE FROM r5accountdetail WHERE acd_code = :old.boo_acd;
  END IF;
END posdel_boo2;
/
