CREATE TRIGGER POSINS_BOO
  
 AFTER INSERT 
	
  ON R5BOOKEDHOURS
  
 FOR EACH ROW 
DECLARE
   checkresult    VARCHAR2(  4 );
   cerrsource     VARCHAR2( 32 );
   cerrtype       VARCHAR2(  4 );
   cevent         r5bookedhours.boo_event%TYPE;
   nact           r5bookedhours.boo_act%TYPE;
   nrecvalnow     r5bookedhours.boo_cost%TYPE ;
   nrecqtynow     r5bookedhours.boo_hours%TYPE;
   db_error       EXCEPTION;
   parentevent    r5events.evt_routeparent%TYPE := NULL;
BEGIN
   IF o7gtsusr <> 'SYS' THEN
     /* Intialize */
     checkresult := '0';
     /* If a booked hour record is not from splitting (records  */
     /* created by splitting should have :new.boo_routerec = '+'. */
     IF NVL(:new.boo_routerec, '-') <> '+' THEN
       /* Find the parent work order if it is a child work order (MEC work order) */
       BEGIN
         SELECT evt_routeparent
         INTO   parentevent
         FROM   r5events
         WHERE  evt_code = :new.boo_event;
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
           parentevent := NULL;
       END;
     END IF;

     /* W0315 : Update of activities for ACT_NT, ACT_OT, ACT_REM                */
     IF :new.boo_misc = '-' THEN
       IF( parentevent IS NOT NULL )THEN
         o7upact1( NVL( :new.boo_orighours, :new.boo_hours ), 0, :new.boo_ocrtype,
                   :new.boo_act, parentevent, checkresult );
         IF checkresult <> '0'  THEN
           cerrsource := 'O7UPACT1';
           cerrtype   := 'PROC';
           RAISE db_error;
         END IF;
       END IF;

       o7upact1( NVL( :new.boo_orighours, :new.boo_hours ), 0, :new.boo_ocrtype,
                 :new.boo_act, :new.boo_event, checkresult );
       IF checkresult <> '0'  THEN
         cerrsource := 'O7UPACT1';
         cerrtype   := 'PROC';
         RAISE db_error;
       END IF;
     END IF;
   END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posins_boo;
/
