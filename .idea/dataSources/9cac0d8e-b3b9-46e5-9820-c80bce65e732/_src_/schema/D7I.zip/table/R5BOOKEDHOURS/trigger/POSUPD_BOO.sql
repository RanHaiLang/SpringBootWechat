CREATE TRIGGER POSUPD_BOO
  
 AFTER UPDATE 
	
  ON R5BOOKEDHOURS
  
 FOR EACH ROW 
DECLARE
   nrecqtynow     r5bookedhours.boo_hours%TYPE;
   cevent         r5bookedhours.boo_event%TYPE;
   nact           r5bookedhours.boo_act%TYPE;
   nrecvalnow     r5bookedhours.boo_cost%TYPE ;
   checkresult    VARCHAR2(  4 );
   x              VARCHAR2(  1 );
   cerrsource     VARCHAR2( 32 );
   cerrtype       VARCHAR2(  4 );
   db_error       EXCEPTION;
BEGIN
   IF o7gtsusr <> 'SYS' THEN
     /* Initialize */
     checkresult:= '0';
     x          := NULL;
     IF :new.boo_misc = '-' THEN
       /* W0315 : Update of activities for ACT_NT, ACT_OT, ACT_REM                */
       o7upact1( :new.boo_hours, :old.boo_hours, :new.boo_ocrtype, :new.boo_act,
                 :new.boo_event, checkresult );
       IF checkresult <> '0'  THEN
         cerrsource := 'O7UPACT1';
         cerrtype   := 'PROC';
         RAISE db_error;
       END IF;
     END IF;
   END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posupd_boo;
/
