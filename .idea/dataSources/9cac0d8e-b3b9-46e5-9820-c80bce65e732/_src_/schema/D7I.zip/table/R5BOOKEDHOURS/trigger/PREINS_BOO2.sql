CREATE TRIGGER PREINS_BOO2
  
 BEFORE INSERT 
	
  ON R5BOOKEDHOURS
  
 FOR EACH ROW 
DECLARE
  chk VARCHAR2( 4 );
BEGIN
 IF o7gtsusr <> 'SYS' THEN
   r5o7.o7maxseq( :new.boo_acd, 'ACCOUNT', '1', chk );
 END IF;
END preins_boo2;
/
