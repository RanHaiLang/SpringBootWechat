CREATE TRIGGER PREUPD_BOO
  
 BEFORE UPDATE 
	
  ON R5BOOKEDHOURS
  
 FOR EACH ROW 
DECLARE
   checkresult    VARCHAR2(  4 );
   x              VARCHAR2(  1 );
   cerrsource     VARCHAR2( 32 );
   cerrtype       VARCHAR2(  4 );
   db_error       EXCEPTION;
BEGIN
IF o7gtsusr <> 'SYS' THEN
/* Initialize */
   checkresult:= '0';
   x          := NULL;
/* PVCS 2495 Paul van Gastel  Multiple trade rates (no correction occupation types)*/
/* W0322AA Data entered can not be updated */
   IF :new.boo_entered <> :old.boo_entered
   OR :new.boo_hours   <> :old.boo_hours
   OR :new.boo_off     <> :old.boo_off
   OR :new.boo_on      <> :old.boo_on
   OR :new.boo_event   <> :old.boo_event
   OR :new.boo_act     <> :old.boo_act
   OR :new.boo_mrc     <> :old.boo_mrc
   OR :new.boo_trade   <> :old.boo_trade
   OR :new.boo_correction <> :old.boo_correction THEN
     o7err.raise_error( 'R5', 'TRIG', 1 );
   END IF;

   IF ( :new.boo_cost    <> :old.boo_cost
       OR :new.boo_rate    <> :old.boo_rate ) AND
         :new.boo_gltransfer IS NOT NULL THEN
     o7err.raise_error( 'R5', 'TRIG', 1 );
   END IF;

/* Call to PRE-PROCEDURE o7preboo  where all pre-update checks are executed */
 END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preupd_boo;
/
