CREATE VIEW CLIENT AS select
com.com_code vendorcode, --供应商代码
com.com_udfchar02||com.com_desc vendorname --供应商名称
from
r5companies com
where
com.com_code<>'*'
/
