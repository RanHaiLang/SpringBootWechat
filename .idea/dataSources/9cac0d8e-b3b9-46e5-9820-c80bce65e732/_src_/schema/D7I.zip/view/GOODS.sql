CREATE VIEW GOODS AS select
par.par_code GoodsCode,--成员单位产品代码
par.par_desc Description1,--成员单位描述
--null Description2,--成员单位描述
--null Description3,--成员单位描述
--null Remark1,--成员单位备注
--null Remark2,--成员单位备注
--null Remark3,--成员单位备注
decode(instr(par_desc,'&'),0,null,substr(par_desc,instr(par_desc,'&')+1,length(par_desc)) ) GoodsSPEC,--成员单位产品规格
uom.uom_desc PPUNIT, --成员单位基准主单位
--null PSUNIT,--成员单位基准辅助单位
--null SPUNIT,--成员单位采购主单位
--null SSUNIT,--成员单位采购辅助单位
cls.cls_code catalog,--成员单位产品品类代码
cls.cls_desc catalogName,--成员单位产品品类名称
par.par_updated createdDate, --数据创建时间
par.par_org COMPANY,--成员单位代码
case par_notused when '+' then 0 else 1 end DSTATUS--状态
--null COPYTIME,--拷贝时间
--null TRANSTIME --保留
from r5parts par
left join r5uoms uom on uom.uom_code=par.par_uom
left join r5classes cls on cls.cls_code=par.par_class AND cls_entity='PART'
left join r5organization org on org.org_code=par.par_org
WHERE par.PAR_ORG='SHWY'
/
