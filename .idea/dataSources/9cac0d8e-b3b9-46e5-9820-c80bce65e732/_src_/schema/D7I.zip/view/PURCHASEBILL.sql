CREATE VIEW PURCHASEBILL AS select
ord.rowid ID,--行ID
ord.ord_code POCode,--订单号码
ord.ord_revision Version,--?
--null POSource,--订单来源
cls.cls_desc POType,--订单类型
ord.ord_org POCmpCode,--成员单位代码
--null PRCmpCode,--采购单位
com.com_code PRVendorCode,--供应商代码
ord.ord_due DeliveryDate,--交货日期
ord.ORD_UDFDATE01 PODate, --订单日期(为订单创建日期)
--需求部门
(select mrc_desc from r5mrcs mrc where mrc.mrc_code=(select req.req_udfchar01 from r5requisitions req
where req.req_code=(select orl.orl_req from r5orderlines orl where orl.orl_req is not null and
orl.orl_order=ord.ord_code and rownum = 1))) Department,
ord.ord_status POStatus,--订单状态发布
--null Reference,--请购参考
cur.cur_desc CurrencyType,--币别
--null InvoiceCorp,--发票公司
dad.dad_address DeliveryAddress,--交货地址
(select ort_desc from r5orderterms where ort_code=ORD_PAYBYMETHOD and  ort_type='PYMT') PayCondition,--付款方式
(select ort_desc from r5orderterms where ort_code=ORD_SHIPVIA and ort_type='SHIP')  ShipType,--发运方式
--null Remark,--备注
(select sum(orl.orl_ordqty*orl.orl_price) from r5orderlines orl where  orl.orl_order=ord.ord_code) OrderTotal,--订单总价
(select ort_desc from r5orderterms where ort_code=ORD_PAYMENTTERMS and  ort_type='PAY') SADD1,--付款条件,其他条件
(select ort_desc from r5orderterms where ort_code=ORD_FREIGHTTERMS and  ort_type='FRTR') SADD2--运输条款,其他条件
--null SADD1,--其它条件
--null SADD2,--其它条件
--ord.ord_date CreateDate--记录创建时间
--dbo.r5o7_o7get_desc('ZH','UCOD', ord.ord_status,'DOST', null) Status--状态
from r5orders ord
left join r5classes cls on cls.cls_code=ord.ord_class and cls.cls_entity='PORD'
left join r5companies com on com.com_code=ord.ord_supplier
left join r5currencies cur on cur.cur_code=ord.ord_curr
left join  r5deladdresses dad on dad.dad_code=ord.ord_deladdress
where ord.ORD_UDFCHAR03<>'N' AND ord.ORD_ORG='SHWY'
/
