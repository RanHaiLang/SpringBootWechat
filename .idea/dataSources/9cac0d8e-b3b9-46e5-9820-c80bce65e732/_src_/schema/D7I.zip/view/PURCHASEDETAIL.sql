CREATE VIEW PURCHASEDETAIL AS select
orl.rowid ID,--行ID
orl.orl_order_org POCmpCode,--成员单位代码
orl.orl_order POCode,--订单号码
orl.orl_ordline RowNo,--行号
par.par_code VendorItemCode,--产品代码
par.par_desc Description1,--产品描述
--null Description2,--产品描述
--null Description3,--产品描述
--null Remark1,--备注
--null Remark2,--备注
--null Remark3,--备注
ad.add_text Remark,--备注
orl.orl_ordqty/orl.ORL_MULTIPLY Qty,--数量(订单数量)
(select uom_desc from r5uoms uom where uom.uom_code=orl.ORL_PURUOM) Unit,--单位
orl.orl_price Price,--单价
(select mrc_desc from r5mrcs mrc where mrc.mrc_code=(select req.req_udfchar01  from r5requisitions req where  req.req_code=orl.orl_req and rownum = 1)) Department,--部门
orl.ORL_ORDQTY BQty,--数量(订单基准单位数量)
orl.ORL_MULTIPLY CQty,--数量(订单单位转换基准单位的数量)
(select sum(trl_qty) from r5translines trl,r5transactions tra where tra.tra_code=trl.trl_trans and trl_type='RECV' and
tra.tra_fromentity='COMP' and tra.tra_toentity='STOR' and trl.trl_part=orl.orl_part and trl.trl_order=orl.orl_order and trl.trl_ordline=orl.orl_ordline and
trl_ordline is not null) DQty,--收货数量
uom.uom_desc DUnit,--收货单位
/**(select top 1 trl_price from r5translines trl,r5transactions tra where tra.tra_code=trl.trl_trans and trl_type='RECV' and
tra.tra_fromentity='COMP' and tra.tra_toentity='STOR' and trl.trl_part=orl.orl_part and trl.trl_order=orl.orl_order and trl.trl_ordline=orl.orl_ordline and
trl_ordline is not null order by trl_date desc) DPrice,--收货单价*/
orl.orl_price/orl.ORL_MULTIPLY DPrice,
orl.orl_due DeliveryDate,--交货期
(select trl_date from r5translines trl left join r5transactions tra on tra.tra_code=trl.trl_trans where trl_type='RECV' and
tra.tra_fromentity='COMP' and tra.tra_toentity='STOR' and rownum = 1 and trl.trl_order=orl.orl_order and trl.trl_ordline=orl.orl_ordline and
trl_ordline is not null --order by trl_date desc
) Received--收货期
--null SADD1,--其它条件
--null SADD2,--其它条件
--null DetailStatus,--明细状态
--null CreateDate,--记录创建日期
--(select uco_desc from r5ucodes where orl.orl_status=uco_code and uco_entity='DOST')  Status--状态
from r5orderlines orl
left join r5orders ord on orl.orl_order = ord.ord_code
left join r5parts par on par.par_code=orl.orl_part
left join r5uoms uom on uom.uom_code=par.par_uom
left join r5comments ad
on ad.add_code=orl.orl_order || '#' || ord.ord_org || '#' || orl.orl_ordline and ad.add_entity='PORL'
where
orl.orl_part is not null and ord.ORD_UDFCHAR03<>'N'
/
