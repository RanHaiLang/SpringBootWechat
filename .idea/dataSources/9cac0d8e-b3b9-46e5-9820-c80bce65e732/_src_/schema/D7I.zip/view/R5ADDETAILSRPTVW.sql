CREATE VIEW R5ADDETAILSRPTVW AS SELECT   add_entity, add_rentity, add_type, add_rtype, add_code, add_lang,
	 add_line, add_print, R5REP.TRIMHTML(add_code, add_rentity, add_type, add_lang, add_line) add_text,
	 add_created, add_user, add_updated, add_upduser, add_updatecount
FROM  R5ADDETAILS
/
