CREATE VIEW R5APPHIST AS SELECT h.eah_rentity,
       h.eah_entity,
       h.eah_code,
       h.eah_revision,
       DECODE( l.eal_origin, '+', h.eah_applist, null ),
       DECODE( l.eal_origin, '+', h.eah_appdate, null ),
       DECODE( l.eal_origin, '+', h.eah_user, null ),
       DECODE( l.eal_origin, '+', h.eah_date, null ),
       DECODE( l.eal_origin, '+', h.eah_reason, null ),
       l.eal_approved,
       l.eal_rejected,
       l.eal_user,
       l.eal_username,
       l.eal_seq,
       l.eal_date,
       l.eal_drilldown,
       l.eal_appruser,
       l.eal_apprusername,
       l.eal_resp,
       l.eal_rejectreason,
       l.eal_finished,
       l.eal_pk,
       l.eal_origin
FROM   r5entappheader h,
       r5entapplists l
WHERE  h.eah_rentity  = l.eal_rentity
AND    h.eah_code     = l.eal_code
AND    h.eah_revision = l.eal_revision
/
