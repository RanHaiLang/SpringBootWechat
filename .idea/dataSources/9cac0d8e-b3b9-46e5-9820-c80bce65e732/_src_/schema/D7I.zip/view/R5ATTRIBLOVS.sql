CREATE VIEW R5ATTRIBLOVS AS SELECT DISTINCT
  a.apr_property,
  p.pro_text,
  Decode( a.apr_list, 'P', '*', a.apr_rentity),
  u.uco_desc,
  Decode( a.apr_list, 'C', a.apr_class, '*'),
  Decode( a.apr_list, 'C', a.apr_class_org, '*'),
  c.cls_desc,
  p.pro_type,
  a.apr_list,
  p.pro_min,
  p.pro_max
FROM
  r5addproperties a,
  r5properties p,
  r5ucodes u,
  r5classes c
WHERE a.apr_property = p.pro_code
AND p.pro_type <> 'RENT'
AND a.apr_list <> '-'
AND u.uco_rentity   = 'ENTP'
AND u.uco_system = '+'
AND u.uco_rcode     = Decode( a.apr_list, 'P', '*', a.apr_rentity)
AND c.cls_code (+)  = Decode( a.apr_list, 'C', a.apr_class, '*')
AND c.cls_rentity (+) = Decode( a.apr_list, 'P', '*', a.apr_rentity)
/
