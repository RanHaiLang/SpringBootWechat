CREATE VIEW R5BACKLOG AS SELECT E.evt_code,
       A.act_act,
       A.act_trade,
       A.act_shift,
       A.act_est,
       A.act_rem,
       NVL(A.act_nt,0) + NVL(A.act_ot,0),
       NVL(A.act_start, NVL(E.evt_target,E.evt_reported)),
       E.evt_org,
       E.evt_mrc,
       E.evt_desc,
       E.evt_location,
       E.evt_location_org,
       E.evt_project,
       E.evt_rstatus,
       E.evt_status,
       E.evt_obrtype,
       E.evt_obtype,
       E.evt_object,
       E.evt_object_org,
       E.evt_ppm,
       P.ppo_meter,
       P.ppo_metuom,
       E.evt_origin,
       E.evt_reqm,
       E.evt_jobtype,
       E.evt_priority,
       E.evt_reported,
       E.evt_warranty,
       E.evt_safety,
       E.evt_objcriticality,
       M.mrc_schedgroup,
       P.ppo_freq,
       E.evt_person,
       E.evt_schedgrp,
       E.evt_routeparent,
       E.evt_multiequip
FROM   r5mrcs M, r5events E, r5activities A, r5ppmobjects P
WHERE  E.evt_code    = A.act_event (+)
AND    E.evt_rstatus = 'R'
AND    NVL(A.act_completed,'-') <> '+'
AND    E.evt_mrc     = M.mrc_code
AND    E.evt_ppm     = P.ppo_ppm (+)
AND    E.evt_ppopk   = P.ppo_pk (+)
AND    E.evt_ppmrev  = P.ppo_revision (+)
/
