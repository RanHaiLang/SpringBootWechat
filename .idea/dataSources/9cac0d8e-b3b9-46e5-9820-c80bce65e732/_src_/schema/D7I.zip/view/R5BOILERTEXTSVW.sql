CREATE VIEW R5BOILERTEXTSVW AS (
SELECT
   bot_function,
   bot_number,
   bot_length,
   bot_xpos,
   bot_ypos,
   bot_lang,
   SUBSTR(bot_text,1,63) bot_text,
   bot_dest,
   bot_page,
   bot_fld1,
   bot_fld2,
   bot_prtp,
   bot_lvcr,
   bot_adlen,
   bot_pool,
   bot_changed,
   bot_display,
   bot_updatecount
FROM r5boilertexts)
/
