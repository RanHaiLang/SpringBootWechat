CREATE VIEW R5CATEGORIES AS SELECT
   o.obj_obtype,
   o.obj_code,
   o.obj_org,
   o.obj_desc,
   o.obj_class,
   o.obj_class_org,
   o.obj_part,
   o.obj_part_org,
   o.obj_manufact,
   o.obj_serialno
FROM  r5objects     o
WHERE o.obj_obrtype = 'C'
/
