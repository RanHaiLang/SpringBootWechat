CREATE VIEW R5CHARGEDEFSEQUENCES AS SELECT cds_category, cds_subcategory, cds_level, cds_sequence, cds_actualsubcat, NULL cds_rcode
FROM   r5chargedefsequence
WHERE  cds_category <> 'WOCH'
UNION
SELECT cds_category, uco_code, cds_level, cds_sequence, cds_actualsubcat, NVL( cds_actualsubcat, uco_rcode ) cds_rcode
FROM   r5ucodes, r5chargedefsequence
WHERE  cds_category = 'WOCH'
AND    uco_rentity  = 'CSTP'
AND    uco_rcode    = cds_subcategory
UNION
SELECT 'FUEL', fue_code, 'TR', 25, NULL, NULL
FROM   r5fuels
WHERE  fue_code <> 'FC00'
UNION
SELECT 'FUEL', fue_code, 'SC', 26, NULL, NULL
FROM   r5fuels
WHERE  fue_code <> 'FC00'
UNION
SELECT 'FUEL', 'FC00', 'TR', 25, fue_code, NULL
FROM   r5fuels
WHERE  fue_code <> 'FC00'
UNION
SELECT 'FUEL', 'FC00', 'SC', 26, fue_code, NULL
FROM   r5fuels
WHERE  fue_code <> 'FC00'
UNION
SELECT 'ENER', cmd_code, 'TR', 28, NULL, NULL
FROM   r5commodities
WHERE  cmd_code <> 'EC00'
UNION
SELECT 'ENER', cmd_code, 'SC', 29, NULL, NULL
FROM   r5commodities
WHERE  cmd_code <> 'EC00'
UNION
SELECT 'USCH', uco_code, 'TR', 30 + SUBSTR( uco_rcode, 4, 1 ), NULL, uco_rcode
FROM   r5ucodes
WHERE  uco_rentity = 'CCUC'
UNION
SELECT 'USCH', uco_code, 'SC', 37 + SUBSTR( uco_rcode, 4, 1 ), NULL,
       ( SELECT uco_code FROM r5ucodes u2
         WHERE  uco_rentity = 'CCUC' AND u2.uco_rcode = u.uco_rcode AND uco_system = '+' )
FROM   r5ucodes u
WHERE  uco_rentity = 'CCUC'
UNION
SELECT 'USCH', uco_code, 'TR', 37, NULL, uco_rcode
FROM   r5ucodes
WHERE  uco_rentity = 'CCSC'
AND    uco_rcode   = 'UCU1'
UNION
SELECT 'USCH', uco_code, 'SC', 44, NULL,
       ( SELECT uco_code FROM r5ucodes u2
         WHERE  uco_rentity = 'CCSC' AND u2.uco_rcode = u.uco_rcode AND uco_system = '+' )
FROM   r5ucodes u
WHERE  uco_rentity = 'CCSC'
AND    uco_rcode   = 'UCU1'
UNION
SELECT 'OTCH', uco_code, 'TR', 45 + SUBSTR( uco_rcode, 4, 1 ), NULL, uco_rcode
FROM   r5ucodes
WHERE  uco_rentity = 'CCOC'
UNION
SELECT 'OTCH', uco_code, 'SC', 49 + SUBSTR( uco_rcode, 4, 1 ), NULL,
       ( SELECT uco_code FROM r5ucodes u2
         WHERE  uco_rentity = 'CCOC' AND u2.uco_rcode = u.uco_rcode AND uco_system = '+' )
FROM   r5ucodes u
WHERE  uco_rentity = 'CCOC'
/
