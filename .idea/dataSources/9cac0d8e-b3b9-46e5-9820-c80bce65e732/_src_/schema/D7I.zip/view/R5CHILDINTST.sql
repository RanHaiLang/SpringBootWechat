CREATE VIEW R5CHILDINTST AS SELECT str_parent,
       tst_part,
       tst_part_org,
       SUM( tst_qty )
FROM   r5stores,
       r5transtock
WHERE  tst_tocode = str_code
AND    str_parent IS NOT NULL
AND    NVL( str_notused, '-' ) = '-'
AND    tst_order IS NULL
AND    tst_req IS NULL
AND    tst_torentity = 'STOR'
GROUP BY str_parent,
         tst_part,
         tst_part_org
/
