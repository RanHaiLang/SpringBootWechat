CREATE VIEW R5CHILDJOBREPAIRS AS SELECT str_parent,
       rpb_part,
       rpb_part_org,
       SUM( rpb_qty )
FROM   r5stores,
       r5repairbins
WHERE  rpb_store = str_code
AND    str_parent IS NOT NULL
AND    NVL( str_notused, '-' ) = '-'
AND    rpb_req   IS NULL
AND    rpb_event IS NOT NULL
GROUP BY str_parent,
         rpb_part,
         rpb_part_org
/
