CREATE VIEW R5CHILDRESERVED AS SELECT str_parent,
       res_part,
       res_part_org,
       SUM( res_qty )
FROM   r5stores,
       r5reservations
WHERE  res_store = str_code
AND    str_parent IS NOT NULL
AND    NVL( str_notused, '-' ) = '-'
GROUP BY str_parent,
         res_part,
         res_part_org
/
