CREATE VIEW R5CLOCODES AS SELECT  acc_code, acc_desc, acc_gen, 'A'
 FROM r5actioncodes
  union all
 SELECT  rqm_code, rqm_desc, rqm_gen, 'R'
 FROM r5requircodes
  union all
 SELECT  fal_code, fal_desc, fal_gen, 'F'
 FROM r5failures
  union all
 SELECT  cau_code, cau_desc, cau_gen, 'C'
 FROM r5causes
/
