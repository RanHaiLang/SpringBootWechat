CREATE VIEW R5DEVCATEGORIES AS SELECT dev_code, dev_desc, dev_rtype, dev_type, dev_driver,
          dev_mode, dev_special, dev_orientation
   FROM r5devices
   WHERE dev_catflag = '+'
/
