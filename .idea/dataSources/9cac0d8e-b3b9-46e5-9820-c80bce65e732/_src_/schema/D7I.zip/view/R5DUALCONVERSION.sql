CREATE VIEW R5DUALCONVERSION AS SELECT h.dch_batch,
       h.dch_date,
       h.dch_type,
       h.dch_oldcurr,
       h.dch_newcurr,
       h.dch_exch,
       h.dch_supplier,
       h.dch_supplier_org,
       l.dcl_table,
       l.dcl_pk,
       l.dcl_exch,
       l.dcl_column1,
       l.dcl_value1,
       l.dcl_column2,
       l.dcl_value2,
       l.dcl_column3,
       l.dcl_value3,
       l.dcl_column4,
       l.dcl_value4
FROM   r5dualconvheader h,
       r5dualconvlines l
WHERE  h.dch_batch = l.dcl_batch
/
