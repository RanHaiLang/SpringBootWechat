CREATE VIEW R5DWCREATEDDATES AS SELECT zdt_key,
          zdt_date,
          zdt_runningdaynum,
          zdt_runningweeknum,
          zdt_runningmonthnum,
          zdt_daynuminmonth,
          zdt_daynuminyear,
          zdt_weeknuminyear,
          zdt_monthnuminyear,
          zdt_yearmonth,
          zdt_quarter,
          zdt_yearquarter,
          zdt_halfyear,
          zdt_year,
          zdt_lastdayinmonth
   FROM   r5dwdates
/
