CREATE VIEW R5DWDATAMARTSVIEW AS SELECT dmt_table,
       bot_text dmt_desc,
       dmt_grain,
       dmt_tabletype,
       bot_lang dmt_lang
FROM   r5dwdatamarts,
       r5boilertexts
WHERE  dmt_botnumber = bot_number
AND    bot_function  = 'BSWHSE'
/
