CREATE VIEW R5DWDIMENSIONSVIEW AS SELECT dim_table,
       bot_text dim_desc,
       dim_tabletype,
       dim_keyfield,
       dim_createkeysequence,
       dim_surrogatekeylookuptbl,
       bot_lang dim_lang
FROM   r5dwdimensions,
       r5boilertexts
WHERE  dim_botnumber = bot_number
AND    bot_function  = 'BSWHSE'
/
