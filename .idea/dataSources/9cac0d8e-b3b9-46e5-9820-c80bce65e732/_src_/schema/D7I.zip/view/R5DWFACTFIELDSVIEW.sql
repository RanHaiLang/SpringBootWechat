CREATE VIEW R5DWFACTFIELDSVIEW AS SELECT ffl_field,
       ddf_sourcename ffl_queryfield,
       ffl_dmttable,
       bot_text ffl_desc,
       ffl_additivity,
       ddf_datatype ffl_datatype,
       ddf_lvgrid ffl_lvgrid,
       bot_lang ffl_lang
FROM   r5dwfactfields,
       r5ddfield,
       r5boilertexts
WHERE  ffl_fieldid   = ddf_fieldid (+)
AND    ffl_botnumber = bot_number
AND    bot_function  = 'BSWHSE'
/
