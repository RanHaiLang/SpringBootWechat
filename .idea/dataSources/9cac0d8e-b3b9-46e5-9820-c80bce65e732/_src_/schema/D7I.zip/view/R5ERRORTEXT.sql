CREATE VIEW R5ERRORTEXT AS SELECT
   ert_code,
   ert_text,
   ert_lang,
   ert_translate,
   ers_source,
   ers_type,
   ers_desc,
   ers_number,
   ers_name
FROM
   r5errtexts,
   r5errsource
   WHERE ert_code = ers_code
/
