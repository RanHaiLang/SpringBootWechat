CREATE VIEW R5EXTINVLHOW AS SELECT
 l.eil_invoice 		eiw_invoice,
 l.eil_invoice_org      eiw_invoice_org,
 l.eil_line 		eiw_line,
 e.eiv_status		eiw_status,
 e.eiv_rstatus		eiw_rstatus,
 e.eiv_debtor		eiw_debtor,
 e.eiv_date		      eiw_date,
 l.eil_paymentagreement	eiw_paymentagreement,
 l.eil_paymentline	eiw_paymentline,
 l.eil_eventcode	      eiw_event,
 l.eil_eventincrement	eiw_eventincrement,
 l.eil_price		eiw_price,
 NVL (c.cev_agreement, l.eil_paymentagreement)
				eiw_agreement
FROM 	r5extinvoices e,
      r5extinvlines l,
      r5calcevents c
WHERE	l.eil_invoice        = e.eiv_code
AND   l.eil_invoice_org    = e.eiv_org
AND	l.eil_eventcode      = c.cev_event(+)
AND 	l.eil_eventincrement = c.cev_increment(+)
/
