CREATE VIEW R5GLREFCTRLVIEW AS SELECT glf_process,
       glf_group,
       glf_jecategory,
       glf_jesource,
       glf_setofbooksid,
       glf_updatecount,
       grc_r5column,
       grc_displayname,
       grc_length,
       grc_datatype,
       grc_displayseq
FROM r5glreferences, r5glreferencesctrl
/
