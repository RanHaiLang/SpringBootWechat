CREATE VIEW R5IMPORTPOLINESVW AS select
ORL_ORDER,
ORL_ORDLINE,
ORL_REF,
IMP_ORDINVQTY,
IMP_PRICE,
ORL_PART,
ORL_COSTCODE,
ORL_EVENT,
ORL_ACT,
ORL_TRADE,
ORL_TASK,
ORL_CURR,
ORL_EXCH,
IMP_ORDERED,
IMP_RECEIVED,
IMP_INVOICED,
ORL_TAX,
ORL_TAX2,
ORL_SUPPLIER,
ORL_SUPPLIER_ORG,
IVL_INVOICE,
IVL_INVOICE_ORG,
ORL_RTYPE,
ORL_PART_ORG,
ORL_ORDER_ORG,
ORL_TYPE
from
(
select
	orl_order,
	orl_ordline,
	orl_ref,
	ivl_invqty IMP_ORDINVQTY,
	case when orl_rtype = 'SF' then
		(GREATEST( GREATEST( orl_price, NVL( orl_recvvalue, 0 ) ) -
			NVL( (SELECT SUM( ivl_invvalue * DECODE( inv_rtype, 'I', 1, -1 ) )
			FROM  r5invoices,  r5invoicelines
			WHERE  inv_code = ivl_invoice AND inv_org = ivl_invoice_org AND inv_rstatus <> 'C' AND
			ivl_order = orl_order  AND
			ivl_order_org = orl_order_org  AND ivl_ordline = orl_ordline ), 0 ), 0 )) else
			case when exists(select 1 from r5install where ins_code='INVECINC' and ins_desc in ('NO', 'COPY')) then
				orl_price else
				orl_price * ( 1 - NVL( orl_discperc, 0 ) / 100 ) + ( NVL( orl_totextra, 0 ) / (orl_ordqty / NVL( orl_multiply, 1 )) )
			end
	end IMP_PRICE,
	orl_part,
	orl_costcode,
	orl_event,
	orl_act,
	orl_trade,
	orl_task,
	orl_curr,
	orl_exch,
	decode(orl_rtype,'SF',orl_price,(orl_ordqty / NVL( orl_multiply, 1 ))) IMP_ORDERED,
	decode(orl_rtype,'SF',NVL( orl_recvvalue, 0 ),(NVL(orl_recvqty, 0) / NVL( orl_multiply, 1 ))) IMP_RECEIVED,
	(SELECT NVL( SUM( decode( inv_rtype, 'C', decode( inv_return, '+',
												  decode(orl_rtype,'SF', -ivl_invvalue, -ivl_returnqty),
												  decode(orl_rtype,'SF', -ivl_invvalue, ivl_returnqty)),
				 	  		  			 'D', decode( inv_return, '+',
										 	  	  decode(orl_rtype,'SF', -ivl_invvalue, -ivl_returnqty),
										 	  	  decode(orl_rtype,'SF', -ivl_invvalue, ivl_returnqty )),
										 decode(orl_rtype,'SF', ivl_invvalue, ivl_invqty) ) ), 0 )
	FROM   r5invoices v, r5invoicelines ivl
	WHERE  v.inv_code = ivl.ivl_invoice
	AND    v.inv_org = ivl.ivl_invoice_org
	AND    v.inv_rstatus = 'A'
	AND    ivl.ivl_order = l.ORL_ORDER
	AND    ivl.ivl_ordline = l.ORL_ORDLINE
	AND    ivl.ivl_order_org = l.ORL_ORDER_ORG) IMP_INVOICED,
	orl_tax,
	orl_tax2,
	null ORL_SUPPLIER,
	null ORL_SUPPLIER_ORG,
	ivl_invoice,
	ivl_invoice_org,
	orl_rtype,
	orl_part_org,
	orl_order_org,
	orl_type
from r5invoicelines i, r5orderlines l
where
i.ivl_order = l.orl_order
and i.ivl_order_org = l.orl_order_org
and i.ivl_ordline = l.orl_ordline
UNION ALL
select
	orl_order,
	orl_ordline,
	orl_ref,
	round(nvl(orl_ordqty,0)/nvl(orl_multiply,1), 6) IMP_ORDINVQTY,
	case when orl_rtype = 'SF' then
		(GREATEST( GREATEST( orl_price, NVL( orl_recvvalue, 0 ) ) -
			NVL( (SELECT SUM( ivl_invvalue * DECODE( inv_rtype, 'I', 1, -1 ) )
			FROM  r5invoices,  r5invoicelines
			WHERE	  inv_code = ivl_invoice AND inv_org = ivl_invoice_org AND inv_rstatus <> 'C' AND
			ivl_order = orl_order  AND
			ivl_order_org = orl_order_org  AND ivl_ordline = orl_ordline ), 0 ), 0 )) else
			case when exists(select 1 from r5install where ins_code='INVECINC' and ins_desc in ('NO', 'COPY')) then
				orl_price else
				orl_price * ( 1 - NVL( orl_discperc, 0 ) / 100 ) + ( NVL( orl_totextra, 0 ) / (orl_ordqty / NVL( orl_multiply, 1 )) )
			end
	end IMP_PRICE,
	orl_part,
	orl_costcode,
	orl_event,
	orl_act,
	orl_trade,
	orl_task,
	orl_curr,
	orl_exch,
	decode(orl_rtype,'SF',orl_price,(orl_ordqty / NVL( orl_multiply, 1 ))) IMP_ORDERED,
	decode(orl_rtype,'SF',NVL( orl_recvvalue, 0 ),(NVL(orl_recvqty, 0) / NVL( orl_multiply, 1 ))) IMP_RECEIVED,
	(SELECT NVL( SUM( decode( inv_rtype, 'C', decode( inv_return, '+',
												  decode(orl_rtype,'SF', -ivl_invvalue, -ivl_returnqty),
												  decode(orl_rtype,'SF', -ivl_invvalue, ivl_returnqty)),
				 	  		  			 'D', decode( inv_return, '+',
										 	  	  decode(orl_rtype,'SF', -ivl_invvalue, -ivl_returnqty),
										 	  	  decode(orl_rtype,'SF', -ivl_invvalue, ivl_returnqty )),
										 decode(orl_rtype,'SF', ivl_invvalue, ivl_invqty) ) ),	0 )
	FROM   r5invoices v, r5invoicelines i
	WHERE  v.inv_code = i.ivl_invoice
	AND    v.inv_org = i.ivl_invoice_org
	AND    v.inv_rstatus <> 'C'
	AND    i.ivl_order = l.ORL_ORDER
	AND    i.ivl_ordline = l.ORL_ORDLINE
	AND    i.ivl_order_org = l.ORL_ORDER_ORG) IMP_INVOICED,
	orl_tax,
	orl_tax2,
	orl_supplier,
	orl_supplier_org,
	null ivl_invoice,
	null ivl_invoice_org,
	orl_rtype,
	orl_part_org,
	orl_order_org,
	orl_type
from  r5orderlines l, r5orders o
where
orl_order = ord_code
and ORD_ORG     = ORL_ORDER_ORG
and ORD_RSTATUS = 'A'
AND ORL_RSTATUS in ('A', 'C', 'J')
AND
	(( GREATEST( DECODE( ORL_RSTATUS, 'C', 0 , ORL_ORDQTY ), NVL( ORL_RECVQTY, 0 ) - NVL( orl_scrapqty, 0 ) ) / NVL( orl_multiply, 1 ) >
		( SELECT NVL( SUM( decode( inv_rtype,
		  		 	  	   		   	'C', decode( inv_return, '+',-ivl_returnqty,0),
									'D', decode( inv_return, '+',-ivl_returnqty,0),
									ivl_invqty) ), 0 )
		FROM   r5invoicelines i, r5invoices v
		WHERE  v.inv_code = i.ivl_invoice
		AND v.inv_org = i.ivl_invoice_org
		AND v.inv_rstatus  <> 'C'
		AND i.ivl_order = orl_order
		AND i.ivl_ordline = orl_ordline
		AND i.ivl_order_org = orl_order_org )
	AND ORL_RTYPE <> 'SF' )
	OR
	( GREATEST( DECODE( ORL_RSTATUS, 'C', 0 , ORL_PRICE ), NVL( ORL_RECVVALUE, 0 ) ) >
	( SELECT NVL( SUM( decode( inv_rtype, 'C', -ivl_invvalue, 'D', -ivl_invvalue, ivl_invvalue)), 0 )
	FROM  r5invoicelines i,r5invoices v
	WHERE v.inv_code = i.ivl_invoice
	AND v.inv_org = i.ivl_invoice_org
	AND v.inv_rstatus <> 'C'
	AND i.ivl_order = orl_order
	AND i.ivl_ordline = orl_ordline
	AND i.ivl_order_org = orl_order_org )
	AND ORL_RTYPE = 'SF' ))
)
/
