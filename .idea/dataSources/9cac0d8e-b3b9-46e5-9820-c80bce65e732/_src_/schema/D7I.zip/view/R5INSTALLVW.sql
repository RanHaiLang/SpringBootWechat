CREATE VIEW R5INSTALLVW AS (
SELECT
   ins_code,
   SUBSTR(ins_desc,1,63) ins_desc,
   ins_comment,
   ins_fixed,
   ins_module,
   ins_updatecount
FROM r5install)
/
