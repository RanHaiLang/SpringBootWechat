CREATE VIEW R5INSTOCKCOND AS SELECT p1.par_code, p1.par_org, s1.sto_store, SUM( s2.sto_qty ) qty
FROM   r5stock s2, r5parts p2, r5stock s1, r5parts p1
WHERE  s1.sto_part = p1.par_code
AND    s1.sto_part_org = p1.par_org
AND    p1.par_parentpart IS NOT NULL
AND    p1.par_trackbycondition = '+'
AND    s1.sto_reorderconditions IS NOT NULL
AND    p2.par_parentpart = p1.par_parentpart
AND    p2.par_org = p1.par_org
AND    INSTR( ','||s1.sto_reorderconditions||',', ','||p2.par_condition||',' ) > 0
AND    p2.par_code <> p1.par_code
AND    s2.sto_part = p2.par_code
AND    s2.sto_part_org = p2.par_org
GROUP BY p1.par_code, p1.par_org, s1.sto_store
/
