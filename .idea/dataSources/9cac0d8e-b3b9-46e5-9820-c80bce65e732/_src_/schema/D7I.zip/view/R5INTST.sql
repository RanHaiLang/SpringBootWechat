CREATE VIEW R5INTST AS SELECT tst_part,
       tst_part_org,
       tst_tocode,
       SUM( tst_qty )
FROM   r5transtock
WHERE  tst_order IS NULL
AND    tst_req IS NULL
AND    tst_torentity = 'STOR'
GROUP BY tst_part,
         tst_part_org,
         tst_tocode
/
