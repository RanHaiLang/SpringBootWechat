CREATE VIEW R5INVLINESVIEW AS ( SELECT
  v.inv_code,
  v.inv_org,
  v.inv_date,
  v.inv_type,
  v.inv_status,
  i.ivl_invline,
  i.ivl_order,
  i.ivl_order_org,
  o.ord_date,
  o.ord_supplier,
  o.ord_supplier_org,
  o.ord_buyer,
  o.ord_status,
  i.ivl_ordline,
  l.orl_status,
  i.ivl_invqty,
  i.ivl_invvalue,
  i.ivl_curr,
  i.ivl_discount,
  i.ivl_price,
  i.ivl_totextra,
  i.ivl_tottaxamount
  FROM r5invoicelines i,
       r5invoices     v,
       r5orders       o,
       r5orderlines   l
  WHERE v.inv_code      = i.ivl_invoice
  AND   v.inv_org       = i.ivl_invoice_org
  AND   o.ord_code      = i.ivl_order
  AND   o.ord_org       = i.ivl_order_org
  AND   l.orl_order     = i.ivl_order
  AND   l.orl_order_org = i.ivl_order_org
  AND   l.orl_ordline   = i.ivl_ordline )
/
