CREATE VIEW R5IPCANCELORDERLINES AS SELECT ord.ROWID ord_rowid,
         orl.ROWID orl_rowid,
         mp5i.des_text FROM_LOCATIONID,
         mp5i.des_text CUSTOMERNUM,
         ord.ord_code PONUM,
         ord.ord_supplier VENDORID,
         otr.otr_controlnum POCONFIRMATIONNUM,
         ipv.ipv_desc TO_LOCATIONID,
         orl.orl_ordline ITEMID,
         orl.orl_part ITEMNUM,
         des.des_text DESCRIPTION,
         (orl.orl_ordqty - NVL(orl.orl_recvqty,0) ) QUANTITYCANCELED,
         o7ipgtxt('PORLC', orl.orl_order, orl.orl_order_org, orl.orl_ordline) REASON,
         orl.orl_ordqty QUANTITYORDERED,
         ord.ord_org ORDORG,
         ord.ord_supplier_org VENDORORG,
         orl.orl_part_org ITEMORG,
         ord.ord_date ORDERDATE
    FROM r5orders ord,
         r5orderlines orl,
         r5descriptions mp5i,
         r5descriptions des,
         r5companies com,
         r5ipvendors ipv,
         r5ordertracking otr
   WHERE orl.orl_order = ord.ord_code
     AND orl.orl_order_org = ord.ord_org
     AND ord.ord_supplier = com.com_code                     -- join to MP5i supplier record
     AND ord.ord_supplier_org = com.com_org                  -- join to MP5i supplier record
     AND com.com_ipvendor = ipv.ipv_code
     AND mp5i.des_rentity = 'COMP'   -- join to descriptions to retrieve customer name (from org)
     AND mp5i.des_code = '*'
     AND mp5i.des_org = com.com_org
     AND mp5i.des_lang = 'EN'
     AND mp5i.des_rtype = '*'
     AND ord.ord_code = otr.otr_order
     AND ord.ord_org  = otr.otr_order_org
     AND otr.otr_tracktype = 'POTR'
     AND des.des_rentity = 'PART'
     AND des.des_code = orl.orl_part
     AND des.des_org = orl.orl_part_org
     AND des.des_lang = 'EN'
     AND des.des_rtype = '*'
     AND NOT EXISTS( SELECT 'x'
                     FROM   r5ordertracking otr2
                     WHERE  ord.ord_code = otr2.otr_order
                     AND    ord.ord_org  = otr2.otr_order_org
                     AND    otr2.otr_tracktype = 'POTR'
                     AND    otr2.otr_gendate > otr.otr_gendate )
    AND orl_rstatus = 'C'
    AND orl_rtype IN ('PS', 'PD')
/
