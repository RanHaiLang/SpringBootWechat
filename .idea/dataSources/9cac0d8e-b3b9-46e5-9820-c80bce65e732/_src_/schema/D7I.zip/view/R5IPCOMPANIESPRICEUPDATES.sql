CREATE VIEW R5IPCOMPANIESPRICEUPDATES AS SELECT com.rowid dtl_rowid,
         cat.rowid cat_rowid,
         rowidtochar(com.rowid) || rowidtochar(cat.rowid) mp2itemid,
         RPAD(cat.cat_puruom, 50, ' ') uow,
         cat.cat_purprice unitcost,
         cat.cat_leadtime leadtime,
         cat.cat_desc defaultdescription,
         com_ipvendor defaultvendor,
         cat.cat_ref vendoritemnum,
         uog.uog_user, uog.uog_group, com."COM_CODE",com."COM_DESC",com."COM_CLASS",com."COM_CONTACT",com."COM_OURCONT",com."COM_CURR",com."COM_LANG",com."COM_LEADTIME",com."COM_MAXORD",com."COM_MINORD",com."COM_STATUS",com."COM_PHONE",com."COM_FAX",com."COM_BUYER",com."COM_PARENT",com."COM_PAYMENTTERMS",com."COM_FREIGHTTERMS",com."COM_SHIPVIA",com."COM_FOBPOINT",com."COM_PURCHASESITE",com."COM_MINORITYGROUP",com."COM_EDINO",com."COM_TYPE1099",com."COM_SOURCESYSTEM",com."COM_SOURCECODE",com."COM_INTERFACE",com."COM_NOTUSED",com."COM_CAPACITY",com."COM_PEOPLE",com."COM_ORG",com."COM_CLASS_ORG",com."COM_PARENT_ORG",com."COM_EMAIL",com."COM_IPVENDOR",com."COM_PAYBYMETHOD",com."COM_IPACCOUNT",com."COM_IPRESPONSE",com."COM_UPDATECOUNT",com."COM_CREATED",com."COM_UPDATED",com."COM_LASTSTATUSUPDATE",com."COM_UDFCHAR01",com."COM_UDFCHAR02",com."COM_UDFCHAR03",com."COM_UDFCHAR04",com."COM_UDFCHAR05",com."COM_UDFCHAR06",com."COM_UDFCHAR07",com."COM_UDFCHAR08",com."COM_UDFCHAR09",com."COM_UDFCHAR10",com."COM_UDFCHAR11",com."COM_UDFCHAR12",com."COM_UDFCHAR13",com."COM_UDFCHAR14",com."COM_UDFCHAR15",com."COM_UDFCHAR16",com."COM_UDFCHAR17",com."COM_UDFCHAR18",com."COM_UDFCHAR19",com."COM_UDFCHAR20",com."COM_UDFCHAR21",com."COM_UDFCHAR22",com."COM_UDFCHAR23",com."COM_UDFCHAR24",com."COM_UDFCHAR25",com."COM_UDFCHAR26",com."COM_UDFCHAR27",com."COM_UDFCHAR28",com."COM_UDFCHAR29",com."COM_UDFCHAR30",com."COM_UDFNUM01",com."COM_UDFNUM02",com."COM_UDFNUM03",com."COM_UDFNUM04",com."COM_UDFNUM05",com."COM_UDFDATE01",com."COM_UDFDATE02",com."COM_UDFDATE03",com."COM_UDFDATE04",com."COM_UDFDATE05",com."COM_UDFCHKBOX01",com."COM_UDFCHKBOX02",com."COM_UDFCHKBOX03",com."COM_UDFCHKBOX04",com."COM_UDFCHKBOX05",com."COM_CUSTOMER",com."COM_ACCOUNTCODE",com."COM_COSTCENTER",com."COM_TAX",com."COM_GROUPPURCHASINGORG1",com."COM_GROUPPURCHASINGORG2"
    FROM r5companies com,
         r5ippermissions ipp,
         r5ipgrouppermissions ipg,
         r5userorganization uog,
         r5catalogue cat
   WHERE com_ipvendor IS NOT NULL
     AND com.com_code = cat.cat_supplier
     AND com.com_org = cat.cat_supplier_org
     AND com.com_org = uog.uog_org
     AND uog.uog_group = ipg.ipg_group
     AND ipp_mnemonic = 'SMSUPP'
     AND ipg_permission = ipp.ipp_code
     AND cat.cat_ref IS NOT NULL
     AND ipp.ipp_function = 5
/
