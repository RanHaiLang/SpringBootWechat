CREATE VIEW R5IPORDERLINEAVAIL AS SELECT orl.ROWID orl_rowid,
       site.des_text SITENAME,
       mp5i.des_text COMPANYNAME,
       mp5i.des_text FROM_LOCATIONID,
       ipv.ipv_desc  TO_LOCATIONID,
       NVL(pord.adr_address1, NVL(poed.adr_address1, NVL(strd.adr_address1, deli.adr_address1 ))) SHIPTO_ADDRESS1,
       DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_address2, strd.adr_address2),poed.adr_address2) , pord.adr_address2  ) SHIPTO_ADDRESS2,
       DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_address3, strd.adr_address3),poed.adr_address3) , pord.adr_address3 ) SHIPTO_ADDRESS3,
       DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_city, strd.adr_city),poed.adr_city) , pord.adr_city ) SHIPTO_CITY,
       DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_state, strd.adr_state),poed.adr_state) , pord.adr_state ) SHIPTO_STATE,
       DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_zip, strd.adr_zip),poed.adr_zip) , pord.adr_zip ) SHIPTO_ZIP
  FROM r5orders ord,
       r5orderlines orl,
       r5companies com,
       r5descriptions mp5i,
       r5descriptions site,
       r5ipvendors ipv,
       r5address poed,
       r5address strd,
       r5address pord,
       r5address deli,
       r5entities ent
WHERE  ord.ord_code = orl.orl_order
   AND ord.ord_org = orl.orl_order_org
   AND ord.ord_supplier = com.com_code
   AND ord.ord_supplier_org = com.com_org
   AND com.com_ipvendor = ipv.ipv_code
   AND ent.ent_table = 'R5ORDERS'
   AND mp5i.des_rentity = 'COMP'
   AND mp5i.des_code = '*'
   AND mp5i.des_org = com.com_org
   AND mp5i.des_rtype = '*'
   AND mp5i.des_lang = 'EN'
   AND site.des_rentity = 'ORG'
   AND site.des_code = ord.ord_org
   AND site.des_org = '*'
   AND site.des_lang = 'EN'
   AND site.des_rtype = '*'
   AND deli.adr_code (+) = '*#' || com.com_org
   AND deli.adr_rentity (+) = 'COMP'
   AND deli.adr_rtype (+) = 'D'
   AND strd.adr_code (+)  = ord.ord_store
   AND strd.adr_rentity  (+)  = 'STOR'
   AND strd.adr_rtype (+)  = 'D'
   AND poed.adr_code (+) = ent.ent_rentity
   AND poed.adr_rentity (+) = 'ENT'
   AND poed.adr_rtype (+) = 'D'
   AND pord.adr_code (+) = ord.ord_code||'#'||ord.ord_org
   AND pord.adr_rentity (+) = 'PORD'
   AND pord.adr_rtype (+) = 'D'
   AND NOT (deli.adr_code IS NULL AND poed.adr_code IS NULL AND strd.adr_code IS NULL AND pord.adr_code IS NULL)
   AND orl_rstatus = 'U'
   AND orl_rtype IN ('PD', 'PS')
/
