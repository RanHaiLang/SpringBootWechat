CREATE VIEW R5IPORDERLINES AS SELECT ord.ROWID ord_rowid,
         orl.orl_ordline MP2ITEMID,
         orl.orl_part USERITEMNUM,
         SUBSTR( par_desc, 1, DECODE( INSTR( par_desc, '::SupplierSessionID' ), '0', 81,
                 INSTR( par_desc, '::SupplierSessionID' ) ) - 1 )||
                 SUBSTR( cat_desc, DECODE( INSTR( cat_desc, '::SupplierSessionID' ), 0, 2001,
                 INSTR( cat_desc, '::SupplierSessionID' ) ), 2000 ) DESCRIPTION,
         o7ipgtxt('PORL',orl.orl_order, orl.orl_order_org, orl_ordline) ITEMCOMMENTS,
         orl.orl_ordqty / NVL ( orl.orl_multiply, 1 ) QUANTITYREQUESTED,
         TO_CHAR ( orl.orl_due, 'MM/DD/YYYY' ) DUEDATE,
         NVL ( orl.orl_puruom, 'EA' ) UOP,
         orl.orl_price UNITCOST,
         NVL ( orl.orl_ordqty / NVL ( orl.orl_multiply, 1 ) * orl.orl_price, 0 ) TOTAL,
         NVL(orl.orl_ref, NVL ( DECODE( orl.orl_rtype, 'RE', cat.cat_repref, cat.cat_ref ), '' )) VENDORITEMNUM,
         orl_costcode COSTCENTER
  FROM   r5orders ord, r5orderlines orl, r5parts par, r5catalogue cat
  WHERE  orl.orl_order = ord.ord_code
  AND    orl.orl_order_org = ord.ord_org
  AND    orl.orl_part = par.par_code
  AND    orl.orl_part_org = par.par_org
  AND    orl.orl_part = cat.cat_part
  AND    orl.orl_part_org = cat.cat_part_org
  AND    orl.orl_supplier = cat.cat_supplier
  AND    orl.orl_supplier_org = cat.cat_supplier_org
  AND    orl.orl_rtype IN ('PD', 'PS', 'RE')
  AND    orl.orl_rstatus = 'A'
  AND   (orl.orl_ref IS NOT NULL OR DECODE( orl.orl_rtype, 'RE', cat.cat_repref, cat.cat_ref ) IS NOT NULL)
/
