CREATE VIEW R5IPORDERS AS SELECT ord.ROWID ord_rowid,
       site.des_text SITENAME,
       mp5i.des_text CUSTOMERNAME,
       mail.adr_address1 MAIL_ADDRESS1,
       mail.adr_address2 MAIL_ADDRESS2,
       mail.adr_address3 MAIL_ADDRESS3,
       mail.adr_city MAIL_CITY,
       mail.adr_state MAIL_STATE,
       mail.adr_zip MAIL_ZIP,
       NVL( mail.adr_country, '-' ) MAIL_COUNTRY,
       mail.adr_phone MAIL_PHONE,
       mail.adr_phoneextn MAIL_EXT,
       mail.adr_fax MAIL_FAX,
       mail.adr_email MAIL_EMAIL,
       NVL ( buyer.des_text, '-' ) BILL_ATTENTIONOF,
       NVL(poei.adr_address1, NVL(stri.adr_address1, bill.adr_address1 )) BILL_ADDRESS1,
       DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_address2,stri.adr_address2) , poei.adr_address2  ) BILL_ADDRESS2,
       DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_address3,stri.adr_address3), poei.adr_address3 ) BILL_ADDRESS3,
       DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_city, stri.adr_city), poei.adr_city ) BILL_CITY,
       DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_state, stri.adr_state), poei.adr_state ) BILL_STATE,
       DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_zip, stri.adr_zip),  poei.adr_zip) BILL_ZIP,
       DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_country, stri.adr_country), poei.adr_country)  BILL_COUNTRY,
       DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_phone, stri.adr_phone), poei.adr_phone)  BILL_PHONE,
       DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_phoneextn, stri.adr_phoneextn), poei.adr_phoneextn) BILL_EXT,
       DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_fax, stri.adr_fax), poei.adr_fax) BILL_FAX,
       DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_email, stri.adr_email), poei.adr_email) BILL_EMAIL,
       com.com_ipvendor VENDORNUM,
       NVL ( buyer.des_text, '-' )  DELI_ATTENTIONOF,                                                 -- buyer name
       NVL( pode.dad_address1, NVL(pord.adr_address1, NVL(poed.adr_address1, NVL(strd.adr_address1, deli.adr_address1 )))) DELI_ADDRESS1,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_address2, strd.adr_address2),poed.adr_address2) , pord.adr_address2 ), pode.dad_address2 )  DELI_ADDRESS2,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_address3, strd.adr_address3),poed.adr_address3) , pord.adr_address3 ), pode.dad_address3 )  DELI_ADDRESS3,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_city, strd.adr_city),poed.adr_city) , pord.adr_city ), pode.dad_city )  DELI_CITY,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_state, strd.adr_state),poed.adr_state) , pord.adr_state ), pode.dad_state )  DELI_STATE,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_zip, strd.adr_zip),poed.adr_zip) , pord.adr_zip ), pode.dad_zip)  DELI_ZIP,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, NVL( deli.adr_country, '-' ), strd.adr_country), poed.adr_country) , pord.adr_country ), pode.dad_country )   DELI_COUNTRY,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, NVL( deli.adr_phone, '-' ), strd.adr_phone), poed.adr_phone) , pord.adr_phone ), pode.dad_phone )  DELI_PHONE,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, NVL( deli.adr_phoneextn, '-' ), strd.adr_phoneextn),poed.adr_phoneextn) , pord.adr_phoneextn ), pode.dad_phoneextn ) DELI_EXT,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, NVL( deli.adr_fax, '-' ), strd.adr_fax), poed.adr_fax) , pord.adr_fax ), pode.dad_fax )  DELI_FAX,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, NVL( deli.adr_email, '-' ), strd.adr_email), poed.adr_email) , pord.adr_email ), pode.dad_email )  DELI_EMAIL,
       NVL ( buyer.des_text, '-' ) CONFIRM_ATTENTIONOF,
       NVL(poem.adr_address1, NVL(strm.adr_address1, mail.adr_address1 ))CONFIRM_ADDRESS1,
       DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_address2,strm.adr_address2) , poem.adr_address2  ) CONFIRM_ADDRESS2,
       DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_address3,strm.adr_address3), poem.adr_address3 ) CONFIRM_ADDRESS3,
       DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_city, strm.adr_city), poem.adr_city ) CONFIRM_CITY,
       DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_state, strm.adr_state), poem.adr_state ) CONFIRM_STATE,
       DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_zip, strm.adr_zip),  poem.adr_zip) CONFIRM_ZIP,
       DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_country, strm.adr_country), poem.adr_country)  CONFIRM_COUNTRY,
       DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_phone, strm.adr_phone),  poem.adr_phone) CONFIRM_PHONE,
       DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_phoneextn, strm.adr_phoneextn),  poem.adr_phoneextn)  CONFIRM_EXT,
       DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_fax, strm.adr_fax),  poem.adr_fax) CONFIRM_FAX,
       DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_email, strm.adr_email),  poem.adr_email) CONFIRM_EMAIL,
       com.com_ipaccount ACCOUNTNUM,
       DECODE(str.str_copy,'Y', 'Y', 'Y') VALIDATEBEFORESUBMIT,
       str.str_desc PURCHASINGCENTER,
       ord.ord_code PONUM,
       ord.ord_desc PODESC,
       NVL ( ord.ord_revision, 1) RELEASENUM,
       status.des_text POSTATUS,
       ptype.des_text POTYPE,
       NVL ( buyer.des_text, '-' ) BUYER,                                                 -- buyer name
       ord.ord_origin ORIGINATOR,
       NVL(buy.adr_address1, NVL(mail.adr_address1 , '-' )) BUYER_ADDRESS1,
       DECODE(buy.adr_address1, NULL, mail.adr_address2, buy.adr_address2) BUYER_ADDRESS2,
       DECODE(buy.adr_address1, NULL, mail.adr_address3, buy.adr_address3) BUYER_ADDRESS3,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_city, '-' ), buy.adr_city) BUYER_CITY,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_state, '-' ), buy.adr_state) BUYER_STATE,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_zip, '-' ), buy.adr_zip) BUYER_ZIP,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_country, '-' ), buy.adr_country) BUYER_COUNTRY,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_phone, '-' ), buy.adr_phone) BUYER_PHONE,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_phoneextn, '-' ), buy.adr_phoneextn) BUYER_EXT,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_fax, '-' ), buy.adr_fax) BUYER_FAX,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_email, '-' ), buy.adr_email) BUYER_EMAIL,
       ord.ord_curr MP2CURRENCY,
       ord.ord_exch EXCHANGERATE,
       TO_CHAR ( ord.ord_date, 'MM/DD/YYYY' ) ORDERDATE,
       DECODE(str.str_copy,'Y', 'Y', 'Y') ACKREQUIRED,
       ipv.ipv_desc MP2VENDORNAME,
       o7ipgtxt('PORD', ord.ord_code, ord.ord_org) NOTES,
       o7ipgtcl( ord.ord_code, ord.ord_org) CLAUSE,
       DECODE(com.com_ipaccount, NULL,crd.crd_creditcard, NULL) CREDITCARD,
       DECODE(com.com_ipaccount, NULL,crd.crd_four, NULL) CREDITFOUR,
       DECODE(com.com_ipaccount, NULL,TO_CHAR(crd.crd_expdate, 'MM/DD/RRRR'), NULL) EXPIRATION,
       DECODE(com.com_ipaccount, NULL,crd.crd_nameoncard, NULL) NAMEONCARD,
       DECODE(com.com_ipaccount, NULL,NVL ( buyer.des_text, '-' ), NULL) CREDIT_ATTENTIONOF,                  -- buyer name
       DECODE(com.com_ipaccount, NULL,credit.adr_address1, NULL) CREDIT_ADDRESS1,
       DECODE(com.com_ipaccount, NULL,credit.adr_address2, NULL) CREDIT_ADDRESS2,
       DECODE(com.com_ipaccount, NULL,credit.adr_address3, NULL) CREDIT_ADDRESS3,
       DECODE(com.com_ipaccount, NULL,credit.adr_city, NULL) CREDIT_CITY,
       DECODE(com.com_ipaccount, NULL,credit.adr_state, NULL) CREDIT_STATE,
       DECODE(com.com_ipaccount, NULL,credit.adr_zip, NULL) CREDIT_ZIP,
       DECODE(com.com_ipaccount, NULL,NVL( credit.adr_country, '-' ), NULL) CREDIT_COUNTRY,
       DECODE(com.com_ipaccount, NULL,credit.adr_phone, NULL) CREDIT_PHONE,
       DECODE(com.com_ipaccount, NULL,credit.adr_phoneextn, NULL) CREDIT_EXT,
       DECODE(com.com_ipaccount, NULL,credit.adr_fax, NULL) CREDIT_FAX,
       DECODE(com.com_ipaccount, NULL,credit.adr_email, NULL) CREDIT_EMAIL,
       ord.ord_shipvia shipviacodenum
  FROM r5orders ord,
       r5address bill,
       r5address mail,
       r5address deli,
       r5address buy,
       r5address credit,
       r5address poem,
       r5address strm,
       r5address poei,
       r5address stri,
       r5address poed,
       r5address strd,
       r5address pord,
       r5companies com,
       r5ipvendors ipv,
       r5descriptions mp5i,
       r5descriptions status,
       r5descriptions ptype,
       r5descriptions buyer,
       r5descriptions site,
       r5stores str,
       r5entities ent,
       r5creditcards crd,
       r5deladdresses pode
 WHERE ord.ord_supplier = com.com_code
   AND ord.ord_supplier_org = com.com_org
   AND com.com_ipvendor = ipv.ipv_code
   AND ord.ord_store = str.str_code
   AND ent.ent_table = 'R5ORDERS'
   AND mail.adr_code (+) = '*#' || com.com_org
   AND mail.adr_rentity (+) = 'COMP'
   AND mail.adr_rtype (+) = 'M'
   AND poem.adr_code  (+) = ent.ent_rentity
   AND poem.adr_rentity (+)  = 'ENT'
   AND poem.adr_rtype (+)  = 'M'
   AND strm.adr_code (+)  = ord.ord_store
   AND strm.adr_rentity  (+)  = 'STOR'
   AND strm.adr_rtype (+)  = 'M'
   AND NOT (mail.adr_address1 IS NULL AND poem.adr_address1 IS NULL AND strm.adr_address1 IS NULL)
   AND bill.adr_code (+) = '*#' || com.com_org
   AND bill.adr_rentity (+) = 'COMP'
   AND bill.adr_rtype (+) = 'I'
   AND poei.adr_code (+) = ent.ent_rentity
   AND poei.adr_rentity (+) = 'ENT'
   AND poei.adr_rtype (+) = 'I'
   AND stri.adr_code (+)  = ord.ord_store
   AND stri.adr_rentity  (+)  = 'STOR'
   AND stri.adr_rtype (+)  = 'I'
   AND NOT (bill.adr_address1 IS NULL AND poei.adr_address1 IS NULL AND stri.adr_address1 IS NULL)
   AND deli.adr_code (+) = '*#' || com.com_org
   AND deli.adr_rentity (+) = 'COMP'
   AND deli.adr_rtype (+) = 'D'
   AND strd.adr_code (+)  = ord.ord_store
   AND strd.adr_rentity  (+)  = 'STOR'
   AND strd.adr_rtype (+)  = 'D'
   AND poed.adr_code (+) = ent.ent_rentity
   AND poed.adr_rentity (+) = 'ENT'
   AND poed.adr_rtype (+) = 'D'
   AND pord.adr_code (+) = ord.ord_code||'#'||ord.ord_org
   AND pord.adr_rentity (+) = 'PORD'
   AND pord.adr_rtype (+) = 'D'
   AND  ord.ord_deladdress = pode.dad_code (+)
   AND NOT (deli.adr_address1 IS NULL AND poed.adr_address1 IS NULL AND strd.adr_address1 IS NULL AND pord.adr_address1 IS NULL AND ord.ord_deladdress IS NULL )
   AND buy.adr_code (+) = ord.ord_buyer
   AND buy.adr_rentity (+) = 'USER'
   AND buy.adr_rtype (+) = 'M'
   AND mp5i.des_rentity = 'COMP'
   AND mp5i.des_code = '*'
   AND mp5i.des_org = com.com_org
   AND mp5i.des_lang = 'EN'
   AND mp5i.des_rtype = '*'
   AND site.des_rentity = 'ORG'                              -- join to descriptions to retrieve site name
   AND site.des_code = ord.ord_org
   AND site.des_org = '*'
   AND site.des_lang = 'EN'
   AND site.des_rtype = '*'
   AND status.des_rentity = 'UCOD'
   AND status.des_code = ord.ord_status
   AND status.des_org = '*'
   AND status.des_lang = 'EN'
   AND status.des_rtype = 'DOST'
   AND ptype.des_rentity = 'UCOD'
   AND ptype.des_code = ord.ord_type
   AND ptype.des_org = '*'
   AND ptype.des_lang = 'EN'
   AND ptype.des_rtype = 'POTP'
   AND buyer.des_code (+) = ord.ord_buyer
   AND buyer.des_org (+) = '*'
   AND buyer.des_lang (+) = 'EN'
   AND buyer.des_rtype (+) = '*'
   AND buyer.des_rentity (+) = 'USER'
   AND crd.crd_code(+) = ord_creditcard
   AND credit.adr_code(+) = to_char(crd.crd_code)      -- retrieve credit card mail address
   AND credit.adr_rentity(+) = 'CARD'
   AND credit.adr_rtype(+) = 'M'
   AND(  com.com_ipaccount IS NOT NULL
      OR ord_creditcard    IS NOT NULL )
   AND ord.ord_iptransmitted = '-'
   AND ord.ord_rstatus = 'A'
   AND NOT EXISTS (
      SELECT 'x'
      FROM r5ordertracking otr
      WHERE ord.ord_code = otr.otr_order
      AND   ord.ord_org = otr.otr_order_org
      AND   ord.ord_revision = otr.otr_releasenum
      AND   otr.otr_tracktype = 'POTR' )
   AND NOT EXISTS
    ( SELECT 'x'
      FROM r5orderlines
      WHERE orl_order             = ord_code
      AND   orl_order_org         = ord_org
      AND   orl_rstatus           = 'A'
      AND ( NVL( orl_recvqty, 0 ) > 0
       OR   EXISTS ( SELECT 'x'
                     FROM r5translines l,
                          r5transactions t
                     WHERE trl_order      = orl_order
                     AND   trl_order_org  = orl_order_org
                     AND   trl_trans      = tra_code
                     AND   tra_rstatus   <> 'C'
                     AND   trl_qty        > 0 ) ) )
/
