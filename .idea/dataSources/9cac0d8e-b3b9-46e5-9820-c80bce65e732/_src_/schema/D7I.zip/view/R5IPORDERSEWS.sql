CREATE VIEW R5IPORDERSEWS AS SELECT ord.ord_org POORG,
       site.des_text SITENAME,
       mp5i.des_text CUSTOMERNAME,
       mail.adr_address1 MAIL_ADDRESS1,
       mail.adr_address2 MAIL_ADDRESS2,
       mail.adr_address3 MAIL_ADDRESS3,
       mail.adr_city MAIL_CITY,
       mail.adr_state MAIL_STATE,
       mail.adr_zip MAIL_ZIP,
       NVL( mail.adr_country, '-' ) MAIL_COUNTRY,
       mail.adr_phone MAIL_PHONE,
       mail.adr_phoneextn MAIL_EXT,
       mail.adr_fax MAIL_FAX,
       mail.adr_email MAIL_EMAIL,
       NVL(ord.ord_attentionto, '-') BILL_ATTENTIONOF,
       NVL(pori.adr_address1, NVL(poei.adr_address1, NVL(stri.adr_address1, bill.adr_address1 ))) BILL_ADDRESS1,
       DECODE(pori.adr_address1, NULL, DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_address2,stri.adr_address2) , poei.adr_address2  ), pori.adr_address2) BILL_ADDRESS2,
       DECODE(pori.adr_address1, NULL, DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_address3,stri.adr_address3), poei.adr_address3 ), pori.adr_address3) BILL_ADDRESS3,
       DECODE(pori.adr_address1, NULL, DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_city, stri.adr_city), poei.adr_city ), pori.adr_city) BILL_CITY,
       DECODE(pori.adr_address1, NULL, DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_state, stri.adr_state), poei.adr_state ), pori.adr_state) BILL_STATE,
       DECODE(pori.adr_address1, NULL, DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_zip, stri.adr_zip),  poei.adr_zip), pori.adr_zip) BILL_ZIP,
       DECODE(pori.adr_address1, NULL, DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_country, stri.adr_country), poei.adr_country), pori.adr_country)  BILL_COUNTRY,
       DECODE(pori.adr_address1, NULL, DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_phone, stri.adr_phone), poei.adr_phone), pori.adr_phone)  BILL_PHONE,
       DECODE(pori.adr_address1, NULL, DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_phoneextn, stri.adr_phoneextn), poei.adr_phoneextn), pori.adr_phoneextn) BILL_EXT,
       DECODE(pori.adr_address1, NULL, DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_fax, stri.adr_fax), poei.adr_fax), pori.adr_fax) BILL_FAX,
       DECODE(pori.adr_address1, NULL, DECODE(poei.adr_address1, NULL, DECODE(stri.adr_address1, NULL, bill.adr_email, stri.adr_email), poei.adr_email), pori.adr_email) BILL_EMAIL,
       com.com_ipvendor VENDORNUM,
       NVL(ord.ord_attentionto, '-')  DELI_ATTENTIONOF,                                                 -- buyer name
       NVL( pode.dad_address1, NVL(pord.adr_address1, NVL(poed.adr_address1, NVL(strd.adr_address1, deli.adr_address1 )))) DELI_ADDRESS1,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_address2, strd.adr_address2),poed.adr_address2) , pord.adr_address2 ), pode.dad_address2 )  DELI_ADDRESS2,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_address3, strd.adr_address3),poed.adr_address3) , pord.adr_address3 ), pode.dad_address3 )  DELI_ADDRESS3,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_city, strd.adr_city),poed.adr_city) , pord.adr_city ), pode.dad_city )  DELI_CITY,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_state, strd.adr_state),poed.adr_state) , pord.adr_state ), pode.dad_state )  DELI_STATE,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_zip, strd.adr_zip),poed.adr_zip) , pord.adr_zip ), pode.dad_zip)  DELI_ZIP,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, NVL( deli.adr_country, '-' ), strd.adr_country), poed.adr_country) , pord.adr_country ), pode.dad_country )   DELI_COUNTRY,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, NVL( deli.adr_phone, '-' ), strd.adr_phone), poed.adr_phone) , pord.adr_phone ), pode.dad_phone )  DELI_PHONE,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, NVL( deli.adr_phoneextn, '-' ), strd.adr_phoneextn),poed.adr_phoneextn) , pord.adr_phoneextn ), pode.dad_phoneextn ) DELI_EXT,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, NVL( deli.adr_fax, '-' ), strd.adr_fax), poed.adr_fax) , pord.adr_fax ), pode.dad_fax )  DELI_FAX,
       DECODE( ord.ord_deladdress, NULL, DECODE(pord.adr_address1, NULL, DECODE(poed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, NVL( deli.adr_email, '-' ), strd.adr_email), poed.adr_email) , pord.adr_email ), pode.dad_email )  DELI_EMAIL,
       NVL(ord.ord_attentionto, '-') CONFIRM_ATTENTIONOF,
       NVL(porm.adr_address1, NVL(poem.adr_address1, NVL(strm.adr_address1, mail.adr_address1 ))) CONFIRM_ADDRESS1,
       DECODE(porm.adr_address1, NULL, DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_address2,strm.adr_address2) , poem.adr_address2  ),porm.adr_address2) CONFIRM_ADDRESS2,
       DECODE(porm.adr_address1, NULL, DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_address3,strm.adr_address3), poem.adr_address3 ),porm.adr_address3) CONFIRM_ADDRESS3,
       DECODE(porm.adr_address1, NULL, DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_city, strm.adr_city), poem.adr_city ),porm.adr_city) CONFIRM_CITY,
       DECODE(porm.adr_address1, NULL, DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_state, strm.adr_state), poem.adr_state ) ,porm.adr_state) CONFIRM_STATE,
       DECODE(porm.adr_address1, NULL, DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_zip, strm.adr_zip),  poem.adr_zip),porm.adr_zip) CONFIRM_ZIP,
       DECODE(porm.adr_address1, NULL, DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_country, strm.adr_country), poem.adr_country),porm.adr_country)  CONFIRM_COUNTRY,
       DECODE(porm.adr_address1, NULL, DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_phone, strm.adr_phone),  poem.adr_phone),porm.adr_phone) CONFIRM_PHONE,
       DECODE(porm.adr_address1, NULL, DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_phoneextn, strm.adr_phoneextn),  poem.adr_phoneextn),porm.adr_phoneextn)  CONFIRM_EXT,
       DECODE(porm.adr_address1, NULL, DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_fax, strm.adr_fax),  poem.adr_fax),porm.adr_fax) CONFIRM_FAX,
       DECODE(porm.adr_address1, NULL, DECODE(poem.adr_address1, NULL, DECODE(strm.adr_address1, NULL, mail.adr_email, strm.adr_email),  poem.adr_email),porm.adr_email) CONFIRM_EMAIL,
       COALESCE(acct.san_ipaccount,com.com_ipaccount) ACCOUNTNUM,
       DECODE(str.str_copy,'Y', 'Y', 'Y') VALIDATEBEFORESUBMIT,
       str.str_desc PURCHASINGCENTER,
       ord.ord_code PONUM,
       ord.ord_desc PODESC,
       NVL ( ord.ord_revision, 1) RELEASENUM,
       status.des_text POSTATUS,
       ptype.des_text POTYPE,
       NVL ( r5o7.o7get_desc(ins.ins_desc,'USER',ord.ord_buyer, '*','*'), '-' ) BUYER,                                                 -- buyer name
       NVL(ord.ord_attentionto,ord.ord_origin) ORIGINATOR,
       NVL(buy.adr_address1, NVL(mail.adr_address1 , '-' )) BUYER_ADDRESS1,
       DECODE(buy.adr_address1, NULL, mail.adr_address2, buy.adr_address2) BUYER_ADDRESS2,
       DECODE(buy.adr_address1, NULL, mail.adr_address3, buy.adr_address3) BUYER_ADDRESS3,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_city, '-' ), buy.adr_city) BUYER_CITY,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_state, '-' ), buy.adr_state) BUYER_STATE,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_zip, '-' ), buy.adr_zip) BUYER_ZIP,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_country, '-' ), buy.adr_country) BUYER_COUNTRY,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_phone, '-' ), buy.adr_phone) BUYER_PHONE,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_phoneextn, '-' ), buy.adr_phoneextn) BUYER_EXT,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_fax, '-' ), buy.adr_fax) BUYER_FAX,
       DECODE(buy.adr_address1, NULL, NVL( mail.adr_email, '-' ), buy.adr_email) BUYER_EMAIL,
       ord.ord_curr MP2CURRENCY,
       ord.ord_exch EXCHANGERATE,
       TO_CHAR ( ord.ord_date, 'MM/DD/YYYY' ) ORDERDATE,
       DECODE(str.str_copy,'Y', 'Y', 'Y') ACKREQUIRED,
       ipv.ipv_desc MP2VENDORNAME,
       o7ipgtxt('PORD', ord.ord_code, ord.ord_org) NOTES,
       o7ipgtcl( ord.ord_code, ord.ord_org) CLAUSE,
       crd.crd_creditcard CREDITCARD,
       crd.crd_four CREDITFOUR,
       TO_CHAR(crd.crd_expdate, 'MM/DD/RRRR') EXPIRATION,
       crd.crd_nameoncard NAMEONCARD,
       crd.crd_desc CREDITCARDDESC,
       NVL (ord.ord_attentionto, '-' ) CREDIT_ATTENTIONOF,                  -- buyer name
       credit.adr_address1 CREDIT_ADDRESS1,
       credit.adr_address2 CREDIT_ADDRESS2,
       credit.adr_address3 CREDIT_ADDRESS3,
       credit.adr_city CREDIT_CITY,
       credit.adr_state CREDIT_STATE,
       credit.adr_zip CREDIT_ZIP,
       NVL( credit.adr_country, '-' ) CREDIT_COUNTRY,
       credit.adr_phone CREDIT_PHONE,
       credit.adr_phoneextn CREDIT_EXT,
       credit.adr_fax CREDIT_FAX,
       credit.adr_email CREDIT_EMAIL,
       ord.ord_shipvia shipviacodenum,
       ord.ORD_UDFCHAR01 UDFCHAR01,
       ord.ORD_UDFCHAR02 UDFCHAR02,
       ord.ORD_UDFCHAR03 UDFCHAR03,
       ord.ORD_UDFCHAR04 UDFCHAR04,
       ord.ORD_UDFCHAR05 UDFCHAR05,
       ord.ORD_UDFCHAR06 UDFCHAR06,
       ord.ORD_UDFCHAR07 UDFCHAR07,
       ord.ORD_UDFCHAR08 UDFCHAR08,
       ord.ORD_UDFCHAR09 UDFCHAR09,
       ord.ORD_UDFCHAR10 UDFCHAR10,
       ord.ORD_UDFCHAR11 UDFCHAR11,
       ord.ORD_UDFCHAR12 UDFCHAR12,
       ord.ORD_UDFCHAR13 UDFCHAR13,
       ord.ORD_UDFCHAR14 UDFCHAR14,
       ord.ORD_UDFCHAR15 UDFCHAR15,
       ord.ORD_UDFCHAR16 UDFCHAR16,
       ord.ORD_UDFCHAR17 UDFCHAR17,
       ord.ORD_UDFCHAR18 UDFCHAR18,
       ord.ORD_UDFCHAR19 UDFCHAR19,
       ord.ORD_UDFCHAR20 UDFCHAR20,
       ord.ORD_UDFCHAR21 UDFCHAR21,
       ord.ORD_UDFCHAR22 UDFCHAR22,
       ord.ORD_UDFCHAR23 UDFCHAR23,
       ord.ORD_UDFCHAR24 UDFCHAR24,
       ord.ORD_UDFCHAR25 UDFCHAR25,
       ord.ORD_UDFCHAR26 UDFCHAR26,
       ord.ORD_UDFCHAR27 UDFCHAR27,
       ord.ORD_UDFCHAR28 UDFCHAR28,
       ord.ORD_UDFCHAR29 UDFCHAR29,
       ord.ORD_UDFCHAR30 UDFCHAR30,
       ord.ORD_UDFNUM01 UDFNUM01,
       ord.ORD_UDFNUM02 UDFNUM02,
       ord.ORD_UDFNUM03 UDFNUM03,
       ord.ORD_UDFNUM04 UDFNUM04,
       ord.ORD_UDFNUM05 UDFNUM05,
       ord.ORD_UDFDATE01 UDFDATE01,
       ord.ORD_UDFDATE02 UDFDATE02,
       ord.ORD_UDFDATE03 UDFDATE03,
       ord.ORD_UDFDATE04 UDFDATE04,
       ord.ORD_UDFDATE05 UDFDATE05,
       ord.ORD_UDFCHKBOX01 UDFCHKBOX01,
       ord.ORD_UDFCHKBOX02 UDFCHKBOX02,
       ord.ORD_UDFCHKBOX03 UDFCHKBOX03,
       ord.ORD_UDFCHKBOX04 UDFCHKBOX04,
       ord.ORD_UDFCHKBOX05 UDFCHKBOX05
  FROM r5orders ord,
       r5address bill,
       r5address mail,
       r5address deli,
       r5address buy,
       r5address credit,
       r5address poem,
       r5address strm,
       r5address poei,
       r5address stri,
       r5address poed,
       r5address strd,
       r5address pord,
       r5address porm,
       r5address pori,
       r5companies com,
       r5ipvendors ipv,
       r5descriptions mp5i,
       r5descriptions status,
       r5descriptions ptype,
       r5descriptions site,
       r5stores str,
       r5entities ent,
       r5creditcards crd,
       r5deladdresses pode,
       r5install ins,
       r5supplieraccountnumbers acct
 WHERE ord.ord_supplier = com.com_code
   AND ord.ord_supplier_org = com.com_org
   AND com.com_ipvendor = ipv.ipv_code
   AND ord.ord_store = str.str_code
   AND acct.san_supplier (+) = ord.ord_supplier
   AND acct.san_supplier_org (+) = ord.ord_supplier_org
   AND acct.san_store (+) = ord.ord_store
   AND ent.ent_table = 'R5ORDERS'
   AND mail.adr_code (+) = '*#' || com.com_org
   AND mail.adr_rentity (+) = 'COMP'
   AND mail.adr_rtype (+) = 'M'
   AND poem.adr_code  (+) = ent.ent_rentity
   AND poem.adr_rentity (+)  = 'ENT'
   AND poem.adr_rtype (+)  = 'M'
   AND strm.adr_code (+)  = ord.ord_store
   AND strm.adr_rentity  (+)  = 'STOR'
   AND strm.adr_rtype (+)  = 'M'
   AND porm.adr_code (+) = ord.ord_code||'#'||ord.ord_org
   AND porm.adr_rentity (+) = 'PORD'
   AND porm.adr_rtype (+) = 'M'
   AND NOT (mail.adr_address1 IS NULL AND poem.adr_address1 IS NULL AND strm.adr_address1 IS NULL AND porm.adr_address1 IS NULL)
   AND bill.adr_code (+) = '*#' || com.com_org
   AND bill.adr_rentity (+) = 'COMP'
   AND bill.adr_rtype (+) = 'I'
   AND poei.adr_code (+) = ent.ent_rentity
   AND poei.adr_rentity (+) = 'ENT'
   AND poei.adr_rtype (+) = 'I'
   AND stri.adr_code (+)  = ord.ord_store
   AND stri.adr_rentity  (+)  = 'STOR'
   AND stri.adr_rtype (+)  = 'I'
   AND pori.adr_code (+) = ord.ord_code||'#'||ord.ord_org
   AND pori.adr_rentity (+) = 'PORD'
   AND pori.adr_rtype (+) = 'I'
   AND NOT (bill.adr_address1 IS NULL AND poei.adr_address1 IS NULL AND stri.adr_address1 IS NULL AND pori.adr_address1 IS NULL)
   AND deli.adr_code (+) = '*#' || com.com_org
   AND deli.adr_rentity (+) = 'COMP'
   AND deli.adr_rtype (+) = 'D'
   AND strd.adr_code (+)  = ord.ord_store
   AND strd.adr_rentity  (+)  = 'STOR'
   AND strd.adr_rtype (+)  = 'D'
   AND poed.adr_code (+) = ent.ent_rentity
   AND poed.adr_rentity (+) = 'ENT'
   AND poed.adr_rtype (+) = 'D'
   AND pord.adr_code (+) = ord.ord_code||'#'||ord.ord_org
   AND pord.adr_rentity (+) = 'PORD'
   AND pord.adr_rtype (+) = 'D'
   AND ord.ord_deladdress = pode.dad_code (+)
   AND NOT (deli.adr_address1 IS NULL AND poed.adr_address1 IS NULL AND strd.adr_address1 IS NULL AND pord.adr_address1 IS NULL AND ord.ord_deladdress IS NULL )
   AND buy.adr_code (+) = ord.ord_buyer
   AND buy.adr_rentity (+) = 'USER'
   AND buy.adr_rtype (+) = 'M'
   AND mp5i.des_rentity = 'COMP'
   AND mp5i.des_code = '*'
   AND mp5i.des_org = com.com_org
   AND mp5i.des_lang =ins.ins_desc
   AND mp5i.des_rtype = '*'
   AND site.des_rentity = 'ORG'                              -- join to descriptions to retrieve site name
   AND site.des_code = ord.ord_org
   AND site.des_org = '*'
   AND site.des_lang =ins.ins_desc
   AND site.des_rtype = '*'
   AND status.des_rentity = 'UCOD'
   AND status.des_code = ord.ord_status
   AND status.des_org = '*'
   AND status.des_lang =ins.ins_desc
   AND status.des_rtype = 'DOST'
   AND ptype.des_rentity = 'UCOD'
   AND ptype.des_code = ord.ord_type
   AND ptype.des_lang =ins.ins_desc
   AND ins.ins_code = 'DEFLANG'
   AND ptype.des_org = '*'
   AND ptype.des_rtype = 'POTP'
   AND crd.crd_code(+) = ord_creditcard
   AND credit.adr_code(+) = to_char(crd.crd_code)      -- retrieve credit card mail address
   AND credit.adr_rentity(+) = 'CARD'
   AND credit.adr_rtype(+) = 'M'
   AND(  com.com_ipaccount IS NOT NULL
      OR ord_creditcard    IS NOT NULL
      OR acct.san_ipaccount IS NOT NULL)
   AND ord.ord_iptransmitted = '-'
   AND ord.ord_rstatus = 'A'
   AND NOT EXISTS (
      SELECT 'x'
      FROM r5ordertracking otr
      WHERE ord.ord_code = otr.otr_order
      AND   ord.ord_org = otr.otr_order_org
      AND   ord.ord_revision = otr.otr_releasenum
      AND   otr.otr_tracktype = 'POTR' )
   AND NOT EXISTS
    ( SELECT 'x'
      FROM r5orderlines
      WHERE orl_order             = ord_code
      AND   orl_order_org         = ord_org
      AND   orl_rstatus           = 'A'
      AND ( NVL( orl_recvqty, 0 ) > 0
       OR   EXISTS ( SELECT 'x'
                     FROM r5translines l,
                          r5transactions t
                     WHERE trl_order      = orl_order
                     AND   trl_order_org  = orl_order_org
                     AND   trl_trans      = tra_code
                     AND   tra_rstatus   <> 'C'
                     AND   trl_qty        > 0 ) ) )
/
