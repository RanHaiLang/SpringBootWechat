CREATE VIEW R5IPVENDORSVW AS SELECT ipv_code, ipv_desc, ipv_url, ipv_notes
    FROM r5ipvendors
/
