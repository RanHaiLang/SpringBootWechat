CREATE VIEW R5ISSMAT AS SELECT l.trl_event,
       l.trl_act,
       l.trl_part,
       l.trl_part_org,
       l.trl_store
FROM   r5transactions t,
       r5translines l
WHERE  l.trl_trans       = t.tra_code
AND    t.tra_torentity   = 'EVNT'
AND    t.tra_fromrentity = DECODE( l.trl_rtype,
                                   'RECV', 'COMP', t.tra_fromrentity )
AND    l.trl_rtype IN ( 'I', 'RR', 'RECV' )
UNION
SELECT a.act_event,
       a.act_act,
       m.mlp_part,
       m.mlp_part_org,
       d.mrc_store
FROM   r5matlparts m,
       r5events e,
       r5mrcs d,
       r5activities a
WHERE  a.act_matlist = m.mlp_matlist
AND    a.act_matlrev = m.mlp_matlrev
AND    a.act_event   = e.evt_code
AND    e.evt_mrc     = d.mrc_code
/
