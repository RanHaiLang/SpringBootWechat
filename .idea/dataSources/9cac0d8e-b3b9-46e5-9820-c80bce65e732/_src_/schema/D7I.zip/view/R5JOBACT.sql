CREATE VIEW R5JOBACT AS SELECT
   evt_code
  ,act_act
  ,act_trade
  ,evt_mrc
  ,act_start
  ,act_start + act_duration - 1
  ,evt_obtype
  ,evt_object
  ,evt_object_org
  ,evt_ppm
  ,evt_ppmrev
  ,act_rem
  ,act_supplier
  ,act_supplier_org
  ,act_order
  ,act_order_org
  ,act_ordline
  ,act_rpc
  ,act_wap
  ,act_tpf
  ,act_manufact
  ,act_syslevel
  ,act_asmlevel
  ,act_complevel
  ,evt_org
FROM   r5events e
      ,r5activities a
WHERE evt_rstatus > 'C'
AND   evt_code    = act_event
/
