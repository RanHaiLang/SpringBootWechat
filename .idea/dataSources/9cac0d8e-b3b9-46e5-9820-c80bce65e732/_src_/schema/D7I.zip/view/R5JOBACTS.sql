CREATE VIEW R5JOBACTS AS SELECT A.act_event, A.act_act, A.act_trade, A.act_shift,
       A.act_est, A.act_rem, NVL(A.act_nt,0) + NVL(A.act_ot,0), A.act_start,A.act_duration,A.act_persons,
       A.act_rpc, A.act_wap, A.act_tpf, A.act_manufact, A.act_syslevel, A.act_asmlevel, A.act_complevel,
       E.evt_parent,E.evt_duration,E.evt_org, E.evt_mrc, E.evt_desc, E.evt_location, E.evt_location_org,
       E.evt_project, E.evt_rstatus, E.evt_status, E.evt_obrtype, E.evt_obtype,
       E.evt_object, E.evt_object_org, E.evt_ppm, E.evt_ppmrev, E.evt_target,
       E.evt_origin, E.evt_reqm, E.evt_jobtype, E.evt_priority, E.evt_reported, E.evt_warranty,
       E.evt_safety, E.evt_objcriticality, E.evt_schedgrp, E.evt_routeparent
FROM   r5events E, r5activities A
WHERE  E.evt_code = A.act_event
AND    E.evt_rstatus = 'R'
AND    NVL(A.act_completed,'-') <> '+'
/
