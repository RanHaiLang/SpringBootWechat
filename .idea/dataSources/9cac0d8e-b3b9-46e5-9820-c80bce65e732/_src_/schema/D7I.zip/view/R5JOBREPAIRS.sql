CREATE VIEW R5JOBREPAIRS AS SELECT rpb_part,
       rpb_part_org,
       rpb_store,
       SUM( rpb_qty )
FROM   r5repairbins
WHERE  rpb_req   IS NULL
AND    rpb_event IS NOT NULL
GROUP BY rpb_part,
         rpb_part_org,
         rpb_store
/
