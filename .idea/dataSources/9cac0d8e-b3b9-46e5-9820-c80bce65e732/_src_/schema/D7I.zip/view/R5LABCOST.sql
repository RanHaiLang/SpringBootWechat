CREATE VIEW R5LABCOST AS SELECT
   b.boo_event
  ,NVL( SUM( DECODE( a.act_ordrtype, 'SF', 0, b.boo_hours ) ), 0 )
  ,NVL( SUM( b.boo_cost  ), 0 )
FROM r5bookedhours b,
     r5activities a
WHERE b.boo_event = a.act_event
AND   b.boo_act   = a.act_act
GROUP BY b.boo_event
/
