CREATE VIEW R5LOADAVAIL AS SELECT
   w.wrk_date,
   w.wrk_mrc,
   w.wrk_trade,
   w.wrk_hours,
   a.avl_ownhours
FROM   r5workload w,
       r5availability a
WHERE  w.wrk_date  = a.avl_date (+)
AND    w.wrk_mrc   = a.avl_mrc (+)
AND    w.wrk_trade = a.avl_trade (+)
UNION
SELECT
   a.avl_date,
   a.avl_mrc,
   a.avl_trade,
   TO_NUMBER( NULL ),
   a.avl_ownhours
FROM   r5availability a
WHERE NOT EXISTS ( SELECT 'x'
                   FROM   r5workload w
                   WHERE  w.wrk_date  = a.avl_date
                   AND    w.wrk_mrc   = a.avl_mrc
                   AND    w.wrk_trade = a.avl_trade )
/
