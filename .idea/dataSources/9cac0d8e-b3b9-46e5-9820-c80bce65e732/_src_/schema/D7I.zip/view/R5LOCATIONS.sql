CREATE VIEW R5LOCATIONS AS SELECT
   o.obj_obtype,
   o.obj_code,
   o.obj_org,
   o.obj_desc,
   o.obj_class,
   o.obj_class_org,
   o.obj_parent,
   o.obj_parent_org,
   o.obj_depend,
   o.obj_mrc,
   o.obj_status,
   o.obj_rstatus,
   o.obj_notused
FROM  r5objects     o
WHERE o.obj_obrtype = 'L'
/
