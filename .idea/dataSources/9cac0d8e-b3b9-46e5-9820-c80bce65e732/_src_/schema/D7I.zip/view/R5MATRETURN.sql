CREATE VIEW R5MATRETURN AS SELECT
   t.tra_fromcode,
   SUM( NVL( l.trl_price, 0 ) * NVL( l.trl_qty, 0 ) )
FROM   r5translines      l,
       r5transactions    t
WHERE  l.trl_trans       = t.tra_code
AND    t.tra_fromrentity = 'EVNT'
GROUP BY t.tra_fromcode
/
