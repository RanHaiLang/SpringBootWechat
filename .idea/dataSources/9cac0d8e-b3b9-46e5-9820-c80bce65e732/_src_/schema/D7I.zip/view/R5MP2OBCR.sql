CREATE VIEW R5MP2OBCR AS SELECT dtc_upcode uco_upcode, uco_entity, uco_code
    FROM r5ucodes, r5dataconversion
   WHERE uco_rentity = 'OBCR'
     AND uco_code <> '*'
/
