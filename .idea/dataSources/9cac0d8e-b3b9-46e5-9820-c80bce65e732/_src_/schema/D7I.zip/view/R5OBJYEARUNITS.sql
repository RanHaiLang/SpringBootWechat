CREATE VIEW R5OBJYEARUNITS AS SELECT oye_start,
       oye_end,
       obu_units,
       obu_object,
       obu_object_org,
       obu_yearpk
FROM   r5orgyears,
       r5objunits
WHERE  oye_pk = obu_yearpk
/
