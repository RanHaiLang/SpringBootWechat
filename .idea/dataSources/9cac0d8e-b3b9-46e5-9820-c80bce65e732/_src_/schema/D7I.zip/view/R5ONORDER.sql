CREATE VIEW R5ONORDER AS SELECT
   orl_part,
   orl_part_org,
   orl_store,
   SUM( orl_ordqty - NVL( orl_recvqty, 0 ) - NVL( orl_scrapqty, 0 ) )
FROM     r5orderlines
WHERE    orl_rtype  IN ( 'PS', 'RE' )
AND      orl_active = '+'
GROUP BY orl_store,
         orl_part,
         orl_part_org
/
