CREATE VIEW R5ONREPREQ AS SELECT l.rql_part,
       l.rql_part_org,
       r.req_tocode,
       NVL( SUM( GREATEST( l.rql_qty - NVL( l.rql_recvqty, 0 ) - NVL( l.rql_scrapqty, 0 ), 0 ) ), 0 )
FROM   r5requisitions r,
       r5parts p,
       r5requislines l
WHERE  r.req_code       = l.rql_req
AND    l.rql_part       = p.par_code
AND    l.rql_part_org   = p.par_org
AND    l.rql_rtype       IN ( 'RI', 'RE' )
AND    l.rql_rstatus NOT IN ( 'C', 'J' )
AND    p.par_repairable = '+'
AND NOT EXISTS ( SELECT 'x'
                 FROM   r5joblines j
                 WHERE  j.jbl_req     = l.rql_req
                 AND    j.jbl_reqline = l.rql_reqline
                 AND    j.jbl_active  = '+' )
AND NOT EXISTS ( SELECT 'x'
                 FROM   r5orders o,
                        r5orderlines s
                 WHERE  s.orl_order     = o.ord_code
                 AND    s.orl_order_org = o.ord_org
                 AND    s.orl_req       = l.rql_req
                 AND    s.orl_reqline   = l.rql_reqline
                 AND    o.ord_rstatus IN ( 'A' ) )
GROUP BY l.rql_part,
         l.rql_part_org,
         r.req_tocode
/
