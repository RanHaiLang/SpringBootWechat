CREATE VIEW R5OPDATATBL AS SELECT
   odt_datestamp,
   odt_varid,
   odt_audituser,
   odt_audittimestamp,
   odt_numvalue,
   odt_textvalue,
   odt_forced,
   odt_id
FROM r5opvardata
/
