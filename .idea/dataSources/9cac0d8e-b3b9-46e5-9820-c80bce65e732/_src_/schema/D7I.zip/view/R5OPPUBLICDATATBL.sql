CREATE VIEW R5OPPUBLICDATATBL AS SELECT
    a.odt_id,
    a.odt_datestamp,
    a.odt_varid,
    a.odt_audituser,
    a.odt_audittimestamp,
    a.odt_numvalue,
    a.odt_textvalue,
    a.odt_forced,
    b.ovd_org
FROM R5OPVARDATA a,
     R5OPVARIABLES b
WHERE a.odt_varid = b.ovd_id
AND   b.ovd_vartype != '9'
AND   length(b.ovd_shortname) <=12
/
