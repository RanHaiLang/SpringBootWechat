CREATE VIEW R5OPSELECTVAR AS SELECT
   ovd_varid,
   ovd_name,
   ovd_vartype,
   ovd_varscope,
   ovd_eqinfix
FROM r5opvardesc
/
