CREATE VIEW R5ORDERLINESDESC AS SELECT
  orl_supplier           ORL_SUPPLIER,
  orl_supplier_org       ORL_SUPPLIER_ORG,
  ord_status             ORDERSTATUS,
  orl_order              ORL_ORDER,
  orl_order_org          ORL_ORDER_ORG,
  ord_date               ORDERDATE,
  orl_ordline            ORL_ORDLINE,
  orl_type               ORL_TYPE,
  orl_status             ORL_STATUS,
  orl_due                ORL_DUE,
  orl_part               ORL_PART,
  orl_part_org           ORL_PART_ORG,
  dl.des_text            ORL_PARTTASK_DESC,
  orl_task               ORL_TASK,
  orl_price              ORL_PRICE,
  orl_curr               ORL_CURR,
  orl_puruom             ORL_PURUOM,
  round( orl_ordqty   / nvl( orl_multiply, 1), 2)   ORLORDQTY,
  round( orl_recvqty  / nvl( orl_multiply, 1 ),2 )  ORLRECVQTY,
  round( orl_scrapqty / nvl( orl_multiply, 1 ),2 )  ORLSCRAPQTY,
  round( orl_invqty   / nvl( orl_multiply, 1 ),2 )  ORLINVQTY,
  orl_recvvalue          ORL_RECVVALUE,
  orl_invvalue           ORL_INVVALUE,
  orl_req                ORL_REQ,
  orl_reqline            ORL_REQLINE,
  orl_event              ORL_EVENT,
  orl_act                ORL_ACT,
  orl_contract           ORL_CONTRACT,
  ord_buyer              ORDERBUYER,
  orl_store              ORL_STORE,
  do.des_text            ORDERDESC,
  orl_multiply           ORL_MULTIPLY,
  do.des_lang            ORL_LANGUAGE
FROM  r5orders o ,
      r5orderlines l ,
      r5descriptions do,
      r5descriptions dl
WHERE dl.des_rentity  = 'PART'
AND   do.des_rentity  = 'PORD'
AND   l.orl_rtype    IN ( 'PD', 'PS', 'RE' )
AND   o.ord_code      = l.orl_order
AND   o.ord_org       = l.orl_order_org
AND   dl.des_code     = orl_part
AND   dl.des_org      = orl_part_org
AND   dl.des_lang     = do.des_lang
AND   do.des_code     = ord_code
AND   do.des_org      = ord_org
UNION ALL
SELECT
  orl_supplier           ,
  orl_supplier_org       ,
  ord_status             ,
  orl_order              ,
  orl_order_org          ,
  ord_date               ,
  orl_ordline            ,
  orl_type               ,
  orl_status             ,
  orl_due                ,
  orl_part               ,
  orl_part_org           ,
  dl.des_text            ,
  orl_task               ,
  orl_price              ,
  orl_curr               ,
  orl_puruom             ,
  round( orl_ordqty   / nvl( orl_multiply, 1), 2)   ORLORDQTY,
  round( orl_recvqty  / nvl( orl_multiply, 1 ),2 )  ORLRECVQTY,
  round( orl_scrapqty / nvl( orl_multiply, 1 ),2 )  ORLSCRAPQTY,
  round( orl_invqty   / nvl( orl_multiply, 1 ),2 )  ORLINVQTY,
  orl_recvvalue          ,
  orl_invvalue           ,
  orl_req                ,
  orl_reqline            ,
  orl_event              ,
  orl_act                ,
  orl_contract           ,
  ord_buyer              ,
  orl_store              ,
  do.des_text            ,
  orl_multiply           ,
  do.des_lang
FROM  r5orders o ,
      r5orderlines l ,
      r5descriptions do,
      r5descriptions dl
WHERE dl.des_rentity(+)  = 'TASK'
AND   do.des_rentity     = 'PORD'
AND   l.orl_rtype       IN ( 'ST', 'SF', 'SH' )
AND   o.ord_code         = l.orl_order
AND   o.ord_org          = l.orl_order_org
AND   dl.des_code(+)     = orl_task
AND ( ( dl.des_lang      = do.des_lang
    AND orl_task         IS NOT NULL )
OR    orl_task           IS NULL )
AND   do.des_code        = ord_code
AND   do.des_org         = ord_org
/
