CREATE VIEW R5ORDREALLOC AS SELECT
 trl_event ora_event,
 trl_act  ora_act,
 e.evt_org ora_event_org,
 trl_order ora_order,
 trl_ordline ora_ordline,
 trl_order_org ora_order_org,
 trl_part ora_part,
 trl_part_org ora_part_org,
 NVL(trl_lot, '*')  ora_lot,
 SUM(trl_qty * decode( trl_rtype, 'RECV', 1, 'RETN', -1, 0 ) )    ora_recvqty,
 SUM(trl_qty * decode( trl_rtype, 'RECV', decode( trl_store, null, 0, 1 ),
                       'I', decode( trl_store, null, 0, -1), 'RETN',
                        decode( trl_store, null, 0 ,-1), 0 ))  ora_holdqty,
 SUM(trl_qty * decode( trl_rtype, 'I', 1,'RECV',decode( trl_store, null, 1, 0),
                       'RETN',decode( trl_store, null, -1, 0), 0)) ora_issueqty
FROM    r5translines tl, r5events e, r5transactions tr
WHERE   trl_event IS NOT NULL
AND     trl_act   IS NOT NULL
AND     trl_order IS NOT NULL
AND     trl_object IS NULL
AND     trl_io = 0
AND     trl_event = evt_code
AND     trl_trans = tra_code
AND     tra_rstatus = 'A'
GROUP BY trl_event, trl_event, trl_act, trl_order, trl_ordline, trl_order_org,
         trl_part, trl_part_org, NVL(trl_lot, '*'), e.evt_org
/
