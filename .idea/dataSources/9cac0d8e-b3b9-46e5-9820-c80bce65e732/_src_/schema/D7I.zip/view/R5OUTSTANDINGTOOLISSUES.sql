CREATE VIEW R5OUTSTANDINGTOOLISSUES AS SELECT par_tool, trl_part, trl_part_org, trl_store, tra_org,
       tra_pers, per_desc, trl_event, trl_act, trl_object, trl_object_org, SUM( trl_qty )
FROM   r5parts, r5translines, r5transactions
       LEFT OUTER JOIN r5personnel ON tra_pers = per_code
WHERE  trl_trans = tra_code
AND    trl_part = par_code
AND    trl_part_org = par_org
AND    trl_rtype IN ( 'I', 'RR' )
AND    par_tool IS NOT NULL
GROUP BY par_tool, trl_part, trl_part_org, trl_store, tra_org,
      tra_pers, per_desc,trl_event, trl_act, trl_object, trl_object_org
HAVING SUM( trl_qty ) > 0
/
