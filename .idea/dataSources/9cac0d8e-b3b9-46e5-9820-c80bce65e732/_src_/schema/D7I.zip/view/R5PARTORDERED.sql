CREATE VIEW R5PARTORDERED AS SELECT SUM( NVL( l.orl_ordqty, 0 ) /
	     NVL( l.orl_multiply, 1 ) ),
	 l.orl_event,
	 l.orl_part,
       l.orl_part_org
 FROM  r5orderlines l,
	 r5orders o
 WHERE l.orl_order     = o.ord_code
 AND   l.orl_order_org = o.ord_org
 AND   o.ord_rstatus   = 'A'
 AND   l.orl_rtype     = 'PD'
 GROUP BY l.orl_event,
   	    l.orl_part,
          l.orl_part_org
/
