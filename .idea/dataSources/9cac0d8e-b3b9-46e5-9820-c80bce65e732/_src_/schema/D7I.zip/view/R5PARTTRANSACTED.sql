CREATE VIEW R5PARTTRANSACTED AS SELECT trl.trl_event,
       trl.trl_act,
       trl.trl_part,
       trl.trl_part_org,
       SUM( NVL( trl.trl_origqty, trl.trl_qty ) * DECODE ( trl_io, 0, DECODE(trl_rtype, 'RETN', -1, 1 ), -trl_io )),
       p.par_uom
FROM   r5translines trl,
       r5transactions tra,
       r5parts p
WHERE  tra.tra_code = trl.trl_trans
  AND  ((tra.tra_rtype = 'I'
  AND   tra.tra_fromrentity = 'STOR'
  AND   tra.tra_torentity = 'EVNT' )
   OR  (tra.tra_rtype = 'RECV'
  AND   tra.tra_fromrentity = 'COMP'
  AND   tra.tra_torentity = 'EVNT' )
   OR  (tra.tra_rtype = 'RETN'
  AND   tra.tra_fromrentity = 'EVNT'
  AND   tra.tra_torentity = 'COMP' ))
  AND   trl.trl_part = par_code
  AND   trl.trl_part_org = par_org
GROUP BY trl.trl_event,
         trl.trl_act,
         trl.trl_part,
         trl.trl_part_org,
         p.par_uom
/
