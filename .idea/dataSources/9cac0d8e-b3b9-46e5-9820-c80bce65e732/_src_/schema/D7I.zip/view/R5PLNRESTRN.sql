CREATE VIEW R5PLNRESTRN AS SELECT
   NVL( e.evt_routeparent, l.trl_event),
   l.trl_act,
   l.trl_part,
   l.trl_part_org,
   l.trl_store,
   0 line,
   null direct,
   null matlist,
   to_number(null) matlistrev
FROM   r5transactions t,
       r5translines l,
       r5events e
WHERE  l.trl_trans       = t.tra_code
AND    (t.tra_torentity = 'EVNT' OR t.tra_torentity = 'STOR')
AND    t.tra_fromrentity = DECODE( l.trl_rtype,'RECV', 'COMP', t.tra_fromrentity )
AND    l.trl_rtype IN ( 'I', 'RR', 'RECV' )
AND    e.evt_code = l.trl_event
UNION
SELECT
   l.trl_event,
   l.trl_act,
   l.trl_part,
   l.trl_part_org,
   l.trl_store,
   0 line,
   null direct,
   null matlist,
   to_number(null) matlistrev
FROM   r5transactions t,
       r5translines l,
       r5events e
WHERE  l.trl_trans       = t.tra_code
AND    t.tra_torentity   = 'EVNT'
AND    t.tra_fromrentity = DECODE( l.trl_rtype,'RECV', 'COMP', t.tra_fromrentity )
AND    l.trl_rtype IN ( 'I', 'RR', 'RECV' )
AND    e.evt_code = l.trl_event
AND    e.evt_routeparent IS NOT NULL
UNION
SELECT r.res_event,
   r.res_act,
   r.res_part,
   r.res_part_org,
   r.res_store,
   0 line,
   null direct,
   null matlist,
   to_number(null) matlistrev
FROM   r5reservations r
UNION
SELECT
   a.act_event,
   a.act_act,
   m.mlp_part,
   m.mlp_part_org,
   DECODE(nvl(str_org,e.evt_org), e.evt_org,d.mrc_store,null),
   m.mlp_line line,
   m.mlp_direct direct,
   m.mlp_matlist matlist,
   m.mlp_matlrev matlistrev
FROM   r5matlparts m,
       r5events e,
       r5mrcs d,
       r5activities a,
	   r5stores s
WHERE  a.act_matlist = m.mlp_matlist
AND    a.act_matlrev = m.mlp_matlrev
AND    a.act_event   = e.evt_code
AND    e.evt_mrc     = d.mrc_code
AND    d.mrc_store   = s.str_code(+)
AND ( ( nvl(m.mlp_code, nvl(e.evt_object,'!@#$%')) = nvl(e.evt_object,'!@#$%')
AND nvl(m.mlp_code_org, nvl(e.evt_object_org,'!@#$%')) = nvl(e.evt_object_org,'!@#$%') )
 OR ( m.mlp_obrtype = 'C'
      AND EXISTS (SELECT obj_code
	              FROM r5objects
				  WHERE obj_code = e.evt_object
				  AND   obj_org = e.evt_object_org
				  AND   obj_category = m.mlp_code) ) )
/
