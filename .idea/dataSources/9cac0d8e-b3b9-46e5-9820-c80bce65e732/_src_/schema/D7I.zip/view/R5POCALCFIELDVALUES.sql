CREATE VIEW R5POCALCFIELDVALUES AS SELECT ord_code, ord_org,
		SUM( CASE WHEN SUBSTR( orl_rtype, 1, 1 ) IN ('P','R') THEN 1  ELSE 0 END),
		SUM( CASE WHEN SUBSTR( orl_rtype, 1, 1 ) = 'S' THEN 1  ELSE 0 END),
		count(*),
		ROUND(SUM(
		GREATEST(
		CASE	WHEN SUBSTR( orl_rtype, 1, 1 ) IN ('P','R')
			THEN  COALESCE(orl_price, 0) / COALESCE( orl_exch, 1) *
				( COALESCE(CASE  WHEN  orl_rstatus IN('C','J') THEN orl_recvqty ELSE orl_ordqty END , 0 ) / COALESCE( orl_multiply, 1 ) )  *
				( 1 - 0.01 * COALESCE( orl_discperc, 0 ) ) + (CASE WHEN  orl_rstatus IN('C','J') THEN 0 ELSE (COALESCE(orl_totextra, 0) + COALESCE(orl_tottaxamount, 0)) / COALESCE( orl_exch, 1 ) END)
			ELSE 0
			END , 0 ) ) ,2),
		ROUND(SUM(
		GREATEST(
		CASE SUBSTR( orl_rtype, 1, 1 )
			WHEN 'S'
			THEN COALESCE(CASE orl_rtype WHEN 'SF' THEN CASE WHEN orl_rstatus IN('C','J') THEN orl_recvvalue ELSE orl_price END ELSE orl_price END, 0) / COALESCE( orl_exch, 1 ) *
				( COALESCE( CASE orl_rtype WHEN 'SF' THEN 1 ELSE CASE WHEN orl_rstatus IN('C','J') THEN  orl_recvqty ELSE orl_ordqty END END, 0 ) / COALESCE( orl_multiply, 1 ) ) *
				( 1 - 0.01 * COALESCE( orl_discperc, 0 ) ) + (CASE WHEN  orl_rstatus IN('C','J') THEN 0 ELSE (COALESCE(orl_totextra, 0) + COALESCE(orl_tottaxamount, 0)) / COALESCE( orl_exch, 1 ) END)
			ELSE 0
			END , 0 ) ) ,2),
		ROUND(SUM(
		GREATEST(
		CASE SUBSTR( orl_rtype, 1, 1 )
			WHEN 'S'
			THEN COALESCE(CASE orl_rtype WHEN 'SF' THEN CASE WHEN orl_rstatus IN('C','J') THEN orl_recvvalue ELSE orl_price END ELSE orl_price END, 0) / COALESCE( orl_exch, 1 ) *
				( COALESCE( CASE orl_rtype WHEN 'SF' THEN 1 ELSE CASE WHEN orl_rstatus IN('C','J') THEN  orl_recvqty ELSE orl_ordqty END END, 0 ) / COALESCE( orl_multiply, 1 ) ) *
				( 1 - 0.01 * COALESCE( orl_discperc, 0 ) ) + (CASE WHEN  orl_rstatus IN('C','J') THEN 0 ELSE (COALESCE(orl_totextra, 0) + COALESCE(orl_tottaxamount, 0)) / COALESCE( orl_exch, 1 ) END)
			ELSE COALESCE(orl_price, 0) / COALESCE( orl_exch, 1) *
				( COALESCE( CASE WHEN  orl_rstatus IN('C','J') THEN orl_recvqty ELSE orl_ordqty END , 0 ) / COALESCE( orl_multiply, 1 ) ) *
				( 1 - 0.01 * COALESCE( orl_discperc, 0 ) ) + (CASE WHEN  orl_rstatus IN('C','J') THEN 0 ELSE (COALESCE(orl_totextra, 0) + COALESCE(orl_tottaxamount, 0)) / COALESCE( orl_exch, 1 ) END)
			END, 0 ) ) ,2),
		ROUND(SUM(COALESCE(orl_tottaxamount, 0) / COALESCE(orl_exch, 1)) ,2),
		ROUND(SUM(COALESCE(orl_totextra, 0) / COALESCE(orl_exch, 1)) ,2)
	FROM r5orders,r5orderlines
	WHERE ord_code = orl_order
	AND ord_org = orl_order_org
	GROUP BY ord_code, ord_org
/
