CREATE VIEW R5PPMPLANOBJECTS AS (  SELECT ppo_object,
          ppo_object_org,
          ppo_obtype,
          ppo_org,
          ppm_plan
   FROM   r5ppmobjects o,
          r5ppms p
   WHERE  ppm_revrstatus = 'A'
   AND    ppm_code         = ppo_ppm
   AND    ppm_revision     = ppo_revision
   AND    ppo_deactive     IS NULL
   AND    ppm_notused      = '-'
   AND    ppm_plan         IS NOT NULL
   GROUP BY ppo_object,
            ppm_plan,
            ppo_object_org,
            ppo_obtype,
            ppo_org
)
/
