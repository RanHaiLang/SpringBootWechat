CREATE VIEW R5PROMPTLOVS AS SELECT DISTINCT
  	   ap.apm_prompt,
  	   p.pro_text,
  	   ap.apm_aspect,
  	   a.asp_desc,
  	   p.pro_type,
  	   p.pro_min,
  	   p.pro_max
FROM
  	   r5aspectprompts ap,
  	   r5aspects a,
  	   r5properties p
WHERE ap.apm_prompt = p.pro_code
AND   a.asp_code    = ap.apm_aspect
/
