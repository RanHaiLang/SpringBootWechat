CREATE VIEW R5QUOTLIN2 AS SELECT
   l.qul_quotation    ql2_quotation,
   q.quo_org          ql2_org,
   l.qul_seqno        ql2_seqno,
   l.qul_trade        ql2_trade,
   ( l.qul_price
     / DECODE( l.qul_rtype, 'SF', 1,
               DECODE( l.qul_quotqty, 0, 1, NULL, 1, l.qul_quotqty ) ) )
                      ql2_rate,
   l.qul_curr         ql2_curr,
   l.qul_exch         ql2_exch,
   l.qul_leadtime     ql2_leadtime,
   l.qul_expir        ql2_expir,
   l.qul_rtype        ql2_rtype,
   l.qul_type         ql2_type,
   l.qul_exchtodual   ql2_exchtodual,
   l.qul_exchfromdual ql2_exchfromdual,
   q.quo_desc         ql2_desc,
   q.quo_supplier     ql2_supplier,
   q.quo_supplier_org ql2_supplier_org,
   q.quo_score        ql2_score,
   q.quo_rating       ql2_rating,
   q.quo_store        ql2_store,
   q.quo_origin       ql2_origin
FROM   r5quotations q,
       r5quotlines  l
WHERE  q.quo_code   = l.qul_quotation
AND    q.quo_seqno  = l.qul_seqno
/
