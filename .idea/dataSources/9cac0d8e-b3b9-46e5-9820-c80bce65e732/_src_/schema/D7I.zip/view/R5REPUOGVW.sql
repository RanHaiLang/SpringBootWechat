CREATE VIEW R5REPUOGVW AS (
SELECT
   o.org_code,
   u.usr_code,
   substr(dbo.repvaliduserorg(u.usr_code,o.org_code),1,1) userorg
FROM r5organization o, r5users u )
/
