CREATE VIEW R5REQSFORJOB AS SELECT r.rql_req,
       q.req_org,
       r.rql_reqline,
       q.req_fromcode,
       q.req_tocode,
       r.rql_part,
       r.rql_part_org,
       r.rql_qty,
       r.rql_type,
       r.rql_status,
       r.rql_uom
FROM   r5requislines r,
       r5requisitions q
WHERE  q.req_code    = r.rql_req
AND    r.rql_rtype   = 'RI'
AND    r.rql_rstatus = 'A'
AND    r.rql_active  = '+'
AND    r.rql_qty     = ( SELECT SUM( b.rpb_qty )
                         FROM   r5repairbins b
                         WHERE  b.rpb_req     = r.rql_req
                         AND    b.rpb_reqline = r.rql_reqline )
AND NOT EXISTS ( SELECT 'x'
                 FROM   r5joblines j
                 WHERE  j.jbl_req     = r.rql_req
                 AND    j.jbl_reqline = r.rql_reqline )
/
