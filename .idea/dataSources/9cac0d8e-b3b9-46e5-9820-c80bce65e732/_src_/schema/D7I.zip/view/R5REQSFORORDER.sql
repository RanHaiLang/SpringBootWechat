CREATE VIEW R5REQSFORORDER AS SELECT
   r.rql_req,
   q.req_org,
   r.rql_reqline,
   r.rql_supplier,
   r.rql_supplier_org,
   q.req_tocode,
   q.req_origin,
   r.rql_part,
   r.rql_part_org,
   r.rql_task,
   r.rql_taskrev,
   r.rql_buyer,
   r.rql_due,
   r.rql_qty,
   r.rql_taskqty,
   r.rql_price,
   r.rql_curr,
   r.rql_exch,
   r.rql_type,
   r.rql_event,
   r.rql_act,
   r.rql_project,
   r.rql_projbud,
   r.rql_costcode,
   r.rql_uom,
   r.rql_rtype,
   r.rql_multiply,
   r.rql_status,
   r.rql_blanketorder,
   r.rql_blanketline,
   r.rql_trade,
   r.rql_deladdress,
   r.rql_quotflag,
   r.rql_inspect,
   r.rql_relatedwo
FROM     r5requislines r,
         r5requisitions q
WHERE    q.req_code        = r.rql_req
AND      q.req_fromrentity = 'COMP'
AND      q.req_rstatus     = 'A'
AND      r.rql_rstatus     = 'A'
AND      r.rql_active      = '+'
AND NOT EXISTS ( SELECT 'x'
                 FROM   r5orderlines o
                 WHERE  o.orl_req     = r.rql_req
                 AND    o.orl_reqline = r.rql_reqline )
AND NOT EXISTS ( SELECT 'x'
                 FROM   r5quotlines q
                 WHERE  q.qul_req     = r.rql_req
                 AND    q.qul_reqline = r.rql_reqline )
AND NOT EXISTS ( SELECT 'x'
                 FROM   r5orderlines o
                 WHERE  o.orl_event = r.rql_event
                 AND    o.orl_act   = r.rql_act
                 AND    o.orl_rstatus NOT IN ( 'C', 'J' )
                 AND    o.orl_rtype LIKE 'S%'
                 AND    r.rql_rtype LIKE 'S%' )
/
