CREATE VIEW R5RESERVED AS SELECT
   res_part,
   res_part_org,
   res_store,
   SUM( res_qty )
FROM  r5reservations
GROUP BY res_store,
         res_part,
         res_part_org
/
