CREATE VIEW R5SELECTTEXT AS SELECT distinct bot_text slt_text,
       bot_pool     slt_pool,
       bot_length   slt_length,
       bot_lang     slt_lang,
       bot_changed  slt_changed
FROM r5boilertexts
/
