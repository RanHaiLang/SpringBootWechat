CREATE VIEW R5SUMUSG AS (
SELECT usg_store,
       usg_part,
       usg_part_org,
       MAX( usg_month ) usg_month
FROM   r5sumusage
GROUP BY usg_store,
         usg_part,
         usg_part_org )
/
