CREATE VIEW R5TEMPREPXFERREQ AS (SELECT r.req_code, 0 , 'STREQF' , '-', TO_CHAR(REQ_DATE,'YYYY-MM-DD')
FROM r5requisitions r
UNION
SELECT req_code, trx_session, trx_function, '+', TO_CHAR(REQ_DATE,'YYYY-MM-DD')
FROM  r5temprepxfer t, r5requisitions r
WHERE trx_rowid = r.rowid and
trx_function = 'STREQF'
)
/
