CREATE VIEW R5TEMPWORKLOADAVAILABILITY AS SELECT w.twl_sessionid,
       NVL(w.twl_date, a.avl_date),
       NVL(w.twl_mrc, a.avl_mrc),
       NVL(w.twl_trade, a.avl_trade),
       w.twl_hours,
       a.avl_ownhours
FROM   r5tempworkload w,
       r5availability a
WHERE  w.twl_date  = a.avl_date (+)
AND    w.twl_mrc   = a.avl_mrc (+)
AND    w.twl_trade = a.avl_trade (+)
UNION
SELECT TO_NUMBER( NULL ),
       a.avl_date,
       a.avl_mrc,
       a.avl_trade,
       0,
       a.avl_ownhours
FROM   r5availability a
WHERE NOT EXISTS ( SELECT 'x'
                   FROM   r5tempworkload w
                   WHERE  w.twl_date  = a.avl_date
                   AND    w.twl_mrc   = a.avl_mrc
                   AND    w.twl_trade = a.avl_trade )
/
