CREATE VIEW R5TLSVIEW_1 AS SELECT DISTINCT lrf_id,
   lrf_objcode,
   lrf_objorg,
   NVL(lrf_re_objcode,'##'||lrf_id) lrf_re_objcode,
   NVL(lrf_re_objorg,'##'||lrf_id) lrf_re_objorg,
   lrf_refrtype,
   lrf_reftype,
   lrf_refdesc,
   obj_desc,
   tls_distance,
   tls_sessionid
FROM r5objects,
     r5objlinearref,
     r5templrfsearch t1
WHERE lrf_id = tls_lrfid
AND   obj_code = lrf_objcode
AND   obj_org = lrf_objorg
AND   tls_distance = ( SELECT MIN( tls_distance )
                     FROM   r5templrfsearch t2
                     WHERE  tls_lrfid = lrf_id
                     AND    t2.tls_sessionid = t1.tls_sessionid )
UNION ALL
SELECT DISTINCT lrf_id,
      '',
      '',
      lrf_objcode,
      lrf_objorg,
      lrf_reftype,
      '',
      obj_desc,
      '',
      tls_distance,
      tls_sessionid
FROM r5objects,
     r5objlinearref,
     r5templrfsearch t1
WHERE lrf_id = tls_lrfid
AND   obj_code = lrf_objcode
AND   obj_org = lrf_objorg
AND   tls_distance = ( SELECT MIN( tls_distance )
                     FROM   r5templrfsearch t2
                     WHERE  tls_lrfid = lrf_id
                     AND    t2.tls_sessionid = t1.tls_sessionid )
/
