CREATE VIEW R5TLSVIEW_2 AS SELECT
   lrf_re_objcode,
   lrf_re_objorg,
   tls_sessionid,
   MIN( tls_distance ) tls_distance
FROM r5tlsview_1
GROUP BY lrf_re_objcode, lrf_re_objorg, tls_sessionid
/
