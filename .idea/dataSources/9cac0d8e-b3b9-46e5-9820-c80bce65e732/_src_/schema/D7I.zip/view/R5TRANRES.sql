CREATE VIEW R5TRANRES AS SELECT
   rql_part,
   rql_part_org,
   req_fromcode,
   SUM( GREATEST( rql_qty - NVL( rql_recvqty, 0 ) - NVL( rql_scrapqty, 0 ) - NVL( tst_qty, 0 ), 0 ) )
FROM r5requislines,
     r5transtock,
     r5requisitions
WHERE    rql_rstatus = 'A'
AND      req_rstatus = 'A'
AND      rql_req     = req_code
AND      rql_req     = tst_req (+)
AND      rql_reqline = tst_reqline (+)
AND      req_fromcode IS NOT NULL
AND      req_fromrentity = 'STOR'
GROUP BY req_fromcode,
         rql_part,
         rql_part_org
/
