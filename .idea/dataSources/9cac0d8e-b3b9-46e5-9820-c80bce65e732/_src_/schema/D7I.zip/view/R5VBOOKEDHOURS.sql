CREATE VIEW R5VBOOKEDHOURS AS SELECT fbs_bill,
       fbs_costcode,
       fbs_object,
       fbs_object_org,
       fbs_adjustment,
       boo_billsubline,
       boo_fleetchecked,
       boo_event,
       evt_jobtype,
       boo_act,
       boo_person,
       boo_trade,
       boo_mrc,
       boo_hours,
       boo_rate,
       boo_cost,
       boo_fleetmarkup,
       boo_date,
       DECODE( boo_fleetchecked, 'M', '+', 'C', '+', '-' ),
       DECODE( boo_fleetchecked, 'M', '+', 'I', '+', '-' )
FROM   r5events, r5bookedhours, r5fleetbillsublines
WHERE  boo_billsubline = fbs_pk
AND    evt_code = boo_event
AND    boo_fleetchecked NOT IN ( '-', '+' )
UNION ALL
SELECT tbo_session,
       tfs_costcode,
       tfs_object,
       tfs_object_org,
       tfs_adjustment,
       tbo_tempsubline,
       tbo_fleetchecked,
       boo_event,
       evt_jobtype,
       boo_act,
       boo_person,
       boo_trade,
       boo_mrc,
       boo_hours,
       boo_rate,
       boo_cost,
       tbo_fleetmarkup,
       boo_date,
       DECODE( tbo_fleetchecked, 'M', '+', 'C', '+', '-' ),
       DECODE( tbo_fleetchecked, 'M', '+', 'I', '+', '-' )
FROM   r5events, r5bookedhours, r5tempbookedhours, r5tempbillsublines
WHERE  boo_acd = tbo_acd
AND    tbo_tempsubline = tfs_pk
AND    evt_code = boo_event
AND    tbo_fleetchecked NOT IN ( '-', '+' )
/
