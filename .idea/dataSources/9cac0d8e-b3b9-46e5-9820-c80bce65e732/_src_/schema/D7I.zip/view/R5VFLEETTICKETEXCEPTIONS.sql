CREATE VIEW R5VFLEETTICKETEXCEPTIONS AS SELECT fbs_bill,
       fbs_costcode,
       fbs_object,
       fbs_object_org,
       fbs_adjustment,
       fte_billsubline,
       fte_ticket,
       fte_exception,
       fte_type,
       fte_date,
       fte_amount,
       fte_comment,
       fti_type,
       fti_person,
       fti_issuedate,
       fti_returndate
FROM   r5fleettickets, r5fleetticketexceptions, r5fleetbillsublines
WHERE  fte_billsubline = fbs_pk
AND    fte_ticket = fti_code
UNION ALL
SELECT tfx_session,
       tfs_costcode,
       tfs_object,
       tfs_object_org,
       tfs_adjustment,
       tfx_tempsubline,
       fte_ticket,
       fte_exception,
       fte_type,
       fte_date,
       fte_amount,
       fte_comment,
       fti_type,
       fti_person,
       fti_issuedate,
       fti_returndate
FROM   r5fleettickets, r5fleetticketexceptions, r5tempticketexceptions, r5tempbillsublines
WHERE  fte_pk = tfx_pk
AND    tfx_tempsubline = tfs_pk
AND    fte_ticket = fti_code
/
