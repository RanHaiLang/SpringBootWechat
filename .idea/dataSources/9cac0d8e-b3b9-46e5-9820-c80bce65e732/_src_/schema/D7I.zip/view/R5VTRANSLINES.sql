CREATE VIEW R5VTRANSLINES AS SELECT fbs_bill,
       fbs_costcode,
       fbs_object,
       fbs_object_org,
       fbs_adjustment,
       trl_billsubline,
       trl_fleetchecked,
       trl_event,
       trl_act,
       trl_part,
       trl_part_org,
       trl_qty,
       par_uom,
       trl_price,
       trl_qty * trl_price,
       trl_fleetmarkup,
       trl_date,
       DECODE( trl_fleetchecked, 'F', '+', '-' ),
       DECODE( trl_fleetchecked, 'M', '+', 'N', '-', '' )
FROM   r5parts, r5translines, r5fleetbillsublines
WHERE  trl_billsubline = fbs_pk
AND    trl_part        = par_code
AND    trl_part_org    = par_org
AND    trl_fleetchecked NOT IN ( '-', '+' )
UNION ALL
SELECT ttr_session,
       tfs_costcode,
       tfs_object,
       tfs_object_org,
       tfs_adjustment,
       ttr_tempsubline,
       ttr_fleetchecked,
       trl_event,
       trl_act,
       trl_part,
       trl_part_org,
       trl_qty,
       par_uom,
       trl_price,
       trl_qty * trl_price,
       ttr_fleetmarkup,
       trl_date,
       DECODE( trl_fleetchecked, 'F', '+', '-' ),
       DECODE( trl_fleetchecked, 'M', '+', 'N', '-', '' )
FROM   r5parts, r5translines, r5temptranslines, r5tempbillsublines
WHERE  trl_trans       = ttr_trans
AND    trl_line        = ttr_transline
AND    trl_part        = par_code
AND    trl_part_org    = par_org
AND    ttr_tempsubline = tfs_pk
AND    ttr_fleetchecked NOT IN ( '-', '+' )
/
