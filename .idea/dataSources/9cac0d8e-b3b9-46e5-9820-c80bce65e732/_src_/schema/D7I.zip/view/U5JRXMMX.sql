CREATE VIEW U5JRXMMX AS select 
	gd.evt_org,gd.evt_code,gd.evt_desc,gd.evt_object,gd.obj_desc,gd.evt_project,
	sum(gd.rengong) rengong,sum(gd.gongju) gongju,sum(gd.beijian) beijian
from (
		--计算供应商工时
	select 
		t1.EVT_ORG,t1.evt_code,t1.evt_desc,t1.evt_object,t3.obj_desc,t1.evt_project,
		t2.boo_RATE*T2.BOO_HOURS rengong,0 gongju,0 beijian
	from
		r5events t1,
		r5bookedhours t2,
		r5objects     t3
	where
		t1.evt_code=t2.boo_event
		and t1.evt_object=t3.obj_code
		and t3.obj_obrtype='A'
		and t2.boo_person is null
	union all
	--计算工具费用
	select 
		t4.EVT_ORG,t4.evt_code,t4.evt_desc,t4.evt_object,t6.obj_desc,t4.evt_project,
		0 rengong,t5.tou_QTY*T5.TOU_TARIFF*T5.TOU_HOURS gongju,0 beijian
	from
		r5events t4,
		r5toolusage t5,
		r5objects     t6
	where
		t4.evt_code=t5.tou_event
		and t4.evt_object=t6.obj_code
		and t6.obj_obrtype='A'	
	union all
	--计算物料使用
	select 
		t7.EVT_ORG,
		t7.evt_code,t7.evt_desc,t7.evt_object,t9.obj_desc,t7.evt_project,
		0 rengong,0 gongju,t8.trl_price*t8.trl_qty beijian
	from
		r5events t7,
		r5translines t8,
		r5objects     t9
	where
		t7.evt_code=t8.trl_event
		and t7.evt_object=t9.obj_code
		and t9.obj_obrtype='A'
		and t8.trl_type='I'
	 )gd
group by  gd.evt_org,gd.evt_code,gd.evt_desc,gd.evt_object,gd.obj_desc,gd.evt_project
/
