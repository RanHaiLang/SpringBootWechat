CREATE VIEW U5PRCBHZ AS SELECT
T1."TRL_STORE",T1."TRL_DATE",T1."TRL_PART",T1."TRL_PRICE",T1."YANSHOU_QTY",T1."TUIHUO_QTY",T1."YIRU_QTY",T1."YICHU_QTY",T1."XIAOHAO_QTY",T1."XIAOSHOU_QTY",T1."PANDIAN_QTY",T1."STO_QTY",T1."STO_AVGPRICE",
T4.STR_DESC,
T2.PAR_CLASS,
T6.CLS_DESC,
T3.OBJ_DESC,
T2.PAR_CATEGORY,
T2.PAR_DESC,
T5.UOM_DESC,
TO_DATE(TO_CHAR(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd') CUR_DATE,
T1.ORG,
T1.PAR_UDFCHAR01
FROM
(
  SELECT
  T1.STO_STORE TRL_STORE ,
  to_date('9999-01-01','yyyy-mm-dd') TRL_DATE ,
  T1.STO_PART TRL_PART,
  0 TRL_PRICE,
  0 YANSHOU_qty,
  0 TUIHUO_qty,
  0 YIRU_qty,
  0 YICHU_qty,
  0 XIAOHAO_qty ,
  0 XIAOSHOU_QTY,
  0 PANDIAN_qty,
  T1.STO_QTY,
  T1.STO_AVGPRICE,
  t1.STO_PART_ORG "ORG",
  T11.PAR_UDFCHAR01
  FROM
  R5STOCK T1,
  R5PARTS T11
  WHERE
  	T1.STO_PART=T11.PAR_CODE AND T11.PAR_NOTUSED='-'
 UNION ALL
  select
  a.trl_store, TO_DATE(a.trl_date,'yyyy-mm-dd') trl_date ,A.TRL_PART,A.TRL_PRICE,
  SUM(YANSHOU_qty) YANSHOU_qty,
  SUM(TUIHUO_qty)  TUIHUO_qty,
  SUM(YIRU_qty)    YIRU_qty,
  SUM(YICHU_qty)   YICHU_qty,
  SUM(XIAOHAO_qty)  XIAOHAO_qty ,
  SUM(XIAOSHOU_qty) XIAOSHOU_qty,
  SUM(PANDIAN_qty)  PANDIAN_qty ,
  0 STO_QTY,
  0 STO_AVGPRICE,
  A.ORG,
  A.PAR_UDFCHAR01
  from
  (
    select
    to_char(t3.TRL_UPDATED,'YYYY-MM-DD') trl_date,
    t3.trl_store,
    T3.TRL_PART,
    T3.TRL_PRICE,
    case when t3.trl_type = 'RECV' AND T2.TRA_FROMENTITY = 'COMP' AND T2.TRA_TOENTITY = 'STOR' THEN  abs(t3.trl_qty)    ELSE 0 END  YANSHOU_qty,       -- 验收
    case when t3.trl_type = 'RETN' AND T2.TRA_FROMENTITY = 'STOR' AND T2.TRA_TOENTITY = 'COMP' THEN  abs(t3.trl_qty)    ELSE 0 END  TUIHUO_qty,       -- 退货
    case when t3.trl_type = 'RECV' AND T2.TRA_FROMENTITY = 'STOR' AND T2.TRA_TOENTITY = 'STOR' THEN  abs(t3.trl_qty)    ELSE 0 END  YIRU_qty,       --移入
    case when t3.trl_type = 'I'    AND T2.TRA_FROMENTITY = 'STOR' AND T2.TRA_TOENTITY = 'STOR' THEN  abs(t3.trl_qty)    ELSE 0 END  YICHU_qty,       --移出
    case when t3.trl_type = 'I'    AND T2.TRA_FROMENTITY = 'STOR' AND T2.TRA_TOENTITY = 'EVNT' AND T2.TRA_ADVICE IS NULL  THEN  t3.trl_qty   ELSE 0 END  XIAOHAO_qty,  --消耗
    case when t3.trl_type = 'I'    AND T2.TRA_FROMENTITY = 'STOR' AND T2.TRA_TOENTITY = 'EVNT' AND T2.TRA_ADVICE IS NOT NULL  THEN  t3.trl_qty    ELSE 0 END  XIAOSHOU_qty,  --销售
    case when t3.trl_type = 'STTK' AND T2.TRA_FROMENTITY = 'STOR' THEN  t3.trl_qty    ELSE 0 END  PANDIAN_qty,        -- 盘点
    T2.TRA_ORG "ORG",
    T23.PAR_UDFCHAR01
    from
    r5transactions t2,
    r5translines   t3,
    R5PARTS T23
    WHERE
    T23.PAR_CODE=T3.TRL_PART AND
    t2.tra_code=t3.trl_trans AND t2.TRA_ORG=t23.PAR_ORG 
    and t2.tra_status='A' AND t2.TRA_FROMCODE<>t2.TRA_TOCODE
  )  a
  group by A.ORG,a.trl_store, a.trl_date,A.PAR_UDFCHAR01,A.TRL_PART,A.TRL_PRICE
) T1,
	R5PARTS T2,
	R5OBJECTS T3,
	R5STORES T4,
	R5UOMS   T5,
	(SELECT
		IT.CLS_CODE,
		IT.CLS_DESC
	FROM
		R5CLASSES IT
	WHERE
		IT.CLS_ENTITY='PART') T6
WHERE
	T1.TRL_PART = T2.PAR_CODE(+)
	AND T1.TRL_STORE = T4.STR_CODE(+)
	AND T2.PAR_CATEGORY = T3.OBJ_CODE(+)
	AND T3.OBJ_OBTYPE(+) = 'C'
	AND T3.OBJ_CLASS(+) =  'W000'
	AND T2.PAR_UOM = T5.UOM_CODE
	and t6.cls_code(+)=t2.par_class
   	AND t2.par_org=t1.org
/
