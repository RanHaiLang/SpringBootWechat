CREATE VIEW U5PRCKMX AS SELECT   T1.TRL_TRANS,
      t1.trl_line,
            T1.TRL_EVENT,
            T1.TRL_ACT,
            T1.TRL_PART,
            T1.TRL_BIN,
            T1.TRL_PRICE,
            -- T1.TRL_AVGPRICE "TRL_PRICE",
            T1.TRL_QTY,
            T1.TRL_PRICE * T1.TRL_QTY "TOTAL",
            T1.TRL_LOT,
            T1.TRL_COSTCODE,
            T4.PAR_UDFCHAR01,
            T1.TRL_PICKLIST,
            T1.TRL_UPDATED TRL_UPDATED,
            T3.STR_CODE,
            T3.STR_CLASS,
            T4.PAR_DESC,
            T4.PAR_CLASS,
            T4.PAR_CATEGORY,
            T4.PAR_ORG,
            T4.PAR_UDFCHAR02,
            T4.PAR_UDFCHAR08,
            T4.PAR_REPAIRABLE,
            T5.MRC_CODE,
            T5.MRC_DESC,
            T6.UOM_DESC,
            T.TRA_CODE,
            T.TRA_PERS TRA_PERSC,
            T.TRA_AUTH,
            (SELECT   USR_DESC
               FROM   R5USERS
              WHERE   USR_CODE = T.TRA_AUTH)
               USR_DESC,
            (SELECT   PER_DESC
               FROM   R5PERSONNEL
              WHERE   PER_CODE = T.TRA_PERS)
               TRA_PERS,
            T2.EVT_OBJECT,
            T7.OBJ_DESC,
            T7.OBJ_OBTYPE,--资产类型
            T7.OBJ_CLASS,--资产分类
            (select CLS_DESC from R5CLASSES where cls_entity = 'OBJ' AND CLS_CODE=t7.obj_class
            ) ZCFL,
            T7.OBJ_UDFCHAR03,--系统分类
            (SELECT OBJ_DESC from R5OBJECTS T8 where T8.OBJ_ORG=T7.OBJ_ORG AND OBJ_OBTYPE = 'S' AND T8.OBJ_CODE=T7.OBJ_UDFCHAR03
            ) XTFL,
            T2.EVT_CODE,
            t.TRA_ORG,
            T.TRA_DATE
     FROM   R5TRANSACTIONS T,
            R5TRANSLINES T1,
            R5EVENTS T2,
            R5STORES T3,
            R5PARTS T4,
            R5MRCS T5,
            R5UOMS T6,
            R5OBJECTS T7
           -- R5OBJECTS T8,
            --R5CLASSES T9
    WHERE
             T.TRA_CODE = T1.TRL_TRANS
            AND T1.TRL_EVENT = T2.EVT_CODE
            AND T1.TRL_STORE = T3.STR_CODE
            AND T1.TRL_PART = T4.PAR_CODE
            AND T2.EVT_MRC = T5.MRC_CODE
            AND T4.PAR_UOM = T6.UOM_CODE
            AND T1.TRL_TYPE = ('I')
            AND T.TRA_STATUS = 'A'
            AND T2.EVT_OBJECT = T7.OBJ_CODE
            AND T7.OBJ_OBTYPE <> 'C'
            AND T7.OBJ_ORG=t.TRA_ORG
            AND T.TRA_ORG=T2.EVT_ORG
            AND T.TRA_ORG=T4.PAR_ORG
/
