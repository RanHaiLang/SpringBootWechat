CREATE VIEW U5PRRKMX AS select
    t1.tra_code,
    T1.TRA_TYPE,
    t2.trl_part,
    t3.par_class,
    t3.par_category,
    t3.par_desc,
    t3.par_UDFCHAR01,
    t4.uom_desc,
    t2.TRL_UPDATED trl_date,
    (SELECT TXV_PERCENT/100 FROM R5TAXRATEVALUES WHERE TXV_RATE = (SELECT TCR_RATE FROM R5TAXCODERATES WHERE TCR_TAX=t6.ORL_TAX)) TXV_PERCENT,
    t2.TRL_PRICE trlprice,
    round(t2.TRL_PRICE *(1+nvl((SELECT TXV_PERCENT/100 FROM R5TAXRATEVALUES WHERE TXV_RATE = (SELECT TCR_RATE FROM R5TAXCODERATES WHERE TCR_TAX=t6.ORL_TAX)),0)),2) trl_price,
    t2.trl_qty*t2.trl_IO trl_qty,
    round(t2.TRL_PRICE * t2.trl_qty *(1+nvl((SELECT TXV_PERCENT/100 FROM R5TAXRATEVALUES WHERE TXV_RATE = (SELECT TCR_RATE FROM R5TAXCODERATES WHERE TCR_TAX=t6.ORL_TAX)),0)),2) *t2.trl_io money1,
    t2.trl_qty*t2.trl_price*t2.trl_io money2,
    t2.trl_bin,
    t1.tra_fromcode,
    t1.tra_tocode,
    t1.TRA_ORDER,
    t2.trl_dckcode,
    t5.str_code,
    T5.STR_DESC,
    t5.str_class,
    T3.PAR_ORG,
    T2.TRL_LOT,
    t6.ORL_TAX
from 
    R5TRANSACTIONS t1,
    r5TRANSLINES t2,
    r5parts  t3,
    r5uoms t4,
    r5stores t5,
    R5ORDERLINES t6
where 
    t1.tra_rstatus='A' 
    and  t1.tra_type in( 'RECV','RETN')
    and  t1.TRA_FROMENTITY||T1.TRA_TOENTITY IN ('COMPSTOR','STORCOMP')
    and t1.tra_code=t2.trl_trans
    and t2.trl_part=t3.par_code
    and t3.par_uom=t4.uom_code
    and t2.trl_store=t5.str_code
    AND t1.TRA_ORG=T3.PAR_ORG
    AND t2.TRL_ORDER = t6.ORL_ORDER(+) 
    AND t2.TRL_ORDLINE = t6.ORL_ORDLINE(+)
/
