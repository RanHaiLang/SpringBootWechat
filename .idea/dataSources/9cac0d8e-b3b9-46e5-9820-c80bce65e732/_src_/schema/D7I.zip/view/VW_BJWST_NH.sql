CREATE VIEW VW_BJWST_NH AS SELECT 
  t0.rea_date,
  SUM(DECODE(t0.rea_uom,'JWD',NVL(t0.REA_DIFF,0),0)) "JWD",--温度
  SUM(DECODE(t0.rea_uom,'JSD',NVL(t0.REA_DIFF,0),0)) "JSD",--湿度
  SUM(DECODE(t0.rea_uom,'JKFJ',NVL(t0.REA_DIFF,0),0)) "JKFJ",--入住房间数
  SUM(DECODE(t0.rea_uom,'JKRS',NVL(t0.REA_DIFF,0),0)) "JKRS",--入住人数
  SUM(DECODE(t0.rea_uom,'JKRL',NVL(t0.REA_DIFF,0),0)) "JKRL",--入住率
  SUM(DECODE(t0.rea_uom,'JCRS',NVL(t0.REA_DIFF,0),0)) "JCRS",--餐饮部就餐人数
  SUM(DECODE(t0.rea_uom,'JLRS',NVL(t0.REA_DIFF,0),0)) "JLRS",--康乐部客人数
  SUM(DECODE(t0.rea_uom,'JKRSY',NVL(t0.REA_DIFF,0),0)) "JKRSY",--客房部日收益
  SUM(DECODE(t0.rea_uom,'JCRSY',NVL(t0.REA_DIFF,0),0)) "JCRSY",--餐饮部日收益
  SUM(DECODE(t0.rea_uom,'JKLSY',NVL(t0.REA_DIFF,0),0)) "JKLSY",--康乐部日收益
  SUM(DECODE(t0.rea_uom,'JZRSY',NVL(t0.REA_DIFF,0),0)) "JZRSY",--酒店总日收入
  SUM(DECODE(t0.rea_uom,'JZDL',NVL(t0.REA_DIFF,0),0)) "JZDL",--总用电量
  SUM(DECODE(t0.rea_uom,'JZDE',NVL(t0.REA_DIFF,0),0)) "JZDE",--总用电额
  SUM(DECODE(t0.rea_uom,'JTDL',NVL(t0.REA_DIFF,0),0)) "JTDL",--空调用电量
  SUM(DECODE(t0.rea_uom,'JYDQ',NVL(t0.REA_DIFF,0),0)) "JYDQ",--用电效率(电量kwh/100元总收入)
  SUM(DECODE(t0.rea_uom,'JZRL',NVL(t0.REA_DIFF,0),0)) "JZRL",--总用气量
  SUM(DECODE(t0.rea_uom,'JZRE',NVL(t0.REA_DIFF,0),0)) "JZRE",--总用气额
  SUM(DECODE(t0.rea_uom,'JCRL',NVL(t0.REA_DIFF,0),0)) "JCRL",--餐饮气量
  SUM(DECODE(t0.rea_uom,'JGRL',NVL(t0.REA_DIFF,0),0)) "JGRL",--锅炉用气  
  SUM(DECODE(t0.rea_uom,'JRQQ',NVL(t0.REA_DIFF,0),0)) "JRQQ",--燃气效率(燃气量nm?/100元总收入)
  SUM(DECODE(t0.rea_uom,'JRCQL',NVL(t0.REA_DIFF,0),0)) "JRCQL",--餐饮用气效率(餐饮用气量nm?/100元餐饮收入)
  SUM(DECODE(t0.rea_uom,'JZSL',NVL(t0.REA_DIFF,0),0)) "JZSL",--总用水量
  SUM(DECODE(t0.rea_uom,'JZSE',NVL(t0.REA_DIFF,0),0)) "JZSE",--总用水额
  SUM(DECODE(t0.rea_uom,'JYSQ',NVL(t0.REA_DIFF,0),0)) "JYSQ",--用水效率(水量m?/100元总收入)
  SUM(DECODE(t0.rea_uom,'ELDL',NVL(t0.REA_DIFF,0),0)) "ELDL",--制冷机房用电
  SUM(DECODE(t0.rea_uom,'ERDL',NVL(t0.REA_DIFF,0),0)) "ERDL",--热力站
  SUM(DECODE(t0.rea_uom,'EZDL',NVL(t0.REA_DIFF,0),0)) "EZDL",--中水机房
  SUM(DECODE(t0.rea_uom,'EGDL',NVL(t0.REA_DIFF,0),0)) "EGDL",--锅炉房
  SUM(DECODE(t0.rea_uom,'EFZDL',NVL(t0.REA_DIFF,0),0)) "EFZDL",--F20照明干线
  SUM(DECODE(t0.rea_uom,'EZMDL',NVL(t0.REA_DIFF,0),0)) "EZMDL",--B2J-F5照明干线
  SUM(DECODE(t0.rea_uom,'EZRL',NVL(t0.REA_DIFF,0),0)) "EZRL"--餐饮用气量
FROM
  R5READINGS t0
WHERE
  t0.REA_OBJECT_ORG='BJWST'
GROUP BY
  t0.rea_date
ORDER BY
  t0.rea_date
/
