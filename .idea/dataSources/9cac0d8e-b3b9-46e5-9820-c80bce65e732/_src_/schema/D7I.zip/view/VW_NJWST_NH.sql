CREATE VIEW VW_NJWST_NH AS SELECT
  to_char(t0.rea_date,'yyyy/mm/dd') "REA_DATE",
  SUM(DECODE(t0.rea_uom,'JWD',NVL(t0.REA_DIFF,0),0)) "JWD",--温度
  SUM(DECODE(t0.rea_uom,'JSD',NVL(t0.REA_DIFF,0),0)) "JSD",--湿度
  SUM(DECODE(t0.rea_uom,'JKFJ',NVL(t0.REA_DIFF,0),0)) "JKFJ",--入住房间数
  SUM(DECODE(t0.rea_uom,'JKRS',NVL(t0.REA_DIFF,0),0)) "JKRS",--入住人数
  SUM(DECODE(t0.rea_uom,'JKRL',NVL(t0.REA_DIFF,0),0)) "JKRL",--入住率
  SUM(DECODE(t0.rea_uom,'JCRS',NVL(t0.REA_DIFF,0),0)) "JCRS",--餐饮部就餐人数
  SUM(DECODE(t0.rea_uom,'JLRS',NVL(t0.REA_DIFF,0),0)) "JLRS",--康乐部客人数
  SUM(DECODE(t0.rea_uom,'JKRSY',NVL(t0.REA_DIFF,0),0)) "JKRSY",--客房部日收益
  SUM(DECODE(t0.rea_uom,'JCRSY',NVL(t0.REA_DIFF,0),0)) "JCRSY",--餐饮部日收益
  SUM(DECODE(t0.rea_uom,'JKLSY',NVL(t0.REA_DIFF,0),0)) "JKLSY",--康乐部日收益
  SUM(DECODE(t0.rea_uom,'JZRSY',NVL(t0.REA_DIFF,0),0)) "JZRSY",--酒店总日收入
  SUM(DECODE(t0.rea_uom,'JZDL',NVL(t0.REA_DIFF,0),0)) "JZDL",--总用电量
  SUM(DECODE(t0.rea_uom,'JZDE',NVL(t0.REA_DIFF,0),0)) "JZDE",--总用电额
  SUM(DECODE(t0.rea_uom,'JTDL',NVL(t0.REA_DIFF,0),0)) "JTDL",--空调用电量
  SUM(DECODE(t0.rea_uom,'JYDQ',NVL(t0.REA_DIFF,0),0)) "JYDQ",--用电效率(电量kwh/100元总收入)
  SUM(DECODE(t0.rea_uom,'JZRL',NVL(t0.REA_DIFF,0),0)) "JZRL",--总用气量
  SUM(DECODE(t0.rea_uom,'JZRE',NVL(t0.REA_DIFF,0),0)) "JZRE",--总用气额
  SUM(DECODE(t0.rea_uom,'JCRL',NVL(t0.REA_DIFF,0),0)) "JCRL",--餐饮气量
  SUM(DECODE(t0.rea_uom,'JGRL',NVL(t0.REA_DIFF,0),0)) "JGRL",--锅炉用气
  SUM(DECODE(t0.rea_uom,'LYCR',NVL(t0.REA_DIFF,0),0)) "LYCR",--员工厨房
  SUM(DECODE(t0.rea_uom,'LRCR',NVL(t0.REA_DIFF,0),0)) "LRCR",--西厨房
  SUM(DECODE(t0.rea_uom,'LRMR',NVL(t0.REA_DIFF,0),0)) "LRMR",--全日明档
  SUM(DECODE(t0.rea_uom,'LZCR',NVL(t0.REA_DIFF,0),0)) "LZCR",--中厨房
  SUM(DECODE(t0.rea_uom,'LRSR',NVL(t0.REA_DIFF,0),0)) "LRSR",--热水锅炉
  SUM(DECODE(t0.rea_uom,'LZQR',NVL(t0.REA_DIFF,0),0)) "LZQR",--蒸汽锅炉
  SUM(DECODE(t0.rea_uom,'JRQQ',NVL(t0.REA_DIFF,0),0)) "JRQQ",--燃气效率(燃气量nm?/100元总收入)
  SUM(DECODE(t0.rea_uom,'JRCQL',NVL(t0.REA_DIFF,0),0)) "JRCQL",--餐饮用气效率(餐饮用气量nm?/100元餐饮收入)
  SUM(DECODE(t0.rea_uom,'JZSL',NVL(t0.REA_DIFF,0),0)) "JZSL",--总用水量
  SUM(DECODE(t0.rea_uom,'JZSE',NVL(t0.REA_DIFF,0),0)) "JZSE",--总用水额
  SUM(DECODE(t0.rea_uom,'LCLS',NVL(t0.REA_DIFF,0),0)) "LCLS",--厨房用水量
  SUM(DECODE(t0.rea_uom,'LZLS',NVL(t0.REA_DIFF,0),0)) "LZLS",--中厨房
  SUM(DECODE(t0.rea_uom,'LWLS',NVL(t0.REA_DIFF,0),0)) "LWLS",--西厨房
  SUM(DECODE(t0.rea_uom,'LELS',NVL(t0.REA_DIFF,0),0)) "LELS",--员工厨房
  SUM(DECODE(t0.rea_uom,'JKLS',NVL(t0.REA_DIFF,0),0)) "JKLS",--客房
  SUM(DECODE(t0.rea_uom,'LXLS',NVL(t0.REA_DIFF,0),0)) "LXLS",--洗衣房
  SUM(DECODE(t0.rea_uom,'LYLS',NVL(t0.REA_DIFF,0),0)) "LYLS",--泳池
  SUM(DECODE(t0.rea_uom,'LGLS',NVL(t0.REA_DIFF,0),0)) "LGLS",--员工更衣室
  SUM(DECODE(t0.rea_uom,'JYSQ',NVL(t0.REA_DIFF,0),0)) "JYSQ"--用水效率(水量m?/100元总收入)
FROM
  R5READINGS t0
WHERE
  t0.REA_OBJECT_ORG='NJWST'
GROUP BY
  t0.rea_date
ORDER BY
  t0.rea_date
/
