CREATE VIEW VW_SYLS_NH AS SELECT 
  t0.rea_date,
SUM(DECODE(t0.rea_uom,'JCRS',NVL(t0.REA_DIFF,0),0)) "JCRS",--就餐人数
SUM(DECODE(t0.rea_uom,'JLRS',NVL(t0.REA_DIFF,0),0)) "JLRS",--客人数
SUM(DECODE(t0.rea_uom,'JKRSY',NVL(t0.REA_DIFF,0),0)) "JKRSY",--客房部日收益
SUM(DECODE(t0.rea_uom,'JCRSY',NVL(t0.REA_DIFF,0),0)) "JCRSY",--餐饮部日收益
SUM(DECODE(t0.rea_uom,'JKLSY',NVL(t0.REA_DIFF,0),0)) "JKLSY",--康乐部日收益
SUM(DECODE(t0.rea_uom,'JZRSY',NVL(t0.REA_DIFF,0),0)) "JZRSY",--酒店总收入日收益
SUM(DECODE(t0.rea_uom,'JWD',NVL(t0.REA_DIFF,0),0)) "JWD",--温度
SUM(DECODE(t0.rea_uom,'JSD',NVL(t0.REA_DIFF,0),0)) "JSD",--湿度
SUM(DECODE(t0.rea_uom,'JKFJ',NVL(t0.REA_DIFF,0),0)) "JKFJ",--入住房间数
SUM(DECODE(t0.rea_uom,'JKRS',NVL(t0.REA_DIFF,0),0)) "JKRS",--入住人数
SUM(DECODE(t0.rea_uom,'JZDL',NVL(t0.REA_DIFF,0),0)) "JZDL",--总用电量
SUM(DECODE(t0.rea_uom,'JZDE',NVL(t0.REA_DIFF,0),0)) "JZDE",--总用电额
SUM(DECODE(t0.rea_uom,'JTDL',NVL(t0.REA_DIFF,0),0)) "JTDL",--空调电量
SUM(DECODE(t0.rea_uom,'JZSL',NVL(t0.REA_DIFF,0),0)) "JZSL",--总用水量
SUM(DECODE(t0.rea_uom,'JZSE',NVL(t0.REA_DIFF,0),0)) "JZSE",--总用水额
SUM(DECODE(t0.rea_uom,'JZRL',NVL(t0.REA_DIFF,0),0)) "JZRL",--总用燃气量
SUM(DECODE(t0.rea_uom,'JZRE',NVL(t0.REA_DIFF,0),0)) "JZRE",--总用燃气额
SUM(DECODE(t0.rea_uom,'JZZL',NVL(t0.REA_DIFF,0),0)) "JZZL",--总用蒸汽量
SUM(DECODE(t0.rea_uom,'JZZE',NVL(t0.REA_DIFF,0),0)) "JZZE",--总用蒸汽额
SUM(DECODE(t0.rea_uom,'JCRL',NVL(t0.REA_DIFF,0),0)) "JCRL",--餐饮
SUM(DECODE(t0.rea_uom,'F1RL',NVL(t0.REA_DIFF,0),0)) "F1RL",--宴会厨房
SUM(DECODE(t0.rea_uom,'F2RL',NVL(t0.REA_DIFF,0),0)) "F2RL",--全日餐厅1
SUM(DECODE(t0.rea_uom,'F3RL',NVL(t0.REA_DIFF,0),0)) "F3RL",--全日餐厅2 
SUM(DECODE(t0.rea_uom,'F4RL',NVL(t0.REA_DIFF,0),0)) "F4RL",--中厨房
SUM(DECODE(t0.rea_uom,'F5RL',NVL(t0.REA_DIFF,0),0)) "F5RL",--意大利厨房
SUM(DECODE(t0.rea_uom,'F6RL',NVL(t0.REA_DIFF,0),0)) "F6RL",--员工厨房
SUM(DECODE(t0.rea_uom,'F7RL',NVL(t0.REA_DIFF,0),0)) "F7RL",--烧烤吧
SUM(DECODE(t0.rea_uom,'JGRL',NVL(t0.REA_DIFF,0),0)) "JGRL",--锅炉
SUM(DECODE(t0.rea_uom,'JXZL',NVL(t0.REA_DIFF,0),0)) "JXZL",--洗衣房
SUM(DECODE(t0.rea_uom,'F1ZL',NVL(t0.REA_DIFF,0),0)) "F1ZL",--厨房蒸汽
SUM(DECODE(t0.rea_uom,'F2ZL',NVL(t0.REA_DIFF,0),0)) "F2ZL",--SPA蒸汽
SUM(DECODE(t0.rea_uom,'JLSL',NVL(t0.REA_DIFF,0),0)) "JLSL",--康乐
SUM(DECODE(t0.rea_uom,'JJSL',NVL(t0.REA_DIFF,0),0)) "JJSL",--景观
SUM(DECODE(t0.rea_uom,'JYDQ',NVL(t0.REA_DIFF,0),0)) "JYDQ",--用电效率
SUM(DECODE(t0.rea_uom,'JYSQ',NVL(t0.REA_DIFF,0),0)) "JYSQ",--用水效率
SUM(DECODE(t0.rea_uom,'JRQQ',NVL(t0.REA_DIFF,0),0)) "JRQQ",--燃气效率
SUM(DECODE(t0.rea_uom,'JRCQL',NVL(t0.REA_DIFF,0),0)) "JRCQL"--餐饮用气效率

FROM
  R5READINGS t0
WHERE
  t0.REA_OBJECT_ORG='SYLS' 
GROUP BY
  t0.rea_date
ORDER BY
  t0.rea_date
/
