CREATE VIEW VW_SZWH_NH AS SELECT 
  t0.rea_date,
SUM(DECODE(t0.rea_uom,'JWD',NVL(t0.REA_DIFF,0),0)) "JWD",--温度
SUM(DECODE(t0.rea_uom,'JSD',NVL(t0.REA_DIFF,0),0)) "JSD",--湿度
SUM(DECODE(t0.rea_uom,'JKFJ',NVL(t0.REA_DIFF,0),0)) "JKFJ",--入住房间数
SUM(DECODE(t0.rea_uom,'JKRS',NVL(t0.REA_DIFF,0),0)) "JKRS",--入住人数
SUM(DECODE(t0.rea_uom,'JKRL',NVL(t0.REA_DIFF,0),0)) "JKRL",--入住率
SUM(DECODE(t0.rea_uom,'JCRS',NVL(t0.REA_DIFF,0),0)) "JCRS",--就餐人数
SUM(DECODE(t0.rea_uom,'JKRSY',NVL(t0.REA_DIFF,0),0)) "JKRSY",--日收益
SUM(DECODE(t0.rea_uom,'JCRSY',NVL(t0.REA_DIFF,0),0)) "JCRSY",--日收益
SUM(DECODE(t0.rea_uom,'JKLSY',NVL(t0.REA_DIFF,0),0)) "JKLSY",--日收益
SUM(DECODE(t0.rea_uom,'JZRSY',NVL(t0.REA_DIFF,0),0)) "JZRSY",--日收益
SUM(DECODE(t0.rea_uom,'JZDL',NVL(t0.REA_DIFF,0),0)) "JZDL",--总用电量
SUM(DECODE(t0.rea_uom,'JZSL',NVL(t0.REA_DIFF,0),0)) "JZSL",--总用水量
SUM(DECODE(t0.rea_uom,'JZRL',NVL(t0.REA_DIFF,0),0)) "JZRL",--总用燃气量
SUM(DECODE(t0.rea_uom,'HXDL',NVL(t0.REA_DIFF,0),0)) "HXDL",--洗衣房用电
SUM(DECODE(t0.rea_uom,'HCDL',NVL(t0.REA_DIFF,0),0)) "HCDL",--厨房用电
SUM(DECODE(t0.rea_uom,'JCRL',NVL(t0.REA_DIFF,0),0)) "JCRL",--餐饮
SUM(DECODE(t0.rea_uom,'JGRL',NVL(t0.REA_DIFF,0),0)) "JGRL",--锅炉
SUM(DECODE(t0.rea_uom,'HYRL',NVL(t0.REA_DIFF,0),0)) "HYRL",--宴会厨房
SUM(DECODE(t0.rea_uom,'HCRL',NVL(t0.REA_DIFF,0),0)) "HCRL",--中厨房
SUM(DECODE(t0.rea_uom,'HXRL',NVL(t0.REA_DIFF,0),0)) "HXRL",--西厨房
SUM(DECODE(t0.rea_uom,'HKRL',NVL(t0.REA_DIFF,0),0)) "HKRL",--开放厨房
SUM(DECODE(t0.rea_uom,'HJRL',NVL(t0.REA_DIFF,0),0)) "HJRL",--粗加工厨房
SUM(DECODE(t0.rea_uom,'HERL',NVL(t0.REA_DIFF,0),0)) "HERL",--员工厨房
SUM(DECODE(t0.rea_uom,'HRSR',NVL(t0.REA_DIFF,0),0)) "HRSR",--热水锅炉
SUM(DECODE(t0.rea_uom,'HZQR',NVL(t0.REA_DIFF,0),0)) "HZQR",--蒸汽锅炉
SUM(DECODE(t0.rea_uom,'HCLS',NVL(t0.REA_DIFF,0),0)) "HCLS",--厨房用水
SUM(DECODE(t0.rea_uom,'HXLS',NVL(t0.REA_DIFF,0),0)) "HXLS",--洗衣用水
SUM(DECODE(t0.rea_uom,'JYDQ',NVL(t0.REA_DIFF,0),0)) "JYDQ",--用电效率
SUM(DECODE(t0.rea_uom,'JYSQ',NVL(t0.REA_DIFF,0),0)) "JYSQ",--用水效率
SUM(DECODE(t0.rea_uom,'JRQQ',NVL(t0.REA_DIFF,0),0)) "JRQQ",--燃气效率
SUM(DECODE(t0.rea_uom,'JRCQL',NVL(t0.REA_DIFF,0),0)) "JRCQL"--餐饮用气效率


FROM
  R5READINGS t0
WHERE
  t0.REA_OBJECT_ORG='SZWH' 
GROUP BY
  t0.rea_date
ORDER BY
  t0.rea_date
/
