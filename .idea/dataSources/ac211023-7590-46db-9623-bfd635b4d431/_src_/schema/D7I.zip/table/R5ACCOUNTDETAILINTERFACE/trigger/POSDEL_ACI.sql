CREATE TRIGGER POSDEL_ACI
  
 AFTER DELETE 
	
  ON R5ACCOUNTDETAILINTERFACE
  
 FOR EACH ROW 
DECLARE
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    o7interface.delint( 'R5ACCOUNTDETAILINTERFACE', :old.aci_transid, NULL, NULL );
    o7interface.arcdel( :old.aci_transorgid );
  END IF;
END posdel_aci;
/
