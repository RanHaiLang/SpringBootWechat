CREATE TRIGGER POSUPD_ACI
  
 AFTER UPDATE 
	
  ON R5ACCOUNTDETAILINTERFACE
  
 FOR EACH ROW 
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    INSERT INTO r5archivetemp
       ( art_sessionid,
         art_action,
         art_transapiid,
         art_transorgid,
         art_transgroup,
         art_trans,
         art_apirtype,
         art_apitable,
         art_apiprefix )
    SELECT USERENV('SESSIONID'),
         'POST-UPDATE',
         :new.aci_transid,
         :new.aci_transorgid,
         :new.aci_transgroup,
         :new.aci_trans,
         'H',
         'R5ACCOUNTDETAILINTERFACE',
         'ACI'
    FROM DUAL;
  END IF;
END posupd_aci;
/
