CREATE TRIGGER POSDEL_ACK
  
 AFTER DELETE 
	
  ON R5ACTCHECKLISTS
  
 FOR EACH ROW 
DECLARE
   checkresult  VARCHAR2(  4 );
   cerrsource   VARCHAR2( 32 );
   cerrortype   VARCHAR2(  4 );
   x            VARCHAR2(  1 );
   db_error     EXCEPTION;
BEGIN
   IF o7gtsusr <> 'SYS' THEN
/* Initialize   */
     checkresult  := '0';
     cerrsource   := NULL;
     cerrortype   := NULL;
     x            := NULL;
/* Delete dependant data */
     o7descs( 'DEL', x, 'TCLI', x, '*', :old.ack_code, x, x, checkresult );
     IF checkresult <> '0' THEN
        cerrsource := 'O7DESCS';
        cerrortype   := 'PROC';
        RAISE db_error;
     END IF;
     IF :old.ack_act = 0 THEN
         -- Reset Permit To Work esignature information
         UPDATE r5permittowork SET ptw_reviewed = null, ptw_reviewedby = null, ptw_reviewedtype = null WHERE ptw_code = :old.ack_event;
     END IF;
   END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrortype, checkresult, SQLCODE );
END POSDEL_ACK;
/
