CREATE TRIGGER PREINS_ACL
  
 BEFORE INSERT 
	
  ON R5ACTCLASSES
  
 FOR EACH ROW 
DECLARE
   checkresult  VARCHAR2(  4 );
   x            VARCHAR2(  1 );
   countit      NUMBER;
   cerrsource   VARCHAR2( 32 );
   cerrtype     VARCHAR2(  4 );
   db_error     EXCEPTION;
   cgeneral     r5actioncodes.acc_gen%TYPE;
   CURSOR c_acc IS
     SELECT a.acc_gen
     FROM   r5actioncodes a
     WHERE  a.acc_code = :new.acl_action;
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Initialize */
   checkresult := '0';
   x           := NULL;
   countit     := 0;
   cerrsource  := 'PREINS_ACL';
   cerrtype    := 'TRIG';
/* A07121 : Class must exist ( r5classes, entity = 'OBJ' ) */
   r5o7.o7exist( 'CLAS', 'OBJ', :new.acl_class,:new.acl_class_org, '*', x, x, x, x,
            countit, checkresult );
   IF countit > 0 THEN
      NULL;
   ELSIF countit = 0 THEN
      checkresult := '1';
      RAISE db_error;
   ELSE
      cerrsource := 'O7EXIST';
      cerrtype   := 'PROC';
      RAISE db_error;
   END IF;
/* A07123 : Action Code can't be general (r5actioncodes) */
   OPEN  c_acc;
   FETCH c_acc INTO cgeneral;
   IF c_acc%NOTFOUND THEN
      CLOSE c_acc;
      checkresult := '999';
      RAISE db_error;
   ELSE
      CLOSE c_acc;
      IF cgeneral = '+' THEN
         checkresult := '2';
         RAISE db_error;
      END IF;
   END IF;
 END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preins_acl;
/
