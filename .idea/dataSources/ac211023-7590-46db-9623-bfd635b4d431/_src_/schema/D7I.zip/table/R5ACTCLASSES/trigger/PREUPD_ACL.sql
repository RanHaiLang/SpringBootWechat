CREATE TRIGGER PREUPD_ACL
  
 BEFORE UPDATE 
	
  ON R5ACTCLASSES
  
 FOR EACH ROW 
DECLARE
   checkresult  VARCHAR2(  4 );
   cerrsource   VARCHAR2( 32 );
   cerrtype     VARCHAR2(  4 );
   db_error     EXCEPTION;
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* A072  -  Update of Action Code for class not allowed */
   checkresult := '900';
   cerrsource  := 'PREUPD_ACL';
   cerrtype    := 'TRIG';
   RAISE db_error;
 END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preupd_acl;
/
