CREATE TRIGGER POSDEL_ACT
  
 AFTER DELETE 
	
  ON R5ACTIVITIES
  
 FOR EACH ROW 
DECLARE
   checkresult     VARCHAR2(  4 );
   cerrsource      VARCHAR2( 32 );
   cerrtype        VARCHAR2(  4 );
   composite_code  r5descriptions.des_code%TYPE;
   x               VARCHAR2(  1 );
   db_error        EXCEPTION;
   rstatus         r5events.evt_rstatus%TYPE;
   rtype           r5events.evt_rtype%TYPE;
   jobtype         r5events.evt_jobtype%TYPE;
   parent          r5events.evt_parent%TYPE;
   org             r5events.evt_org%TYPE;
   evtintout       r5events.evt_interface%TYPE;
   cnt             NUMBER;
   syncwo          VARCHAR2( 30 );
   eventout        r5events.evt_code%TYPE;
   seqno           VARCHAR2( 30 );
   chk1            VARCHAR2(  6 );
BEGIN
  --IF o7gtsusr <> 'SYS' THEN
     DELETE FROM r5actqualifications
     WHERE  aqu_event    = :old.act_event
     AND    aqu_activity = :old.act_act;

     DELETE FROM r5addetails
     WHERE  add_rentity  = 'EVNT'
     AND    add_code     = :old.act_event || '#' || :old.act_act;

     x := NULL;
     composite_code := :OLD.ACT_EVENT || '#' || TO_CHAR (:OLD.ACT_ACT);
     /* W01350 - Delete associated data */
     o7descs( 'DEL', x, 'ACT', x, '*', composite_code, x, x, checkresult );
     IF checkresult <> '0' THEN
         cerrsource := 'O7DESCS';
         cerrtype   := 'PROC';
         RAISE db_error;
     END IF;
     o7eventtemp.addevent( :old.act_event, SYSDATE );

     o7mobile_sync_event ( 'R5ACTIVITIES','DELETE', 'ACT_ACT' || CHR(13) || 'ACT_EVENT', :old.ACT_ACT ||
                           CHR(13) || :old.ACT_EVENT, NULL );

     BEGIN
       SELECT evt_rstatus, evt_rtype, evt_jobtype, evt_parent, evt_org, evt_interface
       INTO   rstatus, rtype, jobtype, parent, org, evtintout
       FROM   r5events
       WHERE  evt_code = :old.act_event;
     EXCEPTION
       -- This exception section is intended for the case that deleting wo will cascade-delete activities
       -- in which case no databridge event should be generated.
       WHEN OTHERS THEN RETURN;
     END;
     IF rstatus IN ( 'R', 'C' ) AND
       rtype IN ( 'JOB', 'PPM' ) THEN
       syncwo := o7dflt( '@SYNCWO', chk1 );
       IF syncwo IN ( 'Y', 'A' ) THEN
         SELECT count(*)
         INTO   cnt
         FROM   r5ucodes
         WHERE  uco_rentity = 'JBTP'
         AND    uco_code    = jobtype
         AND    uco_rcode IN ( '*', 'BR', 'ST', 'PM', 'CAL', 'RP', 'MEC' );
         IF cnt > 0 THEN
           IF syncwo = 'A' AND parent IS NOT NULL THEN
             eventout := parent;
             SELECT evt_interface
             INTO   evtintout
             FROM   r5events
             WHERE  evt_code = parent;
           ELSE
             eventout  := :old.act_event;
           END IF;
           INSERT INTO r5xmltranstatus(
                  xts_trantype, xts_table, xts_keyfld1, xts_keyfld2,xts_org, xts_orig_messageid )
      	   SELECT 'SYNCMAINTORDER', 'R5EVENTS', eventout,
                  CASE WHEN evtintout IS NULL THEN 'A' ELSE 'R' END,
                  org, o7sess.get_messageid()
           FROM   dual
           WHERE NOT EXISTS( SELECT 1
                             FROM   r5xmltranstatus
                             WHERE  xts_trantype = 'SYNCMAINTORDER'
                             AND    xts_keyfld1  = eventout );
         END IF;
       END IF;
     END IF;
     -- reset work order esignature
     DELETE FROM r5eventsignature WHERE ets_event = :old.act_event and ets_updatecount <> -999;

     /* Delete check list items. */
     DELETE FROM r5actchecklists
     WHERE  ack_event = :old.act_event
     AND    ack_act   = :old.act_act;

  --END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posdel_act;
/
