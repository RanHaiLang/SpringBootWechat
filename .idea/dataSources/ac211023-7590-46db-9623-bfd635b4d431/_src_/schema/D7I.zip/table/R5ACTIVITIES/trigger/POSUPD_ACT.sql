CREATE TRIGGER POSUPD_ACT
  
 AFTER UPDATE 
	
  ON R5ACTIVITIES
  
 FOR EACH ROW 
DECLARE
   v_WorkOrderOrg  VARCHAR2( 15 );
   checkresult     VARCHAR2(  4 );
   cerrsource      VARCHAR2( 32 );
   cerrtype        VARCHAR2(  4 );
   db_error        EXCEPTION;
   rstatus         r5events.evt_rstatus%TYPE;
   rtype           r5events.evt_rtype%TYPE;
   jobtype         r5events.evt_jobtype%TYPE;
   jobrtype        VARCHAR2(  4 );
   parent          r5events.evt_parent%TYPE;
   org             r5events.evt_org%TYPE;
   evtintout       r5events.evt_interface%TYPE;
   cnt             NUMBER;
   syncwo          VARCHAR2( 30 );
   eventout        r5events.evt_code%TYPE;
   seqno           VARCHAR2( 30 );
   chk1            VARCHAR2(  6 );
BEGIN
  --IF O7gtsusr <> 'SYS' THEN
     /* this updates the needed date of the tool when the activity start date is changed */
    O7schtool('ACT',:NEW.ACT_EVENT,
                  :NEW.ACT_ACT,
                  :OLD.ACT_START,
                  :NEW.ACT_START,
                  checkresult );
    IF checkresult <> '0' THEN
       cerrsource := 'O7SCHTOOL';
       cerrtype   := 'PROC';
       RAISE db_error;
    END IF;

    SELECT evt_rstatus, evt_rtype, evt_jobtype, evt_parent, evt_org, evt_interface
    INTO   rstatus, rtype, jobtype, parent, org, evtintout
    FROM   r5events
    WHERE  evt_code = :new.act_event;
    r5o7.o7ckcode( jobrtype, jobtype, 'JBTP', checkresult );
    IF checkresult <> '0' THEN
        cerrsource := 'O7CKCODE';
        cerrtype   := 'PROC';
        RAISE db_error;
    END IF;
    O7eventtemp.addevent( :NEW.act_event, SYSDATE );

    IF ( :NEW.ACT_TASK IS NOT NULL AND :OLD.ACT_TASK IS NULL ) THEN
        INSERT INTO r5actqualifications
           (aqu_event, aqu_activity, aqu_qualification, aqu_source )
        SELECT :NEW.ACT_EVENT, :NEW.ACT_ACT, tqu_qualification, 'K'
        FROM   r5taskqualifications
        WHERE  tqu_task = :NEW.ACT_TASK
        AND    tqu_revision = :NEW.ACT_TASKREV;

        /* Create activity check list records if it is not a deferred activity. */
        IF(COALESCE(:NEW.ACT_DEFERMAINTENANCE, '-') = '-') AND jobrtype <> 'MEC' AND rstatus = 'R' THEN
          o7createactchecklist( :NEW.ACT_EVENT, :NEW.ACT_ACT, :NEW.ACT_TASK, :NEW.ACT_TASKREV, NULL);
        END IF;
    END IF;

    IF ( :NEW.ACT_TASK IS NULL AND :OLD.ACT_TASK IS NOT NULL ) THEN
       DELETE FROM   r5actqualifications
       WHERE  aqu_event = :OLD.ACT_EVENT
       AND    aqu_activity = :OLD.ACT_ACT
       AND    aqu_source = 'K';

       /* Delete activity check list records */
        DELETE FROM r5actchecklists
        WHERE  ack_event = :OLD.ACT_EVENT
        AND    ack_act   = :OLD.ACT_ACT;
    END IF;

    IF ( :NEW.ACT_TASK IS NOT NULL AND :OLD.ACT_TASK IS NOT NULL )
       AND ( :NEW.ACT_TASK <> :OLD.ACT_TASK
             OR :NEW.ACT_TASKREV <> :OLD.ACT_TASKREV ) THEN

       DELETE FROM   r5actqualifications
       WHERE  aqu_event = :OLD.ACT_EVENT
       AND    aqu_activity = :OLD.ACT_ACT
       AND    aqu_source = 'K';

       INSERT INTO r5actqualifications
           (aqu_event, aqu_activity, aqu_qualification, aqu_source )
       SELECT :NEW.ACT_EVENT, :NEW.ACT_ACT, tqu_qualification, 'K'
       FROM   r5taskqualifications
       WHERE  tqu_task = :NEW.ACT_TASK
       AND    tqu_revision = :NEW.ACT_TASKREV;

        /* re-create activity check list records if it is not a deferred activity. */
        IF(COALESCE(:NEW.ACT_DEFERMAINTENANCE, '-') = '-') AND jobrtype <> 'MEC' AND rstatus = 'R' THEN
          o7createactchecklist( :NEW.ACT_EVENT, :NEW.ACT_ACT, :NEW.ACT_TASK, :NEW.ACT_TASKREV, NULL);
        END IF;
    END IF;

    /* delete checklists if it is a deferred activity else create checklists*/
    IF(COALESCE(:NEW.ACT_DEFERMAINTENANCE, '-') <> COALESCE(:OLD.ACT_DEFERMAINTENANCE, '-')) THEN
       IF(COALESCE(:NEW.ACT_DEFERMAINTENANCE, '-') = '-') AND jobrtype <> 'MEC' AND rstatus = 'R' THEN
          IF :NEW.ACT_TASK IS NOT NULL THEN
             o7createactchecklist( :NEW.ACT_EVENT, :NEW.ACT_ACT, :NEW.ACT_TASK, :NEW.ACT_TASKREV, NULL);
          END IF;
       ELSIF(COALESCE(:NEW.ACT_DEFERMAINTENANCE, '-') = '+') THEN
          /* Delete activity check list records */
          DELETE FROM r5actchecklists
          WHERE  ack_event = :NEW.ACT_EVENT
          AND    ack_act   = :NEW.ACT_ACT;
       END IF;
    END IF;

    /*Copy Documents from Task to Work Order*/
    IF (:NEW.ACT_TASK IS NOT NULL AND (:OLD.ACT_TASK IS NULL OR :OLD.ACT_TASK IS NOT NULL AND
        (:NEW.ACT_TASK <> :OLD.ACT_TASK OR :NEW.ACT_TASKREV <> :OLD.ACT_TASKREV))) THEN
        SELECT evt_org
        INTO v_WorkOrderOrg
        FROM r5events
        WHERE evt_code = :NEW.ACT_EVENT;
        o7copydocs( :NEW.ACT_EVENT, v_WorkOrderOrg, 'EVNT', NULL, NULL, NULL, NULL, :NEW.ACT_TASK || '#' ||
                    :NEW.ACT_TASKREV, checkresult );
        IF checkresult <> '0' THEN
            cerrsource := 'O7COPYDOCS';
            cerrtype   := 'PROC';
            RAISE db_error;
        END IF;
    END IF;

    o7mobile_sync_event ( 'R5ACTIVITIES','UPDATE', 'ACT_ACT' || CHR(13) || 'ACT_EVENT', :new.ACT_ACT ||
                          CHR(13) || :new.ACT_EVENT, NULL );

    IF rstatus IN ( 'R', 'C' ) AND
      rtype IN ( 'JOB', 'PPM' ) THEN
      syncwo := o7dflt( '@SYNCWO', chk1 );
      IF syncwo IN ( 'Y', 'A' ) THEN
        SELECT count(*)
        INTO   cnt
        FROM   r5ucodes
        WHERE  uco_rentity = 'JBTP'
        AND    uco_code    = jobtype
        AND    uco_rcode IN ( '*', 'BR', 'ST', 'PM', 'CAL', 'RP', 'MEC' );
        IF cnt > 0 THEN
          IF syncwo = 'A' AND parent IS NOT NULL THEN
            eventout := parent;
            SELECT evt_interface
            INTO   evtintout
            FROM   r5events
            WHERE  evt_code = parent;
          ELSE
            eventout  := :new.act_event;
          END IF;
          INSERT INTO r5xmltranstatus(
                 xts_trantype, xts_table, xts_keyfld1, xts_keyfld2,xts_org, xts_orig_messageid )
     	   SELECT 'SYNCMAINTORDER', 'R5EVENTS', eventout,
                 CASE WHEN evtintout IS NULL THEN 'A' ELSE 'R' END,
                 org, o7sess.get_messageid()
          FROM   dual
          WHERE NOT EXISTS( SELECT 1
                            FROM   r5xmltranstatus
                            WHERE  xts_trantype = 'SYNCMAINTORDER'
                            AND    xts_keyfld1  = eventout );
        END IF;
      END IF;
    END IF;

    -- reset work order esignature
    DELETE FROM r5eventsignature WHERE ets_event = :old.act_event and ets_updatecount <> -999;

  --END IF;
EXCEPTION
   WHEN db_error THEN
      O7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posupd_act;
/
