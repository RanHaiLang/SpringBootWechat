CREATE TRIGGER POSUPDDEL1_ACS
  
 AFTER UPDATE OR DELETE 
	
  ON R5ACTSCHEDULES
  
 FOR EACH ROW 
DECLARE
   i NUMBER DEFAULT o7acstemp.acstemptable.count + 1;
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    o7acstemp.acstemptable(i).acs_event := :old.acs_event;
    o7acstemp.acstemptable(i).acs_activity := :old.acs_activity;
  END IF;
END posupddel1_acs;
/
