CREATE TRIGGER PREINS_ACS
  
 BEFORE INSERT 
	
  ON R5ACTSCHEDULES
  
 FOR EACH ROW 
DECLARE
   chk VARCHAR2(4);
BEGIN
  IF o7gtsusr <> 'SYS' THEN
	IF :new.acs_code IS NULL THEN
		r5o7.o7maxseq( :new.acs_code, 'ACS', '1', chk );
	END IF;
    IF :new.acs_frozen IS NULL THEN
      :new.acs_frozen := '-';
    END IF;
    IF :new.acs_responsible IS NOT NULL THEN
      BEGIN
        UPDATE r5activities
        SET    act_perresp = :new.acs_responsible
        WHERE  act_event   = :new.acs_event
        AND    act_act     = :new.acs_activity
        AND    act_perresp IS NULL;
      EXCEPTION
        WHEN OTHERS THEN NULL;
      END;
    END IF;
  END IF;
END preins_acs;
/
