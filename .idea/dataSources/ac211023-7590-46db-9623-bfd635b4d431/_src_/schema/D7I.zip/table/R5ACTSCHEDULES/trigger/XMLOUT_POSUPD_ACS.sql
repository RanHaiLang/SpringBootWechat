CREATE TRIGGER XMLOUT_POSUPD_ACS
  
 AFTER INSERT OR UPDATE 
	
  ON R5ACTSCHEDULES
  
 FOR EACH ROW 
declare v_flag VARCHAR(80);
   usr_name  VARCHAR2(38);
   v_org     VARCHAR2(80);
BEGIN


 /* Initialize */
  select sys_context('USERENV','SESSION_USER') into
  usr_name from dual;
  IF usr_name != 'SYS' THEN
    BEGIN
      SELECT NVL(INS_DESC, 'N') INTO v_flag FROM R5INSTALL WHERE INS_CODE = '@EMPSHLB';
      EXCEPTION WHEN NO_DATA_FOUND THEN
        v_flag := 'N';
    END;
/* Make sure @EMPSHLB is a valid value */
    IF (v_flag <> 'Y') THEN
      RETURN;
    END IF;
  SELECT EVT_ORG INTO v_org FROM R5EVENTS WHERE EVT_CODE = :NEW.ACS_EVENT;
/* Create entry in outbound table for edited schedule*/

      INSERT INTO R5XMLTRANSTATUS
      (
    XTS_TRANTYPE,
    XTS_TABLE,
    XTS_KEYFLD1,
    XTS_ORIG_MESSAGEID,
    XTS_ORG,
    XTS_KEYFLD2
      )
      VALUES(
    'EMPSHLB',
    'R5ACTSCHEDULES',
    :NEW.ACS_CODE,
    o7sess.get_messageid(),
    v_org,
    v_org
      );


   END IF;
END;
/
