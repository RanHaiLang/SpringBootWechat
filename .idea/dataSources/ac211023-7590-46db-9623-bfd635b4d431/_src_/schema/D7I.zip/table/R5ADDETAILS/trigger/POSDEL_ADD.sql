CREATE TRIGGER POSDEL_ADD
  
 AFTER DELETE 
	
  ON R5ADDETAILS
  
 FOR EACH ROW 
DECLARE
BEGIN
  IF o7gtsusr <> 'SYS' THEN
     IF :old.add_rentity = 'EVNT' THEN
       DELETE FROM r5eventsignature WHERE ets_event = :old.add_code and ets_updatecount <> -999;
     END IF;
     -- Reset Permit To Work esignature information
     IF :new.add_rentity IN ('PTW', 'SFWO', 'LTPW') THEN
            UPDATE r5permittowork
            SET ptw_reviewed = null, ptw_reviewedby = null, ptw_reviewedtype = null
            WHERE ptw_code = :old.add_code;
     END IF;
  END IF;
END posdel_add;
/
