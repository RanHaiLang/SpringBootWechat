CREATE TRIGGER XMLOUT_POSDEL_ADD
  
 AFTER DELETE 
	
  ON R5ADDETAILS
  
 FOR EACH ROW WHEN (FOR EACH ROW )
declare v_flag VARCHAR(2);
   usr_name	VARCHAR2(38);
   v_org          VARCHAR2(15);
   v_partorg          VARCHAR2(2000);

BEGIN
/* Initialize */

  select sys_context('USERENV','SESSION_USER') into
	usr_name from dual;

IF usr_name != 'SYS' THEN
  BEGIN
      SELECT NVL(INS_DESC, 'N') INTO v_flag FROM R5INSTALL WHERE INS_CODE = '@SYNCITM';
      EXCEPTION WHEN NO_DATA_FOUND THEN
        v_flag := 'N';
  END;

  /*
  IF v_flag <> 'Y' THEN
    RETURN;
  END IF;
  */


  IF ( :OLD.ADD_RENTITY = 'PART' OR :OLD.ADD_RENTITY = 'STOC') THEN
    IF ( (v_flag = 'Y') OR (v_flag = 'T') ) THEN

      v_partorg := SUBSTR(:OLD.ADD_CODE, INSTR(:OLD.ADD_CODE, '#')+1, 2000);
      IF ( INSTR(v_partorg, '#') > 0 ) THEN
          v_partorg := SUBSTR(v_partorg, 1, INSTR(v_partorg, '#')-1);
      END IF;

      INSERT INTO R5XMLTRANSTATUS
        (XTS_TRANTYPE,
        XTS_TABLE,
        XTS_KEYFLD1,
        XTS_KEYFLD2,
        XTS_KEYFLD3,
        XTS_ORIG_MESSAGEID,
        XTS_ORG
        )
        SELECT 'SYNCITEM',
        'R5PARTS',
        SUBSTR(:OLD.ADD_CODE, 1, INSTR(:OLD.ADD_CODE, '#')-1), --get part code
        v_partorg, --get part org
        'R',
        o7sess.get_messageid(),
        v_partorg
        FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM R5XMLTRANSTATUS
                                  WHERE XTS_TRANTYPE='SYNCITEM'
	                                AND XTS_KEYFLD1 = SUBSTR(:OLD.ADD_CODE, 1, INSTR(:OLD.ADD_CODE, '#')-1)
                                        AND XTS_KEYFLD2 = v_partorg );
    END IF;
  END IF;

  IF ( :OLD.ADD_RENTITY = 'TRAD' ) THEN
     IF ( v_flag = 'T' ) THEN

       SELECT TRD_ORG INTO v_org FROM R5TRADES WHERE TRD_CODE = :OLD.ADD_CODE;

       INSERT INTO R5XMLTRANSTATUS
         (XTS_TRANTYPE,
         XTS_TABLE,
         XTS_KEYFLD1,
         XTS_KEYFLD2,
         XTS_KEYFLD3,
         XTS_ORIG_MESSAGEID,
         XTS_ORG
         )
         VALUES('SYNCITEM',
         'R5TRADES',
         :OLD.ADD_CODE,
         v_org,
         'R',
         o7sess.get_messageid(),
         v_org);
     END IF;
   END IF;



END IF;
END;
/
