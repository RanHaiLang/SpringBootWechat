CREATE TRIGGER POSDEL_ADI
  
 AFTER DELETE 
	
  ON R5ADDETAILSINTERFACE
  
 FOR EACH ROW 
BEGIN
   IF o7gtsusr <> 'SYS' THEN
      o7interface.delint( 'R5ADDETAILSINTERFACE', :old.adi_transid, NULL, NULL );
      o7interface.arcdel( :old.adi_transorgid );
   END IF;
END posdel_adi;
/
