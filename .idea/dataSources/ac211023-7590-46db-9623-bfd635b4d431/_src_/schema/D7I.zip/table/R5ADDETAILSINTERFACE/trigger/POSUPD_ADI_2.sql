CREATE TRIGGER POSUPD_ADI_2
  
 AFTER UPDATE 
	
  ON R5ADDETAILSINTERFACE
  
DECLARE
  CURSOR c1 IS
         SELECT *
         FROM   r5archivetemp
         WHERE  art_action     = 'POST-UPDATE'
         AND    art_apitable   = 'R5ADDETAILSINTERFACE'
         AND    art_sessionid in (SELECT USERENV('SESSIONID') FROM DUAL)
         FOR UPDATE;
BEGIN
   IF o7gtsusr <> 'SYS' THEN
      FOR c1rec IN c1 LOOP
         DELETE FROM r5archivetemp WHERE CURRENT OF c1;
          o7interface.arcupd( c1rec.art_transapiid,
                        c1rec.art_transorgid,
                        c1rec.art_transgroup,
                        c1rec.art_trans,
                        c1rec.art_apirtype,
                        c1rec.art_apitable,
                        c1rec.art_apiprefix );
      END LOOP;
   END IF;
END posupd_adi_2;
/
