CREATE TRIGGER PREINS_ADI
  
 BEFORE INSERT 
	
  ON R5ADDETAILSINTERFACE
  
 FOR EACH ROW 
DECLARE
   chk VARCHAR2(3);
BEGIN
   IF o7gtsusr <> 'SYS' THEN
     r5o7.o7maxseq( :new.adi_transid, 'INTERFACE', '1', chk );
     o7interface.astint ( 'INSERT'
                       ,:new.adi_sessionid
                       ,:new.adi_trans
                       ,'R5ADDETAILSINTERFACE'
                       ,:new.adi_transid
                       ,NULL
                       ,NULL
                       ,:new.adi_transorgid
                       ,:new.adi_transgroup
                       ,NULL
                       ,NULL );
   END IF;
END preins_adi;
/
