CREATE TRIGGER POSDEL_APR
  
 AFTER DELETE 
	
  ON R5ADDPROPERTIES
  
 FOR EACH ROW 
BEGIN
  IF o7gtsusr <> 'SYS' THEN
      -- delete value records for this property.
      o7prop.delete_values( :old.apr_property, :old.apr_rentity, :old.apr_class, :old.apr_class_org );
  END IF;
END posdel_apr;
/
