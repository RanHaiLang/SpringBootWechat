CREATE TRIGGER POSINS_APR
  
 AFTER INSERT 
	
  ON R5ADDPROPERTIES
  
 FOR EACH ROW 
declare
         x      VARCHAR2( 1 );
begin
   IF o7gtsusr <> 'SYS' THEN
      /*Need to do this for both HDR and LST since custom fields can be added to list view. */
      update r5pagecache set pgc_updatecount=pgc_updatecount
         where pgc_rentity=:NEW.apr_rentity
         and pgc_tabname in ('HDR','LST');

      /* If handling PART or OBJ entity, then translate to PEVL or EEVL */
      /* SSEVAL shows PART custom fields and OSEVAL shows OBJ custom fields */
      IF( :NEW.apr_rentity = 'PART' OR :NEW.apr_rentity = 'OBJ' ) THEN
         update r5pagecache set pgc_updatecount=pgc_updatecount
            where pgc_rentity= CASE :NEW.apr_rentity
            			WHEN 'PART' THEN 'PEVL'
            			ELSE 'EEVL' END
            and pgc_tabname in ('HDR','LST');
      END IF;
      IF :new.apr_rentity = 'EVNT' THEN
         UPDATE r5pagecache
         SET    pgc_updatecount = pgc_updatecount
         WHERE  pgc_rentity IN ( 'PPM', 'STWO' )
         AND    pgc_tabname IN ( 'HDR', 'LST' );
      END IF;
   END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
end POSINS_APR;
/
