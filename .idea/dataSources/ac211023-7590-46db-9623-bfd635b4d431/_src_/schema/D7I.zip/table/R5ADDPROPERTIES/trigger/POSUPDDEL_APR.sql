CREATE TRIGGER POSUPDDEL_APR
  
 AFTER UPDATE OR DELETE 
	
  ON R5ADDPROPERTIES
  
 FOR EACH ROW 
begin
   IF o7gtsusr <> 'SYS' THEN
      /*Need to do this for both HDR and LST since custom fields can be added to list view. */
      update r5pagecache set pgc_updatecount=pgc_updatecount
         where pgc_rentity=:OLD.apr_rentity
         and pgc_tabname in ('HDR','LST');

      /* If handling PART , OBJ or EVNT entity, then translate to PEVL or EEVL or PPM respectively */
      /* SSEVAL shows PART custom fields , OSEVAL shows OBJ custom fields and WSPPMS shows EVNT custom fields */
      IF( :OLD.apr_rentity = 'PART' OR :OLD.apr_rentity = 'OBJ' ) THEN
         update r5pagecache set pgc_updatecount=pgc_updatecount
            where pgc_rentity= CASE :OLD.apr_rentity
            			WHEN 'PART' THEN 'PEVL'
            			ELSE 'EEVL' END
            and pgc_tabname in ('HDR','LST');
      END IF;
      IF :old.apr_rentity = 'EVNT' THEN
         UPDATE r5pagecache
         SET    pgc_updatecount = pgc_updatecount
         WHERE  pgc_rentity IN ( 'PPM', 'STWO' )
         AND    pgc_tabname IN ( 'HDR', 'LST' );
      END IF;
   END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN NULL;
end POSUPDDEL_APR;
/
