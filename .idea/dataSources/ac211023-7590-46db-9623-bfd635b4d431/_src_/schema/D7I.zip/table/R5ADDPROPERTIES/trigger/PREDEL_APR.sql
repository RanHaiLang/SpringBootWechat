CREATE TRIGGER PREDEL_APR
  
 BEFORE DELETE 
	
  ON R5ADDPROPERTIES
  
 FOR EACH ROW 
DECLARE
  ptype r5ucodes.uco_code%TYPE;
  CURSOR pt( prop IN VARCHAR2 ) IS
    SELECT pro_type
    FROM   r5properties
    WHERE  pro_code = prop;
BEGIN
 IF o7gtsusr <> 'SYS' THEN
  OPEN pt( :old.apr_property );
  FETCH pt INTO ptype;
  CLOSE pt;
  IF ptype <> 'RENT' AND :old.apr_list <> '-' Then
    o7prop.apr_to_delete( :old.apr_property, ptype,
                          :old.apr_rentity,:old.apr_class,
			  :old.apr_class_org, :old.apr_list );
  End If;
 END IF;
END predel_apr;
/
