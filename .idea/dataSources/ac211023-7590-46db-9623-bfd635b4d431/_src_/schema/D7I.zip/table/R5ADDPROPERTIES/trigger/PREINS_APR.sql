CREATE TRIGGER PREINS_APR
  
 BEFORE INSERT 
	
  ON R5ADDPROPERTIES
  
 FOR EACH ROW 
BEGIN
 IF o7gtsusr <> 'SYS' THEN
   o7prop.preapr( 'INS', :new.apr_property,  :new.apr_rentity, :new.apr_class,
                  :new.apr_class_org, :new.apr_uom, :new.apr_list );
 END IF;
END preins_apr;
/
