CREATE TRIGGER PREUPD_APR
  
 BEFORE UPDATE 
	
  ON R5ADDPROPERTIES
  
 FOR EACH ROW 
BEGIN
 IF o7gtsusr <> 'SYS' THEN
  -- B41C7 Property, rentity, class not updateable
   IF :new.apr_property <> :old.apr_property
   OR :new.apr_rentity  <> :old.apr_rentity
   OR :new.apr_class    <> :old.apr_class THEN
      o7err.raise_error( 'R5', 'TRIG', 1 );
   END IF;
  -- B41C8 List only updateable from '-'.
   IF  :new.apr_list <> :old.apr_list
   AND :old.apr_list <> '-' THEN
      o7err.raise_error( 'PREUPD_APR', 'TRIG', 1 );
   END IF;
   o7prop.preapr( 'UPD', :new.apr_property,  :new.apr_rentity, :new.apr_class,
                  :new.apr_class_org, :new.apr_uom, :new.apr_list );
   :new.apr_updated := sysdate;
 END IF;
END preupd_apr;
/
