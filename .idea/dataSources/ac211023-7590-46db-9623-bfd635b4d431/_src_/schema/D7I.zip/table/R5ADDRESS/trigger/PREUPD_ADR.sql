CREATE TRIGGER PREUPD_ADR
  
 BEFORE UPDATE 
	
  ON R5ADDRESS
  
 FOR EACH ROW 
BEGIN
 IF o7gtsusr <> 'SYS' THEN
  -- B27T1 : Only Text is Updateable
   IF(( :new.adr_rentity <> :old.adr_rentity ) OR
      ( :new.adr_code    <> :old.adr_code AND :new.adr_rentity <> 'PERS') OR
      ( :new.adr_rtype   <> :old.adr_rtype )) THEN
      o7err.raise_error( 'R5', 'TRIG', 3 );
   END IF;
 END IF;
END preupd_adr;
/
