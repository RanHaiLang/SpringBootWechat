CREATE TRIGGER POSINS_ADJ
  
 AFTER INSERT 
	
  ON R5ADJUSTMENTS
  
 FOR EACH ROW 
DECLARE
   checkresult VARCHAR2(  4 );
   cerrsource  VARCHAR2( 32 );
   cerrtype    VARCHAR2(  4 );
   x           VARCHAR2(  1 );
   db_error    EXCEPTION;
BEGIN
   IF o7gtsusr <> 'SYS' THEN
/* Initialize */
     checkresult := '0';
     x           := NULL;
/* Insert descriptions */
     o7descs( 'INS', x, 'ADJU', x, '*', :new.adj_code, :new.adj_org,
              :new.adj_desc, checkresult );
     IF checkresult <> '0' THEN
        cerrsource := 'O7DESCS';
        cerrtype   := 'PROC';
        RAISE db_error;
     END IF;
   END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END POSINS_ADJ;
/
