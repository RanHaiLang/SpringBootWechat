CREATE TRIGGER POSUPD_ADJ
  
 AFTER UPDATE 
	
  ON R5ADJUSTMENTS
  
 FOR EACH ROW 
DECLARE
   checkresult  VARCHAR2(  4 );
   cerrsource   VARCHAR2( 32 );
   cerrortype   VARCHAR2(  4 );
   countit      NUMBER;
   db_error     EXCEPTION;
   x            VARCHAR2(  1 );
   chk          VARCHAR2(  3 );
   ndeforg      r5install.ins_desc%TYPE := o7dflt('DEFORG', chk);
BEGIN
   IF o7gtsusr <> 'SYS' THEN
/* Initialize   */
     checkresult  := '0';
     countit      := 0;
     cerrsource   := NULL;
     cerrortype   := NULL;
     x            := NULL;
     o7descs( 'UPD', x, 'ADJU', x, '*', :new.adj_code, :new.adj_org,
              :new.adj_desc, checkresult );
   END IF;
END POSUPD_ADJ;
/
