CREATE TRIGGER PRES_AGR
  
 BEFORE INSERT OR UPDATE 
	
  ON R5AGREEMENTS
  
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Initialise the package for post-statement processing */
   o7agr.prestmt;
 END IF;
END pres_agr;
/
