CREATE TRIGGER PRE_AGR
  
 BEFORE INSERT OR UPDATE OR DELETE 
	
  ON R5AGREEMENTS
  
 FOR EACH ROW 
DECLARE
   insupddel VARCHAR2 (3);
   cagrcode     r5agreements.agr_code%TYPE;
   cagrstatus   r5agreements.agr_status%TYPE;
   cagrrstatus  r5agreements.agr_rstatus%TYPE;
   countit      NUMBER := 0;
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Determine mode */
   IF INSERTING THEN
      insupddel := 'INS';
   ELSIF UPDATING THEN
      insupddel := 'UPD';
   ELSIF DELETING THEN
      insupddel := 'DEL';
   END IF;

   cagrcode    := :NEW.agr_code;
   cagrstatus  := :NEW.agr_status;
   cagrrstatus := :NEW.agr_rstatus;


/* Call dedicated procedure for further processing */
   IF insupddel = 'DEL' THEN
     SELECT count(*)
     INTO   countit
     FROM   r5agreements_archive
     WHERE  aag_code = :old.agr_code;
   END IF;
   IF countit = 0 THEN
     o7preagr (
         insupddel,
         old_agr_code => :OLD.agr_code,
         old_agr_status => :OLD.agr_status,
         old_agr_rstatus => :OLD.agr_rstatus,
         old_agr_arrangement => :OLD.agr_arrangement,
         old_agr_class => :OLD.agr_class,
         old_agr_clsorg => :OLD.agr_class_org,
         old_agr_debtor => :OLD.agr_debtor,
         old_agr_desc => :OLD.agr_desc,
         old_agr_end => :OLD.agr_end,
         old_agr_object => :OLD.agr_object,
         old_agr_event => :OLD.agr_event,
         old_agr_project => :OLD.agr_project,
         old_agr_start => :OLD.agr_start,
         new_agr_code => cagrcode,
         new_agr_status => cagrstatus,
         new_agr_rstatus => cagrrstatus,
         new_agr_arrangement => :NEW.agr_arrangement,
         new_agr_class => :NEW.agr_class,
         new_agr_clsorg => :NEW.agr_class_org,
         new_agr_debtor => :NEW.agr_debtor,
         new_agr_desc => :NEW.agr_desc,
         new_agr_end => :NEW.agr_end,
         new_agr_object => :NEW.agr_object,
         new_agr_event => :NEW.agr_event,
         new_agr_project => :NEW.agr_project,
         new_agr_start => :NEW.agr_start);
   END IF;
   IF insupddel IN ('INS', 'UPD') THEN
     :NEW.agr_code    := cagrcode;
     :NEW.agr_status  := cagrstatus ;
     :NEW.agr_rstatus := cagrrstatus;
   END IF;
 END IF;
END pre_agr;
/
