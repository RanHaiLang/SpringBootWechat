CREATE TRIGGER PREUPD2_ADO
  
 BEFORE UPDATE 
	
  ON R5ALERTDATAOBJ
  
 FOR EACH ROW 
DECLARE
   db_error             EXCEPTION;
   checkresult          VARCHAR2(  4 ) := '0';
   cerrsource           VARCHAR2( 15 );
   cerrtype             VARCHAR2(  4 );

BEGIN
   IF o7gtsusr <> 'SYS' THEN

      IF NVL(:new.ado_updatecount,-1) = NVL(:old.ado_updatecount,-1) THEN
         :new.ado_updatecount := NVL(:new.ado_updatecount,-1) + 1;
      ELSE
         cerrsource   := 'UPDCOUNT';
         cerrtype     := 'TRIG';
         checkresult  := '1';
         RAISE db_error;
      END IF;
   END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preupd2_ado ;
/
