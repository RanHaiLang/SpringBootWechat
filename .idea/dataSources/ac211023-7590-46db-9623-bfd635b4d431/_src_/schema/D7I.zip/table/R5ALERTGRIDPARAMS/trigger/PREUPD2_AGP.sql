CREATE TRIGGER PREUPD2_AGP
  
 BEFORE UPDATE 
	
  ON R5ALERTGRIDPARAMS
  
 FOR EACH ROW 
DECLARE
   db_error             EXCEPTION;
   checkresult          VARCHAR2(  4 ) := '0';
   cerrsource           VARCHAR2( 15 );
   cerrtype             VARCHAR2(  4 );

BEGIN
   IF o7gtsusr <> 'SYS' THEN

      IF NVL(:new.agp_updatecount,-1) = NVL(:old.agp_updatecount,-1) THEN
         :new.agp_updatecount := NVL(:new.agp_updatecount,-1) + 1;
      ELSE
         cerrsource   := 'UPDCOUNT';
         cerrtype     := 'TRIG';
         checkresult  := '1';
         RAISE db_error;
      END IF;
   END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preupd2_agp ;
/
