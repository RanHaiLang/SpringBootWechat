CREATE TRIGGER POSDEL_ALM
  
 AFTER DELETE 
	
  ON R5ALERTMAIL
  
 FOR EACH ROW 
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Delete associated text parameter records (r5alerttextparams) */
    delete from r5alerttextparams
     where atp_alert = :old.alm_alert
       and atp_rtype = 'M'
       and atp_template = :old.alm_template;
  END IF;
END posdel_alm;
/
