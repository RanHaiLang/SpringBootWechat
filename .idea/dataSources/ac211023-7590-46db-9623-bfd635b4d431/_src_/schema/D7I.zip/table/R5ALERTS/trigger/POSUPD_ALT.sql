CREATE TRIGGER POSUPD_ALT
  
 AFTER UPDATE 
	
  ON R5ALERTS
  
 FOR EACH ROW 
DECLARE
  checkresult VARCHAR2(  4 );
  cerrsource  VARCHAR2( 32 );
  cerrtype    VARCHAR2(  4 );
  x           VARCHAR2(  4 );
  db_error    EXCEPTION;
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Initialize */
    checkresult := '0';
    x           := NULL;

    /* Update descriptions (r5descriptions) */
    o7descs( 'UPD', x, 'ALRT', x, '*', :new.alt_code, x, :new.alt_desc, checkresult );
    IF checkresult <> '0' THEN
      cerrsource := 'O7DESCS';
      cerrtype   := 'PROC';
      RAISE db_error;
    END IF;

    IF (:old.alt_gridid <> :new.alt_gridid) THEN
      o7alert.syncgridparameters(:new.alt_code, :new.alt_gridid);
    END IF;
  END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posupd_alt;
/
