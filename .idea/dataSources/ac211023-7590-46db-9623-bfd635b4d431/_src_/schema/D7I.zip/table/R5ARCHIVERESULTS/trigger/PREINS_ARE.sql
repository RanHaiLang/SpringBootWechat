CREATE TRIGGER PREINS_ARE
  
 BEFORE INSERT 
	
  ON R5ARCHIVERESULTS
  
 FOR EACH ROW 
DECLARE
  chk VARCHAR2( 4 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    r5o7.o7maxseq( :new.are_pk, 'ARE', '1', chk );
  END IF;
END preins_are;
/
