CREATE TRIGGER PREUPD_ARC
  
 BEFORE UPDATE OF ARC_DATE, ARC_USER, ARC_ENDDATE, ARC_EVENTS, ARC_ORDERS, ARC_TRANS, ARC_AUDIT, ARC_ELEC, ARC_STOP
	
  ON R5ARCHIVES
  
 FOR EACH ROW 
DECLARE
  db_error    EXCEPTION;
  checkresult VARCHAR2(  4 ) := '0';
  cerrsource  VARCHAR2( 15 );
  cerrtype    VARCHAR2(  4 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    IF NVL(:new.arc_updatecount,-1) = NVL(:old.arc_updatecount,-1) THEN
      :new.arc_updatecount := NVL(:new.arc_updatecount,-1) + 1;
    ELSE
      cerrsource   := 'UPDCOUNT';
      cerrtype     := 'TRIG';
      checkresult  := '1';
      RAISE db_error;
    END IF;
  END IF;
EXCEPTION
  WHEN db_error THEN
    o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preup2_arc ;
/
