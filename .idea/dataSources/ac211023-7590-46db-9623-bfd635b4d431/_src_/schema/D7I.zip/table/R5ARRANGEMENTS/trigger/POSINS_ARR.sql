CREATE TRIGGER POSINS_ARR
  
 AFTER INSERT 
	
  ON R5ARRANGEMENTS
  
 FOR EACH ROW 
DECLARE
   chk         VARCHAR2(  4 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Copy descriptions (r5descriptions) */
     o7descs( 'INS', null, 'ARR', null, '*', :NEW.arr_code, :NEW.arr_org, :NEW.arr_desc, chk );
    /* Add to the package for post-statement processing */
     o7arr.posrow (:NEW.rowid);
  END IF;
END posins_arr;
/
