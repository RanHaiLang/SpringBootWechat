CREATE TRIGGER PRE_APA
  
 BEFORE INSERT OR UPDATE OR DELETE 
	
  ON R5ARRPARTS
  
 FOR EACH ROW 
DECLARE
   insupddel VARCHAR2 (3);
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Determine mode */
   IF INSERTING THEN
      insupddel := 'INS';
   ELSIF UPDATING THEN
      insupddel := 'UPD';
   ELSIF DELETING THEN
      insupddel := 'DEL';
   END IF;
/* Call dedicated procedure for further processing */
   o7preapa (
         insupddel,
         old_apa_arrangement => :OLD.apa_arrangement,
         old_apa_charge => :OLD.apa_charge,
         old_apa_parclass => :OLD.apa_parclass,
	 old_apa_parclsorg => :OLD.apa_parclass_org,
         new_apa_arrangement => :NEW.apa_arrangement,
         new_apa_charge => :NEW.apa_charge,
         new_apa_parclass => :NEW.apa_parclass,
	 new_apa_parclsorg => :NEW.apa_parclass_org);
 END IF;
END pre_apa;
/
