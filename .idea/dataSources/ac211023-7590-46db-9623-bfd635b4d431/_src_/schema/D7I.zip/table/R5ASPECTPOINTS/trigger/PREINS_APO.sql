CREATE TRIGGER PREINS_APO
  
 BEFORE INSERT 
	
  ON R5ASPECTPOINTS
  
 FOR EACH ROW 
DECLARE
   checkresult    VARCHAR2(  4 );
   cerrsource     VARCHAR2( 32 );
   cerrtype       VARCHAR2(  4 );
   db_error       EXCEPTION;
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Initialize */
   checkresult        := '0';
/* I03131 : Insert associated data */
   o7crapo1( :new.apo_object,  :new.apo_object_org,
             :new.apo_obrtype, :new.apo_obtype,
             :new.apo_point,   :new.apo_pointtype,
             null,             checkresult );
   IF checkresult <> '0'  THEN
      cerrsource  := 'O7CRAPO1';
      cerrtype    := 'PROC';
      RAISE db_error;
   END IF;

   :new.apo_updated      := sysdate;
 END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preins_apo;
/
