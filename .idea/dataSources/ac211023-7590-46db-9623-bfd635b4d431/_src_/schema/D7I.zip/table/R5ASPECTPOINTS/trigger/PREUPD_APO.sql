CREATE TRIGGER PREUPD_APO
  
 BEFORE UPDATE 
	
  ON R5ASPECTPOINTS
  
 FOR EACH ROW 
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* I03211-Updation of Object/type/rtype/aspect/point/pointtype not allowed */
   IF :new.apo_object <> :old.apo_object
   OR :new.apo_object_org <> :old.apo_object_org
   OR :new.apo_obtype <> :old.apo_obtype
   OR :new.apo_obrtype <> :old.apo_obrtype
   OR :new.apo_aspect <> :old.apo_aspect
   OR :new.apo_point <> :old.apo_point
   OR :new.apo_pointtype <> :old.apo_pointtype THEN
      o7err.raise_error( 'R5', 'TRIG', 1 );
   END IF;

   :new.apo_updated      := sysdate;
 END IF;
END preupd_apo;
/
