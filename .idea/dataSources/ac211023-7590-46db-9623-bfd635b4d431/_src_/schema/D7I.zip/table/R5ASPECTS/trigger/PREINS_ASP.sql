CREATE TRIGGER PREINS_ASP
  
 BEFORE INSERT 
	
  ON R5ASPECTS
  
 FOR EACH ROW 
DECLARE
   checkresult  VARCHAR2(  4 );
   x            VARCHAR2(  1 );
   countit      NUMBER;
   cerrsource   VARCHAR2( 32 );
   cerrtype     VARCHAR2(  4 );
   ctype        r5ucodes.uco_code%TYPE; /* User type for corresponding rapier code */
   db_error     EXCEPTION;
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Initialize */
   checkresult := '0';
   countit     := 0;
   x           := NULL;
   ctype       := NULL;
/* I01113 : Time dependence should exist in r5ucodes. */
   IF :new.asp_timedep IS NOT NULL THEN
      r5o7.o7ckcode( :new.asp_timedep , ctype, 'TIMD', checkresult );
      IF checkresult <> '0' THEN
         cerrsource  := 'PREINS_ASP';
         cerrtype    := 'TRIG';
         checkresult := '2';
         RAISE db_error;
      END IF;
   END IF;
/* I01121 : Class must exist ( r5classes, rentity = 'ASPC' ) */
   IF :new.asp_class IS NOT NULL THEN
      r5o7.o7exist( 'CLAS', 'ASPC', :new.asp_class,:new.asp_class_org, '*', x, x, x, x,
               countit, checkresult );
      IF countit > 0 THEN
         NULL;
      ELSIF countit = 0 THEN
         checkresult := '1';
         cerrsource  := 'PREINS_ASP';
         cerrtype    := 'TRIG';
         RAISE db_error;
      ELSE
         cerrsource  := 'O7EXIST';
         cerrtype    := 'PROC';
         RAISE db_error;
      END IF;
   END IF;
 END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preins_asp;
/
