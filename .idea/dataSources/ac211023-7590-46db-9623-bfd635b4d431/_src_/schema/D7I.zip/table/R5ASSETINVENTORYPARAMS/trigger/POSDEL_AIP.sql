CREATE TRIGGER POSDEL_AIP
  
 AFTER DELETE 
	
  ON R5ASSETINVENTORYPARAMS
  
 FOR EACH ROW 
DECLARE
   checkresult  VARCHAR2(  4 );
   cerrsource   VARCHAR2( 32 );
   cerrortype   VARCHAR2(  4 );
   x            VARCHAR2(  1 );
   db_error     EXCEPTION;
BEGIN
   IF o7gtsusr <> 'SYS' THEN
/* Initialize   */
     checkresult  := '0';
     cerrsource   := NULL;
     cerrortype   := NULL;
     x            := NULL;
/* Delete dependant data */
     o7descs( 'DEL', x, 'AINV', x, '*', :old.aip_code, x, x, checkresult );
     IF checkresult <> '0' THEN
        cerrsource := 'O7DESCS';
        cerrortype   := 'PROC';
        RAISE db_error;
     END IF;
   END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrortype, checkresult, SQLCODE );
END POSDEL_AIP;
/
