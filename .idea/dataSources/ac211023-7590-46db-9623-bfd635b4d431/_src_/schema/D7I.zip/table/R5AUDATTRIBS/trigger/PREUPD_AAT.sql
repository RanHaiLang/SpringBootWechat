CREATE TRIGGER PREUPD_AAT
  
 BEFORE UPDATE 
	
  ON R5AUDATTRIBS
  
 FOR EACH ROW 
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    :new.aat_updated := sysdate;
  END IF;
END preupd_aat;
/
