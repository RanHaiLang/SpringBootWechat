CREATE TRIGGER PREINS_AVA
  
 BEFORE INSERT 
	
  ON R5AUDVALUES
  
 FOR EACH ROW 
DECLARE
  val  VARCHAR2( 20000 );
  hash VARCHAR2(   200 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
     val := :new.ava_attribute || :new.ava_table || :new.ava_primaryid || :new.ava_secondaryid  ||
            :new.ava_from || :new.ava_to || TO_CHAR( :new.ava_changed, 'DD-MON-YYYY' ) ||
            :new.ava_modifiedby || :new.ava_function || :new.ava_updated || :new.ava_inserted ||
            :new.ava_deleted || :new.ava_updatecount;
     hash := o7hash( val , NVL( :new.ava_modifiedby, 'GBJMIONL') );
     :new.ava_scode := hash;
  END IF;
END;
/
