CREATE TRIGGER POSINS3_AUT
  
 AFTER INSERT 
	
  ON R5AUTH
  
 FOR EACH ROW 
BEGIN
  IF O7gtsusr <> 'SYS' THEN

  o7mobile_sync_event ( 'R5AUTH','INSERT', 'AUT_ENTITY' || CHR(13) || 'AUT_GROUP' || CHR(13) || 'AUT_STATNEW' || CHR(13) || 'AUT_STATUS' || CHR(13) || 'AUT_USER', :new.AUT_ENTITY || CHR(13) || :new.AUT_GROUP || CHR(13) || :new.AUT_STATNEW || CHR(13) || :new.AUT_STATUS || CHR(13) || :new.AUT_USER, NULL );

  END IF;
END posins_AUT;
/
