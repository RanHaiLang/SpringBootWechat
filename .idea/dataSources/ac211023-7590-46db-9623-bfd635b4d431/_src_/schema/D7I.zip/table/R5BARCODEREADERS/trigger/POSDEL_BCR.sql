CREATE TRIGGER POSDEL_BCR
  
 AFTER DELETE 
	
  ON R5BARCODEREADERS
  
 FOR EACH ROW 
DECLARE
   checkresult  VARCHAR2( 4 );
   cerrsource   VARCHAR2( 32 );
   cerrtype     VARCHAR2( 4 );
   db_error     EXCEPTION;
   x            VARCHAR2( 1 );
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Initialize   */
    checkresult  := '0';
   /* S3934  Delete all associated data of the record */
    o7descs( 'DEL', x, 'BARR', x, '*', :old.bcr_code, x, x, checkresult );
    IF checkresult <> '0' THEN
      cerrsource := 'O7DESCS';
      cerrtype   := 'PROC';
      RAISE db_error;
    END IF;
  END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posdel_bcr;
/
