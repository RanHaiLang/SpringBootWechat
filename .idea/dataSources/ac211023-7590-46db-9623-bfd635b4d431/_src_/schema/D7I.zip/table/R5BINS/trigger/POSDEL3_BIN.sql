CREATE TRIGGER POSDEL3_BIN
  
 AFTER DELETE 
	
  ON R5BINS
  
 FOR EACH ROW 
BEGIN
  IF O7gtsusr <> 'SYS' THEN

  o7mobile_sync_event ( 'R5BINS','DELETE', 'BIN_CODE' || CHR(13) || 'BIN_STORE', :old.BIN_CODE || CHR(13) || :old.BIN_STORE, NULL );

  END IF;
END posdel_BIN;
/
