CREATE TRIGGER POSINS3_BIN
  
 AFTER INSERT 
	
  ON R5BINS
  
 FOR EACH ROW 
BEGIN
  IF O7gtsusr <> 'SYS' THEN

  o7mobile_sync_event ( 'R5BINS','INSERT', 'BIN_CODE' || CHR(13) || 'BIN_STORE', :new.BIN_CODE || CHR(13) || :new.BIN_STORE, NULL );

  END IF;
END posins_BIN;
/
