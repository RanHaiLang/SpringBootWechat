CREATE TRIGGER POSUPD3_BIN
  
 AFTER UPDATE 
	
  ON R5BINS
  
 FOR EACH ROW 
BEGIN
  IF O7gtsusr <> 'SYS' THEN

  o7mobile_sync_event ( 'R5BINS','UPDATE', 'BIN_CODE' || CHR(13) || 'BIN_STORE', :new.BIN_CODE || CHR(13) || :new.BIN_STORE, NULL );

  END IF;
END posupd_BIN;
/
