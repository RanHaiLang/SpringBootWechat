CREATE TRIGGER PREDEL_BIN
  
 BEFORE DELETE 
	
  ON R5BINS
  
 FOR EACH ROW 
BEGIN
 IF o7gtsusr <> 'SYS' THEN
   /* Clear default bin. */
   UPDATE r5stock
   SET    sto_defaultbin = ''
   WHERE  sto_store      = :old.bin_store
   AND    sto_defaultbin = :old.bin_code;
 END IF;
END predel_bin;
/
