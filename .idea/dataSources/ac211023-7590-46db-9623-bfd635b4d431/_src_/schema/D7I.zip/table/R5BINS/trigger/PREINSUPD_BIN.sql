CREATE TRIGGER PREINSUPD_BIN
  
 BEFORE INSERT OR UPDATE 
	
  ON R5BINS
  
 FOR EACH ROW 
DECLARE
cbinorg     r5stores.str_org%TYPE;
CURSOR cur_str_org IS
   SELECT str_org
   FROM r5stores
   WHERE str_code = :new.bin_store;

BEGIN
   IF o7gtsusr <> 'SYS' THEN

      OPEN cur_str_org;
      FETCH cur_str_org INTO cbinorg;
      CLOSE cur_str_org;

      IF INSERTING THEN
         :new.bin_createdby    := NVL(o7sess.cur_user,'R5');
         :new.bin_created      := o7gttime( cbinorg );
      ELSE
         :new.bin_updatedby    := NVL(o7sess.cur_user,'R5');
         :new.bin_updated      := o7gttime( cbinorg );
      END IF;
   END IF;
END preinsupd_bin;
/
