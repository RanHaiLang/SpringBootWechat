CREATE TRIGGER POSDEL3_BIS
  
 AFTER DELETE 
	
  ON R5BINSTOCK
  
 FOR EACH ROW 
BEGIN
  IF O7gtsusr <> 'SYS' THEN

  o7mobile_sync_event ( 'R5BINSTOCK','DELETE', 'BIS_BIN' || CHR(13) || 'BIS_LOT' || CHR(13) || 'BIS_PART' || CHR(13) || 'BIS_PART_ORG' || CHR(13) || 'BIS_STORE', :old.BIS_BIN || CHR(13) || :old.BIS_LOT || CHR(13) || :old.BIS_PART || CHR(13) || :old.BIS_PART_ORG || CHR(13) || :old.BIS_STORE, NULL );

  END IF;
END posdel_BIS;
/
