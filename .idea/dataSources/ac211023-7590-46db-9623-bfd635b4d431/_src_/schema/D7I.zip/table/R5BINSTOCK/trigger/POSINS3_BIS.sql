CREATE TRIGGER POSINS3_BIS
  
 AFTER INSERT 
	
  ON R5BINSTOCK
  
 FOR EACH ROW 
BEGIN
  IF O7gtsusr <> 'SYS' THEN

  o7mobile_sync_event ( 'R5BINSTOCK','INSERT', 'BIS_BIN' || CHR(13) || 'BIS_LOT' || CHR(13) || 'BIS_PART' || CHR(13) || 'BIS_PART_ORG' || CHR(13) || 'BIS_STORE', :new.BIS_BIN || CHR(13) || :new.BIS_LOT || CHR(13) || :new.BIS_PART || CHR(13) || :new.BIS_PART_ORG || CHR(13) || :new.BIS_STORE, NULL );

  END IF;
END posins_BIS;
/
