CREATE TRIGGER PREDEL_BIS
  
 BEFORE DELETE 
	
  ON R5BINSTOCK
  
 FOR EACH ROW 
DECLARE
   checkresult   VARCHAR2(  4 );
   cerrsource    VARCHAR2( 32 );
   cerrtype      VARCHAR2(  4 );
   db_error      EXCEPTION;
BEGIN
 IF o7gtsusr <> 'SYS' THEN
/* Initialize                  */
   checkresult := '0';
/* S32411 - Check that qty is 0 */
   o7debis1( :old.bis_qty, checkresult );
   IF checkresult <> '0' THEN
      cerrsource := 'O7DEBIS1';
      cerrtype   := 'PROC';
      RAISE db_error;
   END IF;
 END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END predel_bis;
/
