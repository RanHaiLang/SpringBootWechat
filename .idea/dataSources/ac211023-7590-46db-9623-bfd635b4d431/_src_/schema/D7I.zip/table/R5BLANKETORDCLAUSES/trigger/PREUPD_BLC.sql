CREATE TRIGGER PREUPD_BLC
  
 BEFORE UPDATE 
	
  ON R5BLANKETORDCLAUSES
  
 FOR EACH ROW 
DECLARE
   checkresult   VARCHAR2(  4 );
   cerrsource    VARCHAR2( 32 );
   cerrtype      VARCHAR2(  4 );
   db_error      EXCEPTION;
   ncountit1     NUMBER; /* counter for number of rows selected */
   ncountit2     NUMBER; /* counter for number of rows selected */
   ncountit3     NUMBER; /* counter for number of rows selected */
BEGIN
IF o7gtsusr <> 'SYS' THEN
/* Initialize                                                              */
   ncountit1   :=  0;
   ncountit2   :=  0;
   ncountit3   :=  0;
   checkresult := '0';
/* M27221 -  Prevent update if Active Order, Order Line, Or Requisition    */
/*           Line ( that was created from this Blanket Order ) exists      */
   BEGIN
      SELECT COUNT( * )
      INTO   ncountit1
      FROM   r5orders o
      WHERE  o.ord_blanketorder = :old.blc_blanketorder
      AND    o.ord_rstatus = 'A';
      SELECT COUNT( * )
      INTO   ncountit2
      FROM   r5orderlines o
      WHERE  o.orl_blanketorder = :old.blc_blanketorder
      AND    o.orl_active = '+';
   END;
   IF ncountit1 > 0
   OR ncountit2 > 0
   OR ncountit3 > 0  THEN
      checkresult := '900';
      cerrsource  := 'PREUPD_BLC';
      cerrtype    := 'TRIG';
      RAISE db_error;
   END IF;
END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preupd_blc;
/
