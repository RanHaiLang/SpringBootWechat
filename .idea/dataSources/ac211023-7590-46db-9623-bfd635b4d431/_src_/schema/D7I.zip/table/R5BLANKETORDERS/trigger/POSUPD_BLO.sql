CREATE TRIGGER POSUPD_BLO
  
 AFTER UPDATE 
	
  ON R5BLANKETORDERS
  
 FOR EACH ROW 
DECLARE
   checkresult VARCHAR2( 4 ) := '0';
   x           VARCHAR2( 1 );
   chk         VARCHAR2( 3 );
   ndeforg     r5install.ins_desc%TYPE := o7dflt('DEFORG', chk);

   /* 21CFR11 */
   cseqno       VARCHAR2( 30 );
   cseqno1      VARCHAR2( 30 );
   chk1         VARCHAR2(  6 );

   CURSOR bll IS
     SELECT * FROM r5blanketordlines
     WHERE bll_blanketorder = :new.blo_blanketorder;

BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* M2525 - Update descriptions (r5descriptions)   */
    o7descs( 'UPD', x, 'BORD', x, '*', :new.blo_blanketorder, :new.blo_org,
             :new.blo_desc, checkresult );
    IF checkresult <> '0' THEN
       o7err.raise_error( 'O7DESCS', 'PROC', checkresult );
    END IF;
    /* M2522G - When Class is updated remove old class's custom attrib. values */
    IF NVL( :old.blo_class, '*' ) <> '*'
       AND ( ( NVL( :new.blo_class, '*' ) <> :old.blo_class
	   OR NVL( :new.blo_class_org, ndeforg ) <> :old.blo_class_org) )
    THEN
       DELETE FROM r5propertyvalues
       WHERE prv_rentity     = 'BORD'
       AND   prv_class       = :old.blo_class
       AND   prv_class_org   = :old.blo_class_org
       AND   prv_code        = :old.blo_blanketorder;
    END IF;

    /* 21CFR11 BEGIN */
    BEGIN
      IF o7erecord ('UPD', 'BORD', :old.blo_status, :new.blo_status ) > 0 THEN
        r5o7.o7maxseq( cseqno, 'EREC', '1', chk1 );
        INSERT INTO r5elecarchive (  ELA_CODE,  ELA_USER,  ELA_DATE,   ELA_SIGNTYPE, ELA_CERTIFYNUM,ELA_CERTIFYTYPE,
                                  ELA_SCODE, ELA_ENTITY,ELA_ENTCODE,ELA_ENTORG,   ELA_STATUS, ELA_PARENT,
                                  ELA_FLD1,  ELA_FLD2,   ELA_FLD3,   ELA_FLD4,
                                  ELA_FLD5,  ELA_FLD6,   ELA_FLD7,   ELA_FLD8,
                                  ELA_FLD9,  ELA_FLD10,  ELA_FLD11,  ELA_FLD12,
                                  ELA_FLD13, ELA_FLD14,  ELA_FLD15,  ELA_FLD16,
                                  ELA_FLD17, ELA_FLD18,  ELA_FLD19,  ELA_FLD20,
                                  ELA_FLD21, ELA_FLD22,  ELA_FLD23,  ELA_FLD24,
                                  ELA_FLD25, ELA_FLD26,  ELA_FLD27,  ELA_FLD28,
                                  ELA_FLD29, ELA_FLD30,  ELA_FLD31 )
        VALUES ( cseqno,          o7esign.getuser,  o7gttime( :new.blo_org ), o7esign.getstype,
                 o7esign.getcertifynum,o7esign.getcertifytype,
                 '',   'BORD',          :new.blo_blanketorder, :new.blo_org,        :new.blo_status,    '',
                 :new.BLO_BLANKETORDER, :new.BLO_DESC,  :new.BLO_CLASS,      :new.BLO_STATUS,
                 :new.BLO_RSTATUS,      TO_CHAR(:new.BLO_CREATED,'DD-MON-YYYY'),
                 :new.BLO_SUPPLIER,     :new.BLO_STORE, :new.BLO_CURR,       :new.BLO_EXCH,
                 :new.BLO_BUYER,        :new.BLO_MAXAMOUNT, :new.BLO_CURAMOUNTREL, :new.BLO_NUMRELEASED,
                 TO_CHAR(:new.BLO_START,'DD-MON-YYYY'),
                 TO_CHAR(:new.BLO_END,'DD-MON-YYYY'),
                 TO_CHAR(:new.BLO_LASTRELEASED,'DD-MON-YYYY'),
                 :new.BLO_LASTORD,      :new.BLO_APPROVEORDER, :new.BLO_PAYMENTTERMS, :new.BLO_FREIGHTTERMS,
                 :new.BLO_SHIPVIA,      :new.BLO_FOBPOINT,     :new.BLO_ORG,          :new.BLO_EXCHTODUAL,
                 :new.BLO_EXCHFROMDUAL, :new.BLO_CLASS_ORG,    :new.BLO_SUPPLIER_ORG, :new.BLO_LASTORD_ORG,
                 :new.blo_updatecount,  :new.blo_paybymethod );

        FOR i IN bll LOOP
          r5o7.o7maxseq( cseqno1, 'EREC', '1', chk1 );
          INSERT INTO r5elecarchive (  ELA_CODE,  ELA_USER,  ELA_DATE,   ELA_SIGNTYPE, ELA_CERTIFYNUM,ELA_CERTIFYTYPE,
                                    ELA_SCODE, ELA_ENTITY, ELA_ENTCODE,ELA_ENTORG,   ELA_STATUS, ELA_PARENT,
                                    ELA_FLD1,  ELA_FLD2,   ELA_FLD3,   ELA_FLD4,
                                    ELA_FLD5,  ELA_FLD6,   ELA_FLD7,   ELA_FLD8,
                                    ELA_FLD9,  ELA_FLD10,  ELA_FLD11,  ELA_FLD12,
                                    ELA_FLD13, ELA_FLD14,  ELA_FLD15,  ELA_FLD16,
                                    ELA_FLD17, ELA_FLD18,  ELA_FLD19,  ELA_FLD20,
                                    ELA_FLD21, ELA_FLD22,  ELA_FLD23,  ELA_FLD24,
                                    ELA_FLD25, ELA_FLD26,  ELA_FLD27,  ELA_FLD28,
                                    ELA_FLD29, ELA_FLD30,  ELA_FLD31,  ELA_FLD32,
                                    ELA_FLD33, ELA_FLD34,  ELA_FLD35,  ELA_FLD36,
                                    ELA_FLD37, ELA_FLD38,  ELA_FLD39 )
          VALUES ( cseqno1,         o7esign.getuser,    o7gttime( :new.blo_org ),         o7esign.getstype,
                   o7esign.getcertifynum,  o7esign.getcertifytype,
                   '',         'BORL',     i.bll_blanketline,        :NEW.blo_org,    '',               cseqno,
                   i.BLL_BLANKETORDER,     i.BLL_BLANKETLINE,        i.BLL_TYPE,           i.BLL_RTYPE,
                   i.BLL_COMMODITY,        i.BLL_PART,               i.BLL_UOM,            i.BLL_UOMPRICE,
                   i.BLL_MULTIPLY,         i.BLL_CURR,               i.BLL_EXCH,           i.BLL_QTY,
                   i.BLL_MAXLINEQTY,       i.BLL_MAXLINEAMOUNT,      i.BLL_CURQTYREL,      i.BLL_CURAMOUNTREL,
                   i.BLL_NUMRELEASED,      i.BLL_LASTORD,            i.BLL_QUOTATION,      i.BLL_QUOTELINE,
                   i.BLL_SEQNO,            i.BLL_EXCHTODUAL,         i.BLL_EXCHFROMDUAL,   i.BLL_REF,
                   i.BLL_LASTORD_ORG,      i.BLL_PART_ORG,           i.BLL_INSPECT,        i.bll_updatecount,
                   i.bll_task,             i.bll_trade,              i.bll_costcode,       i.bll_ordqty,
                   i.bll_taskqty,          i.bll_puruom,             i.bll_price,          i.bll_deladdress,
                   i.bll_object,           i.bll_object_org,         i.bll_taskrev  );
        END LOOP;
        o7archive ( 'BORD', :new.blo_blanketorder, :new.blo_org, cseqno );

      END IF;
    END;

  END IF;
END posupd_blo;
/
