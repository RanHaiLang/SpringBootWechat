CREATE TRIGGER PREINS_BLOEXCH
  
 BEFORE INSERT OR UPDATE 
	
  ON R5BLANKETORDERS
  
 FOR EACH ROW 
DECLARE
  fromdual NUMBER;
  todual   NUMBER;
  exch     NUMBER;
BEGIN
IF o7gtsusr <> 'SYS' THEN
  o7gtdual( :new.blo_curr, 1000, todual, fromdual, exch, :new.blo_org, :new.blo_created );
  :new.blo_exchtodual   := todual;
  :new.blo_exchfromdual := fromdual;
END IF;
END preins_bloexch;
/
