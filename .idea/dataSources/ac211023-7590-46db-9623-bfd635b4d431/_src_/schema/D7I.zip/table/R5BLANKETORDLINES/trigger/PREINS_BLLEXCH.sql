CREATE TRIGGER PREINS_BLLEXCH
  
 BEFORE INSERT OR UPDATE 
	
  ON R5BLANKETORDLINES
  
 FOR EACH ROW 
DECLARE
  fromdual   NUMBER;
  todual     NUMBER;
  exch       NUMBER;
  exchorg    r5blanketorders.blo_org%TYPE;
  blocreated DATE;
BEGIN
 IF o7gtsusr <> 'SYS' THEN
     BEGIN
         SELECT blo_org, blo_created
         INTO   exchorg, blocreated
         FROM   r5blanketorders
         WHERE  blo_blanketorder = :new.bll_blanketorder;
     EXCEPTION
         WHEN OTHERS THEN
              NULL;
     END;
  o7gtdual( :new.bll_curr, :new.bll_uomprice * nvl( :new.bll_qty, 1 ),
            todual, fromdual, exch, exchorg, blocreated );
  :new.bll_exchtodual   := todual;
  :new.bll_exchfromdual := fromdual;
 END IF;
END preins_bllexch;
/
