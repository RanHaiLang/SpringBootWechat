CREATE TRIGGER PREUPD_BLL
  
 BEFORE UPDATE 
	
  ON R5BLANKETORDLINES
  
 FOR EACH ROW 
DECLARE
   checkresult   VARCHAR2(   4 );
   x             VARCHAR2(   1 );
   cerrsource    VARCHAR2(  32 );
   cerrtype      VARCHAR2(   4 );
   ntemp         NUMBER;  /* Temporary Variable to store Max Amount */
   db_error      EXCEPTION;
BEGIN
IF o7gtsusr <> 'SYS' THEN
/* Initialize                                                              */
   checkresult := '0';
   x := NULL;
/* M26223 - Price is required for catalogued Purchases                     */
   IF :new.bll_part IS NOT NULL
   AND :new.bll_uomprice IS NULL THEN
      checkresult := '4';
      cerrsource  := 'PREUPD_BLL';
      cerrtype    := 'TRIG';
      RAISE db_error;
   END IF;
/* M26225 - IF Max Amount(r5blanketorders) exists then                    */
/*          Unit Price cannot exceed it                                   */
/* M26226 - IF Max Amount(r5blanketorders) exists then                    */
/*          Max Line Amount cannot exceed it                              */
   BEGIN
      IF :new.bll_maxlineamount IS NOT NULL THEN
         IF :new.bll_uomprice IS NOT NULL THEN
            IF ROUND(( :new.bll_uomprice)/NVL(:new.bll_exch, 1 ), 2 ) * NVL(:new.bll_qty, 1) >
               ROUND(( :new.bll_maxlineamount)/ NVL(:new.bll_exch,1 ) , 2 ) THEN
               checkresult := '10';
               cerrsource  := 'PREUPD_BLL';
               cerrtype    := 'TRIG';
               RAISE db_error;
            END IF;
         END IF;
         IF :new.bll_price IS NOT NULL THEN
            IF ROUND(( :new.bll_price)/NVL(:new.bll_exch, 1 ), 2 ) * NVL(:new.bll_ordqty, 1)  >
               ROUND(( :new.bll_maxlineamount)/ NVL(:new.bll_exch,1 ) , 2 ) THEN
               checkresult := '11';
               cerrsource  := 'PREUPD_BLL';
               cerrtype    := 'TRIG';
               RAISE db_error;
            END IF;
         END IF;
      END IF;
      SELECT ROUND( b.blo_maxamount/NVL(b.blo_exch, 1 ),2 )
      INTO   ntemp
      FROM   r5blanketorders b
      WHERE  b.blo_blanketorder = :new.bll_blanketorder;

      IF ntemp IS NOT NULL THEN
         IF ROUND(( :new.bll_maxlineamount )/ NVL(:new.bll_exch, 1 ),2 ) > ntemp THEN
            checkresult := '6';
            cerrsource  := 'PREUPD_BLL';
            cerrtype    := 'TRIG';
            RAISE db_error;
         ELSIF ROUND(( :new.bll_uomprice )/ NVL(:new.bll_exch, 1 ), 2 ) * NVL(:new.bll_qty, 1) > ntemp THEN
            checkresult := '5';
            cerrsource  := 'PREUPD_BLL';
            cerrtype    := 'TRIG';
            RAISE db_error;
         ELSIF ROUND(( :new.bll_price)/NVL(:new.bll_exch, 1 ), 2 ) * NVL(:new.bll_ordqty, 1) > ntemp THEN
            checkresult := '5';
            cerrsource  := 'PREINS_BLL';
            cerrtype    := 'TRIG';
            RAISE db_error;
         END IF;
      ELSE
/* M26224 - IF Max Amount(r5blanketorders) IS NULL then either Max Line   */
/*          Quantity or Max Line Amount must be present but not both at   */
/*          the same time                                                 */
         IF :new.bll_qty IS NOT NULL THEN
            IF  :new.bll_maxlineqty IS NULL
            AND :new.bll_maxlineamount IS NULL THEN
               checkresult := '7';
               cerrsource  := 'PREUPD_BLL';
               cerrtype    := 'TRIG';
               RAISE db_error;
            END IF;
         ELSIF :new.bll_ordqty IS NOT NULL THEN
            IF :new.bll_maxlineqty IS NULL
            AND :new.bll_maxlineamount IS NULL THEN
               checkresult := '8';
               cerrsource  := 'PREINS_BLL';
               cerrtype    := 'TRIG';
               RAISE db_error;
            END IF;
         END IF;
      END IF;
      EXCEPTION
         WHEN OTHERS THEN
            RAISE;
   END;
/* M26229 - Type, rtype must exist(r5ucodes)                               */
   IF :new.bll_type IS NOT NULL THEN
      :new.bll_rtype := x;
      r5o7.o7ckcode( :new.bll_rtype, :new.bll_type, 'PLTP', checkresult );
      IF checkresult = '0' THEN
         NULL;
      ELSE
         checkresult := '3';
         cerrsource  := 'PREUPD_BLL';
         cerrtype    := 'TRIG';
         RAISE db_error;
      END IF;
   END IF;
END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preupd_bll;
/
