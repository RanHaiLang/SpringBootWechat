CREATE TRIGGER POSUPD_BOT
  
 AFTER UPDATE 
	
  ON R5BOILERTEXTS
  
 FOR EACH ROW 
declare
   nEquipLOVText   integer;

begin
    IF o7gtsusr <> 'SYS' THEN
        IF :new.bot_function ='BSDESC'  THEN
            update r5pagecache set pgc_updatecount=pgc_updatecount
                  Where pgc_TABNAME='DES';
        ELSIF :new.bot_function='BSPARA' THEN
            update r5pagecache set pgc_updatecount=pgc_updatecount
                  Where pgc_TABNAME='PAS';
        ELSIF :new.bot_function='BSADRS' THEN
            update r5pagecache set pgc_updatecount=pgc_updatecount
                  Where pgc_TABNAME='ADR';
        ELSE
            update r5pagecache set pgc_updatecount=pgc_updatecount
                  where pgc_FUNCTION=:new.bot_function;

            -- Handle boilertext changes for text on the equipment lookups
            SELECT count(1) INTO nEquipLOVText
            FROM  r5gridfield
            WHERE gfd_gridid IN ( 67, 1907, 2032, 2216, 1398, 2085, 2372, 2445, 1059, 1416, 1483, 157, 1700, 1973, 412, 1283, 1039, 1984, 1986 )
            AND   gfd_botfunction = :new.bot_function
            AND   gfd_botnumber   = :new.bot_number;

            IF( nEquipLOVText > 0 )THEN
                UPDATE r5pagecache SET pgc_updatecount = pgc_updatecount WHERE pgc_function = 'OSEQPP';
            END IF;
        END IF;
    END IF;
end POSUPD_BOT;
/
