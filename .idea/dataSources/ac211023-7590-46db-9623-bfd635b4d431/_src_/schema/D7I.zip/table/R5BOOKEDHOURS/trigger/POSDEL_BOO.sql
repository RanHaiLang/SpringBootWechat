CREATE TRIGGER POSDEL_BOO
  
 AFTER DELETE 
	
  ON R5BOOKEDHOURS
  
 FOR EACH ROW 
DECLARE
   checkresult    VARCHAR2(  4 );
   cact           NUMBER; /* Activity Code */
   cerrsource     VARCHAR2( 32 );
   cerrtype       VARCHAR2(  4 );
   db_error       EXCEPTION;
BEGIN
   IF o7gtsusr <> 'SYS' THEN
     /* Initialize */
     checkresult := '0';
     IF :new.boo_misc = '-' THEN
       /* W0340 - Update activity */
       o7upact1( 0, :old.boo_hours, :old.boo_ocrtype, :old.boo_act, :old.boo_event,
                 checkresult );
       IF checkresult <> '0'  THEN
          cerrsource := 'O7UPACT1';
          cerrtype   := 'PROC';
          RAISE db_error;
       END IF;
     END IF;
   END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END posdel_boo;
/
