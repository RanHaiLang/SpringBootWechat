CREATE TRIGGER PREDEL_BOO
  
 BEFORE DELETE 
	
  ON R5BOOKEDHOURS
  
 FOR EACH ROW 
DECLARE
  checkresult    VARCHAR2(  2 );
  cerrsource     VARCHAR2( 32 );
  cerrtype       VARCHAR2(  4 );
  db_error       EXCEPTION;
  countit        NUMBER;
BEGIN
  IF o7gtsusr <> 'SYS' THEN
    /* Intialize */
    checkresult := '0';
    SELECT count(*)
    INTO   countit
    FROM   r5bookedhours_archive
    WHERE  abk_event = :old.boo_event;
    /* W0331 - Deletion not allowed, unless archived. */
    IF countit = 0 THEN
      cerrsource := 'PREDEL_BOO';
      cerrtype   := 'TRIG';
      checkresult:= '2';
      RAISE db_error;
    END IF;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    NULL;
  WHEN db_error THEN
    o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END predel_boo;
/
