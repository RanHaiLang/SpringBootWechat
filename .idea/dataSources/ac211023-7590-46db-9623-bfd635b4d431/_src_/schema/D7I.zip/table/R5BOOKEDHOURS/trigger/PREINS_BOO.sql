CREATE TRIGGER PREINS_BOO
  
 BEFORE INSERT 
	
  ON R5BOOKEDHOURS
  
 FOR EACH ROW 
DECLARE
   boocorrection  VARCHAR2(  2 );
   checkresult    VARCHAR2(  4 ) ;
   chk            VARCHAR2(  4 );
   x              VARCHAR2(  1 ):= NULL;
   cerrsource     VARCHAR2( 32 );
   cerrtype       VARCHAR2(  4 );
   rtype          VARCHAR2(  4 );
   cevtorg        r5events.evt_org%TYPE;
   crouteparent   r5events.evt_routeparent%TYPE;
   cMultiEquipWO  r5events.evt_multiequip%TYPE;
   rate           NUMBER;
   CURSOR cur_getevt_org IS
      SELECT evt_org, evt_routeparent, COALESCE(evt_multiequip, '-')
      FROM   r5events
      WHERE  evt_code = :new.boo_event;
   db_error       EXCEPTION;
   nobjects       NUMBER;
BEGIN
IF o7gtsusr <> 'SYS' THEN
/* Initialize */
   checkresult:= '0';
   rate := :new.boo_rate;
/* Return when boo_routerec = '+' */
   IF :new.boo_routerec = '+' THEN
      r5o7.o7maxseq( :new.boo_code, 'BOO', '1', chk );
      RETURN;
   END IF;
/* W0312AA Date entered is system date */
   OPEN cur_getevt_org;
   FETCH cur_getevt_org INTO cevtorg, crouteparent, cMultiEquipWO;
   CLOSE cur_getevt_org;
/* Use org from r5events as argument in o7gttime for timezone offset */
   :new.boo_entered := o7gttime( cevtorg );
   :new.boo_ocrtype := '';
   IF :new.boo_correction IS NULL THEN
      :new.boo_correction := '-';
   END IF;
   IF :new.boo_order IS NOT NULL THEN
      boocorrection := 'SH';
   ELSE
      boocorrection := :new.boo_correction;
   END IF;
/* Call to PRE-PROCEDURE o7preboo  where all pre-insert checks are executed */
/* PVCS 2495 Paul van Gastel  Multiple trade rates (no correction occupation types)*/
   o7preboo ( 'INS',  :new.boo_event, :new.boo_act, :new.boo_date,
              :new.boo_person , :new.boo_trade, :new.boo_mrc, :new.boo_octype,
              :new.boo_ocrtype ,  boocorrection, :new.boo_on , :new.boo_off  , :new.boo_hours,
              :new.boo_rate, :new.boo_cost, x, checkresult );
   IF checkresult NOT IN( '0', '28', '33', '29', '35' ) THEN
      cerrsource := 'O7PREBOO';
      cerrtype   := 'PROC';
      RAISE db_error;
   END IF;
   IF :new.boo_misc = '+' THEN
     /* In case of misc. cost set rate back to original entered rate. */
     :new.boo_rate := rate;
     :new.boo_cost := rate * :new.boo_hours;
   END IF;
   IF :new.boo_code IS NULL THEN
     r5o7.o7maxseq( :new.boo_code, 'BOO', '1', chk );
   END IF;
   /* If we are booking hours to a MEC WO, then set the boo_routertype field */
   IF( :new.boo_event IS NOT NULL AND crouteparent IS NOT NULL )THEN
     BEGIN
		 SELECT orl_rtype
		   INTO   :new.boo_routertype
		   FROM   r5orderlines
		   WHERE  orl_event = crouteparent
		   AND    orl_act   = :new.boo_act
		   AND    orl_relatedwo = :new.boo_event
		   AND    orl_rtype LIKE 'S%';
	 EXCEPTION
	   WHEN OTHERS THEN :new.boo_routertype := '';
	 END;
   END IF;

   :new.boo_cost := ( :new.boo_hours * :new.boo_rate ) + NVL( :new.boo_taxamount, 0 );

   /* If we aren't on a Multiple Equipment Parent WO, then we don't need to split anything */
   IF( cMultiEquipWO <> '+' )THEN
      :new.boo_splithours := 'N';
   END IF;

   /* If we are splitting booked hours to children */
   IF :new.boo_event IS NOT NULL AND
      :new.boo_splithours <> 'N' THEN
      -- Count all children (boo_splithours = 'A') or only open children (boo_splithours= 'O')
      SELECT count(*)
      INTO   nobjects
      FROM   r5events
      WHERE  evt_routeparent = :new.boo_event
      AND    ( :new.boo_splithours = 'A' OR ( :new.boo_splithours = 'O' AND evt_rstatus <> 'C' ) )
      AND    EXISTS ( SELECT 'x'
                      FROM   r5activities a1,
                             r5activities a2
                      WHERE  a1.act_event = evt_code
                      AND    a1.act_act   = :new.boo_act
                      AND    a2.act_event = :new.boo_event
                      AND    a2.act_act   = :new.boo_act );
      IF NVL( nobjects, 0 ) > 0 THEN
         BEGIN
           SELECT orl_rtype
           INTO   rtype
           FROM   r5orderlines
           WHERE  orl_event = :new.boo_event
           AND    orl_act   = :new.boo_act
           AND    orl_rtype LIKE 'S%';
         EXCEPTION
           WHEN OTHERS THEN rtype := '';
         END;
         o7crboo1( :new.boo_event, :new.boo_act, :new.boo_date, :new.boo_trade,
                   :new.boo_mrc, :new.boo_person, :new.boo_octype, :new.boo_ocrtype,
                   :new.boo_hours, :new.boo_rate, :new.boo_cost, :new.boo_entered,
                   :new.boo_correction, :new.boo_order, :new.boo_order_org,
                   :new.boo_ordline, rtype, nobjects, :new.boo_splithours,
                   :new.boo_desc,:new.boo_code, :new.boo_misc, :new.boo_taxamount );
         :new.boo_orighours     := :new.boo_hours;
         :new.boo_origtaxamount := :new.boo_taxamount;
         :new.boo_taxamount     := 0;
         :new.boo_hours         := 0;
         :new.boo_on            := '';
         :new.boo_off           := '';
         :new.boo_cost          := 0;
      END IF;
    END IF;
 END IF;
EXCEPTION
   WHEN db_error THEN
      o7rae( cerrsource, cerrtype, checkresult, SQLCODE );
END preins_boo;
/
