CREATE TRIGGER XMLOUT_POSINS_HRS
  
 AFTER INSERT 
	
  ON R5BOOKEDHOURS
  
 FOR EACH ROW 
declare
v_flag varchar(2);
   usr_name	VARCHAR2(38);
   org		VARCHAR2(15);
BEGIN
/* Initialize */
		select sys_context('USERENV','SESSION_USER') into
		usr_name from dual;
		IF usr_name != 'SYS' THEN
  BEGIN
      select NVL(INS_DESC, 'N') into v_flag from R5INSTALL where INS_CODE = '@UPDPTM';
      EXCEPTION WHEN NO_DATA_FOUND THEN
        v_flag := 'N';
  END;

  if v_flag <> 'Y' then
    return;
  end if;

  --begin check : if it is PO related then exit.
  if (:NEW.BOO_ORDER IS NOT NULL) then return;
  else
    if (:NEW.BOO_PERSON IS NULL) then
      return;
    end if;
  end if;
  --end check.

    if ( :NEW.BOO_EVENT IS NOT NULL ) then
      SELECT EVT_ORG INTO org FROM R5EVENTS WHERE EVT_CODE = :NEW.BOO_EVENT;
    else
      SELECT PER_ORG INTO org FROM R5PERSONNEL WHERE PER_CODE = :NEW.BOO_PERSON;
    end if;


    INSERT INTO R5XMLTRANSTATUS
    (XTS_TRANTYPE,
    XTS_TABLE,
    XTS_KEYFLD1,
    XTS_KEYFLD2,
    XTS_KEYFLD3,
    XTS_KEYFLD4,
    XTS_KEYFLDDATE1,
    XTS_ORG,
    XTS_ORIG_MESSAGEID
    )
    VALUES
    ('UPDATEPERSONTIME',
     'R5BOOKEDHOURS',
     :NEW.BOO_EVENT,
     :NEW.BOO_ACT,
     :NEW.BOO_ACD,
     :NEW.BOO_CODE,
     :NEW.BOO_ENTERED,
     org, o7sess.get_messageid()
    );
END IF;
END;
/
