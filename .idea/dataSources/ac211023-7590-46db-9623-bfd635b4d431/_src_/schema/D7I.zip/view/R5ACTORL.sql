CREATE VIEW R5ACTORL AS SELECT a.act_event,
       a.act_act,
       e.evt_org,
       a.act_order,
       a.act_order_org,
       a.act_ordline
FROM   r5events e,
       r5activities a
WHERE  e.evt_code = a.act_event
AND    e.evt_rstatus IN ( 'C', 'R' )
AND NOT ( a.act_hire = '+' AND a.act_order IS NULL )
UNION
SELECT orl_event,
       orl_act,
       orl_order_org,
       orl_order,
       orl_order_org,
       orl_ordline
FROM   r5orders,
       r5orderlines
WHERE  ord_code    = orl_order
AND    ord_org     = orl_order_org
AND    ord_rstatus = 'A'
AND    orl_rstatus = 'A'
AND    orl_rtype   = 'SH'
/
