CREATE VIEW R5ADDETAILSVW AS (
SELECT
   add_entity,
   add_rentity,
   add_type,
   add_rtype,
   SUBSTR(add_code,1,63) add_code,
   add_lang,
   add_line,
   add_print,
   add_text,
   add_created,
   add_user,
   add_updated,
   add_upduser,
   add_updatecount
FROM r5addetails)
/
