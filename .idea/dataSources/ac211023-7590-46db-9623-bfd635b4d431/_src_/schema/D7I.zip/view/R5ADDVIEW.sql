CREATE VIEW R5ADDVIEW AS SELECT add_entity, add_rentity, add_type, add_rtype, add_code, add_lang, add_line,
       add_print, add_created, add_user, add_updated, add_upduser, add_updatecount
FROM   r5addetails
/
