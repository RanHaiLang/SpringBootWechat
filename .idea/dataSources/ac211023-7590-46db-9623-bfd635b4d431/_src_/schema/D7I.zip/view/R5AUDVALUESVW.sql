CREATE VIEW R5AUDVALUESVW AS SELECT ava_attribute,
       ava_table,
       ava_primaryid,
       ava_secondaryid,
       ava_from,
       ava_to,
       to_char(ava_changed,'YYYY-MM-DD HH24:MI:SS') ava_changed,
       ava_modifiedby,
       ava_function,
       ava_updated,
       ava_inserted,
       ava_deleted
FROM   r5audvalues
/
