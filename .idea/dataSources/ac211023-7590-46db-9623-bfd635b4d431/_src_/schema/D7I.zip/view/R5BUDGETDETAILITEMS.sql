CREATE VIEW R5BUDGETDETAILITEMS AS SELECT bdt_code bdti_code,
       bdt_budget bdti_budget,
       bdt_year bdti_year,
       bdt_period bdti_period,
       NVL (bdt_object, a_object.bit_code) bdti_object,
       NVL (bdt_object_org, a_object.bit_code_org) bdti_object_org,
       NVL (bdt_location, a_location.bit_code) bdti_location,
       NVL (bdt_location_org, a_location.bit_code_org) bdti_location_org,
       NVL (bdt_jobtype, a_jobtype.bit_code) bdti_jobtype,
       NVL (bdt_mrc, a_mrc.bit_code) bdti_mrc,
       NVL (bdt_costcode, a_costcode.bit_code) bdti_costcode,
       NVL (bdt_project, a_project.bit_code) bdti_project
FROM   r5budgetitems a_mrc,
       r5budgetitems a_jobtype,
       r5budgetitems a_location,
       r5budgetitems a_object,
       r5budgetitems a_costcode,
       r5budgetitems a_project,
       r5budgetgroups g_mrc,
       r5budgetgroups g_jobtype,
       r5budgetgroups g_location,
       r5budgetgroups g_object,
       r5budgetgroups g_costcode,
       r5budgetgroups g_project,
       r5budgetdetails
WHERE  a_object.bit_group (+) = g_object.bgr_code
AND    a_location.bit_group (+) = g_location.bgr_code
AND    a_jobtype.bit_group (+) = g_jobtype.bgr_code
AND    a_mrc.bit_group (+) = g_mrc.bgr_code
AND    a_costcode.bit_group (+) = g_costcode.bgr_code
AND    a_project.bit_group (+) = g_project.bgr_code
AND    g_object.bgr_code (+) = bdt_objectgr
AND    g_object.bgr_rentity (+) = 'OBJ'
AND    g_location.bgr_code (+) = bdt_locationgr
AND    g_location.bgr_rentity (+) = 'LOC'
AND    g_jobtype.bgr_code (+) = bdt_jobtypegr
AND    g_jobtype.bgr_rentity (+) = 'JBTP'
AND    g_mrc.bgr_code (+) = bdt_mrcgr
AND    g_mrc.bgr_rentity (+) = 'MRC'
AND    g_costcode.bgr_code (+) = bdt_costcodegr
AND    g_costcode.bgr_rentity (+) = 'CSTC'
AND    g_project.bgr_code (+) = bdt_projectgr
AND    g_project.bgr_rentity (+) = 'PROJ'
/
