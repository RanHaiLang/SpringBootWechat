CREATE VIEW R5CHILDONORDER2 AS SELECT orl_part,
       orl_part_org,
       str_parent,
       SUM( DECODE( orl_rtype,
                    'PS',
                    orl_ordqty - NVL( orl_recvqty, 0 ) - NVL( orl_scrapqty, 0 ),
                    NVL(( SELECT SUM(rpb_qty) FROM r5repairbins WHERE rpb_part = orl_part AND rpb_part_org = orl_part_org AND rpb_req = orl_req AND rpb_reqline = orl_reqline ), 0) ) )
FROM   r5stores,
       r5orderlines
WHERE  orl_store = str_code
AND    str_parent IS NOT NULL
AND    NVL( str_notused, '-' ) = '-'
AND    orl_rtype  IN ( 'PS', 'RE' )
AND    orl_active = '+'
GROUP BY str_parent,
         orl_part,
         orl_part_org
/
