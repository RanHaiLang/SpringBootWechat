CREATE VIEW R5CHILDONREQUI AS SELECT r.rql_part,
       r.rql_part_org,
       s.str_parent,
       SUM( r.rql_qty - NVL( r.rql_recvqty, 0 ) - NVL( r.rql_scrapqty, 0 ) )
FROM   r5stores s,
       r5requislines  r,
       r5requisitions q
WHERE  q.req_tocode = s.str_code
AND    q.req_code   = r.rql_req
AND    NOT( q.req_fromcode = s.str_parent AND q.req_fromrentity = 'STOR' )
AND    r.rql_active = '+'
AND    r.rql_rstatus IN ( 'U', 'R', 'A' )
AND    r.rql_rtype   IN ( 'PS', 'RE', 'RI' )
AND    s.str_parent IS NOT NULL
AND NOT EXISTS ( SELECT 'x'
                 FROM   r5orderlines o
                 WHERE  o.orl_req     = r.rql_req
                 AND    o.orl_reqline = r.rql_reqline )
GROUP BY s.str_parent,
         r.rql_part,
         r.rql_part_org
/
