CREATE VIEW R5CHILDSTOCK AS SELECT s.str_parent,
       st.sto_part,
       st.sto_part_org,
       SUM( st.sto_qty )
FROM   r5stock  st,
       r5stores s
WHERE  st.sto_store = s.str_code
AND    s.str_parent IS NOT NULL
AND    NVL( s.str_notused, '-' ) = '-'
GROUP BY s.str_parent, st.sto_part, st.sto_part_org
/
