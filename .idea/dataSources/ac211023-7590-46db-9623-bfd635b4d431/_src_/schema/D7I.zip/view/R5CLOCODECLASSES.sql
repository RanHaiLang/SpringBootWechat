CREATE VIEW R5CLOCODECLASSES AS SELECT  acl_action, acl_class, acl_class_org, 'A'
 FROM r5actclasses
  union all
 SELECT  rcl_reqm, rcl_class, rcl_class_org, 'R'
 FROM r5reqclasses
  union all
 SELECT  fca_failure, fca_class, fca_class_org, 'F'
 FROM r5failureclasses
  union all
 SELECT  cac_cause, cac_class, cac_class_org, 'C'
 FROM r5causeclasses
/
