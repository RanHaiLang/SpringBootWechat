CREATE VIEW R5COMMENTS AS SELECT
   add_entity,
   add_rentity,
   add_type,
   add_rtype,
   add_code,
   add_lang,
   add_line,
   add_print,
   add_text,
   add_created,
   add_user,
   add_updated,
   add_upduser,
   add_updatecount,
   u.usr_code usr_code_upd,
   u.usr_desc usr_desc_upd,
   c.usr_code usr_code_cre,
   c.usr_desc usr_desc_cre
FROM r5addetails, r5users c, r5users u
WHERE  add_user    = c.usr_code
AND   (add_upduser = u.usr_code(+) )
/
