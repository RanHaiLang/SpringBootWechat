CREATE VIEW R5CUSTATTRIBS AS SELECT
   apr_property,
   apr_line,
   apr_class,
   apr_class_org,
   apr_rentity,
   apr_list,
   apr_listvalid,
   apr_uom,
   apr_required,
   apr_nonupdcat
FROM    r5addproperties
/
