CREATE VIEW R5DEFPARTSUMMARYVW AS SELECT  dfa_code,dfa_origwo,dfa_origact,orl_part partcode, orl_part_org , orl_puruom ,
                    ord_store ,
                    CASE WHEN orl_req IS NULL THEN 'POONLY'
                        ELSE 'REQPO'
                    END,
                    NULL, NULL,
                    NULL , NULL , NULL ,NULL, req_code ,REQ_ORG ,
                    req_status , rql_reqline , rql_status ,
                    ord_code , ord_org , ord_status ,
                    orl_ordline , orl_status , orl_event , orl_act,
                    CASE
		       WHEN p.evt_multiequip = '-'
		    	  THEN p.evt_object
		           WHEN p.evt_multiequip = '+' AND orl_relatedwo IS NULL
		    	  THEN 'ALLEQUIPMENT'
		    	WHEN p.evt_multiequip = '+' AND orl_relatedwo = orl_event
		    	  THEN 'WOHEADEREQUIPMENT'
		    	  WHEN p.evt_multiequip = '+' AND orl_relatedwo != orl_event
		    	    THEN dfa_object
		    END ,
		    CASE
		           WHEN p.evt_multiequip = '-'
		    	  THEN p.evt_object_org
		           WHEN p.evt_multiequip = '+' AND ( orl_relatedwo IS NULL or orl_relatedwo = orl_event )
		    	  THEN null
		    	WHEN p.evt_multiequip = '+' AND orl_relatedwo != orl_event
		    	  THEN dfa_object_org
		    END ,
		    CASE
		           WHEN p.evt_multiequip = '-'
		    	  THEN null
		    	WHEN p.evt_multiequip = '+' AND orl_relatedwo IS NULL
		    	  THEN null
		    	WHEN p.evt_multiequip = '+' AND orl_relatedwo = orl_event
		    	  THEN orl_relatedwo
		    	WHEN p.evt_multiequip = '+' AND orl_relatedwo != orl_event
		    	  THEN dfa_relatedwo
		    END ,
                    CASE
                        WHEN orl_rtype='PD'
                    THEN
                    CASE
                        WHEN
                            p.evt_multiequip = '+' AND (orl_relatedwo = dfa_relatedwo OR orl_relatedwo = orl_event)
                        THEN
                                ORL_ORDQTY
                        WHEN
                            p.evt_multiequip = '+' AND  (select count(*) from r5events  where EVT_ROUTEPARENT =dfa_previouswo)>0 and orl_relatedwo is null
                        THEN
                              ROUND(ORL_ORDQTY/(select count(*) from r5events  where EVT_ROUTEPARENT = dfa_previouswo),2)
                        WHEN
                            (p.evt_multiequip = '-' OR   ORL_RELATEDWO = ORL_EVENT )
                        THEN
                             ORL_ORDQTY
                        END
                ELSE
                      null
                END,
            CASE
                WHEN
                    p.evt_multiequip = '+' AND (orl_relatedwo = dfa_relatedwo OR orl_relatedwo = orl_event)
                THEN
                    o7outstqty(ORL_ORDER,ORL_ORDER_ORG,ORL_ORDLINE)
                WHEN
                    p.evt_multiequip = '+' AND  (select count(*) from r5events  where EVT_ROUTEPARENT =dfa_previouswo)>0 and orl_relatedwo is null
                THEN
                    ROUND(o7outstqty(ORL_ORDER,ORL_ORDER_ORG,ORL_ORDLINE)/(select count(*) from r5events  where EVT_ROUTEPARENT = dfa_previouswo),2)
                WHEN
                    p.evt_multiequip = '-'
                THEN
                    o7outstqty(ORL_ORDER,ORL_ORDER_ORG,ORL_ORDLINE)
            END,
                    orl_due, ord_origin, ord_buyer,
                    ord_supplier, ord_supplier_org, null, dfa_object || '#' || dfa_object_org
           FROM r5parts, r5orders, r5deferredact,
               r5orderlines
                LEFT OUTER JOIN r5requislines  ON ( orl_req = rql_req AND orl_reqline = rql_reqline)
                LEFT OUTER JOIN r5requisitions  ON (orl_req = req_code)
                LEFT OUTER JOIN r5events p  ON (orl_event = p.evt_code)
                LEFT OUTER JOIN r5events c  ON (orl_relatedwo = c.evt_code)
          WHERE par_code = orl_part
            AND par_org = orl_part_org
            AND orl_order = ord_code
            AND orl_order_org = ord_org
            AND orl_event = dfa_previouswo
            AND orl_act = dfa_previousact
            AND dfa_object = COALESCE( c.evt_object, dfa_object )
            AND dfa_object_org = COALESCE( c.evt_object_org, dfa_object_org )
            AND (   orl_relatedwo IS NULL AND  EXISTS (SELECT 1 FROM r5events
                             WHERE evt_routeparent = dfa_previouswo AND DFA_OBJECT = EVT_OBJECT
							 	   AND DFA_OBJECT_ORG =EVT_OBJECT_ORG)
                 OR COALESCE (dfa_relatedwo, '!@#$') = COALESCE (orl_relatedwo, '!@#$') or orl_relatedwo = orl_event
                )
            AND not ((orl_rstatus = 'J') OR ( orl_rstatus = 'C' AND COALESCE(orl_recvqty, 0) =0) )
            AND (ORL_RELATEDWO = dfa_relatedwo or ORL_RELATEDWO is null or dfa_relatedwo is null or orl_relatedwo = orl_event )
            AND dfa_rstatus <>'C'
            AND EXISTS(SELECT 1 FROM R5EVENTS WHERE EVT_OBJECT=dfa_object AND EVT_OBJECT_ORG=DFA_OBJECT_ORG AND (EVT_CODE=dfa_previouswo or EVT_CODE=dfa_relatedwo))
UNION ALL
        SELECT dfa_code,dfa_origwo,dfa_origact,par_code , rql_part_org , rql_uom ,
                req_tocode, 'REQONLY', NULL, NULL,
                NULL , NULL , NULL , NULL, req_code ,REQ_ORG ,
                req_status , rql_reqline , rql_status ,
                NULL , NULL , NULL , NULL ,
                NULL , rql_event ,rql_act,
                CASE
		   WHEN p.evt_multiequip = '-'
			  THEN p.evt_object
		       WHEN p.evt_multiequip = '+' AND rql_relatedwo IS NULL
			  THEN 'ALLEQUIPMENT'
			WHEN p.evt_multiequip = '+' AND rql_relatedwo = rql_event
			  THEN 'WOHEADEREQUIPMENT'
			  WHEN p.evt_multiequip = '+' AND rql_relatedwo != rql_event
			    THEN dfa_object
		END ,
		CASE
		       WHEN p.evt_multiequip = '-'
			  THEN p.evt_object_org
		       WHEN p.evt_multiequip = '+' AND ( rql_relatedwo IS NULL or rql_relatedwo = rql_event )
			  THEN null
			WHEN p.evt_multiequip = '+' AND rql_relatedwo != rql_event
			  THEN dfa_object_org
		END ,
		CASE
		       WHEN p.evt_multiequip = '-'
			  THEN null
			WHEN p.evt_multiequip = '+' AND rql_relatedwo IS NULL
			  THEN null
			WHEN p.evt_multiequip = '+' AND rql_relatedwo = rql_event
			  THEN rql_relatedwo
			WHEN p.evt_multiequip = '+' AND rql_relatedwo != rql_event
			  THEN dfa_relatedwo
		END ,
                CASE
                    WHEN rql_rtype='PD'
                THEN
                    CASE
                        WHEN
                            p.evt_multiequip = '+' AND (rql_relatedwo = dfa_relatedwo OR rql_relatedwo = rql_event)
                        THEN
                                rql_qty
                        WHEN
                            p.evt_multiequip = '+' AND  (select count(*) from r5events  where EVT_ROUTEPARENT =dfa_previouswo)>0 and rql_relatedwo is null
                        THEN
                              ROUND(RQL_QTY/(select count(*) from r5events  where EVT_ROUTEPARENT = dfa_previouswo),2)
                        WHEN
                             (p.evt_multiequip = '-' OR   RQL_RELATEDWO = RQL_EVENT )
                        THEN
                             RQL_QTY
                        END
                ELSE
                      null
                END,
            null,
                rql_due ,req_origin , rql_buyer , rql_supplier ,
                rql_supplier_org, null, dfa_object || '#' || dfa_object_org
           FROM r5parts, r5requisitions, r5deferredact,
           r5requislines
             LEFT OUTER JOIN r5orderlines  ON (    rql_req =orl_req AND rql_reqline = orl_reqline)
             LEFT OUTER JOIN r5orders  ON (rql_req = ord_code)
             LEFT OUTER JOIN r5events p ON (rql_event = p.evt_code)
             LEFT OUTER JOIN r5events c ON (rql_relatedwo = c.evt_code)
          WHERE par_code = rql_part
            AND par_org = rql_part_org
            AND par_code = rql_part
            AND rql_req = req_code
            AND orl_req IS NULL
            AND orl_reqline IS NULL
            AND rql_event = dfa_previouswo
            AND rql_act = dfa_previousact
            AND dfa_object = COALESCE( c.evt_object, dfa_object )
            AND dfa_object_org = COALESCE( c.evt_object_org, dfa_object_org )
            AND not ((rql_rstatus = 'J') OR ( rql_rstatus = 'C' AND COALESCE(rql_recvqty, 0) =0) )
            AND (RQL_RELATEDWO =dfa_relatedwo or RQL_RELATEDWO is null
            		AND  EXISTS (SELECT 1 FROM r5events WHERE evt_routeparent = dfa_previouswo
            							AND DFA_OBJECT = EVT_OBJECT
							 	   AND DFA_OBJECT_ORG =EVT_OBJECT_ORG)
            	or dfa_relatedwo is null or rql_relatedwo = rql_event)
            AND dfa_rstatus <>'C'
            AND EXISTS(SELECT 1 FROM R5EVENTS WHERE EVT_OBJECT=dfa_object AND EVT_OBJECT_ORG=DFA_OBJECT_ORG AND (EVT_CODE=dfa_previouswo or EVT_CODE=dfa_relatedwo))
UNION ALL
        SELECT dfa_code,NULL,NULL,mlp_part , mlp_part_org , par_uom ,
                NULL , 'MATL' ,
            CASE MLP_DIRECT  WHEN '+' THEN 'DIRPUR' ELSE 'STOCK' END ,
            mlp_qty ,
                null ,
                null ,
                dfa_matlist ,MTL_REVISION, NULL ,null , NULL ,
                NULL , NULL , NULL , NULL ,
                NULL , NULL , NULL , NULL ,null,
                null ,null ,null ,NULL ,null ,
                NULL , NULL , NULL , NULL,
                NULL, mlp_line, null
          FROM  r5matlists, r5deferredact,r5matlparts,r5parts
          WHERE mtl_code = dfa_matlist
            AND mtl_revision = dfa_matlrev
            AND mtl_code = mlp_matlist
            AND mtl_revision = mlp_matlrev
            AND mlp_part = par_code
            AND mlp_part_org = par_org
UNION ALL
    SELECT dfa_code, null, null,PAR_CODE  , PAR_ORG  , par_uom ,
        RES_STORE, 'RES', 'STOCK', null,
        RES_QTY ,sto_qty ,null , NULL , NULL , null ,
        NULL ,NULL , NULL , NULL , NULL ,NULL , NULL , NULL ,null,
        NULL ,null ,null ,null ,NULL ,null ,NULL , NULL , NULL,
        NULL ,NULL, null, null
    FROM r5parts,r5deferredact, r5stock, r5reservations
    WHERE par_code = RES_PART
      AND par_org = RES_PART_ORG
      AND res_event = dfa_previouswo
      AND res_act = dfa_previousact
      AND STO_PART = RES_PART
      AND STO_PART_ORG = RES_PART_ORG
      AND STO_STORE = RES_STORE
      AND EXISTS(SELECT 1 FROM R5EVENTS WHERE EVT_MULTIEQUIP!='+' AND EVT_CODE=dfa_previouswo)
/
