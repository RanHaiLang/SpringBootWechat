CREATE VIEW R5DESCRIPTIONSVW AS (
SELECT
   des_entity,
   des_rentity,
   des_type,
   des_rtype,
   des_code,
   des_lang,
   SUBSTR(des_text,1,63) des_text,
   des_trans,
   des_org,
   des_updatecount
FROM r5descriptions)
/
