CREATE VIEW R5DWDIMENSIONFIELDSVIEW AS SELECT dmf_field,
       ddf_sourcename dmf_queryfield,
       dmf_dimtable,
       bot_text dmf_desc,
       ddf_datatype dmf_datatype,
       ddf_lvgrid dmf_lvgrid,
       bot_lang dmf_lang
FROM   r5dwdimensionfields,
       r5ddfield,
       r5boilertexts
WHERE  dmf_fieldid   = ddf_fieldid (+)
AND    dmf_botnumber = bot_number
AND    bot_function  = 'BSWHSE'
/
