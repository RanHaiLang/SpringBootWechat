CREATE VIEW R5DWFROMSTATUSES AS SELECT zst_key,
          zst_atrb||'-'||zst_code,
          zst_atrb||'-'||zst_desc,
          zst_atrb||'-'||zst_rcode,
          zst_atrb||'-'||zst_rdesc
     FROM   r5dwstatuses
/
