CREATE VIEW R5DWTOSTORES AS SELECT zso_key,
          zso_code,
          zso_desc,
          zso_classcode,
          zso_classorg,
          zso_classdesc,
          zso_locationcode,
          zso_locationorg,
          zso_locationdesc
   FROM r5dwstores
/
