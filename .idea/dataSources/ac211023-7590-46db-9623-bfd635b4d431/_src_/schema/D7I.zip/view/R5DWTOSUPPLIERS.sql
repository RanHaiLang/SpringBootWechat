CREATE VIEW R5DWTOSUPPLIERS AS SELECT zsu_key,
          zsu_code,
          zsu_desc,
          zsu_orgcode,
          zsu_orgdesc,
          zsu_classcode,
          zsu_classorg,
          zsu_classdesc,
          zsu_buyercode,
          zsu_buyername,
          zsu_parentcode,
          zsu_parentorg,
          zsu_parentdesc
   FROM r5dwsuppliers
/
