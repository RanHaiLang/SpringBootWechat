CREATE VIEW R5EVENTCODES AS SELECT a.acc_code, DECODE(a.acc_gen, 'A', 'A', 'A'),  a.acc_desc, a.acc_class, a.acc_class_org, a.acc_gen
   FROM   r5actioncodes   a
 UNION
   SELECT r.rqm_code, DECODE(r.rqm_gen, 'R', 'R', 'R'),  r.rqm_desc, r.rqm_class, r.rqm_class_org, r.rqm_gen
   FROM   r5requircodes   r
 UNION
   SELECT f.fal_code, DECODE(f.fal_gen, 'F', 'F', 'F'),  f.fal_desc, NULL, NULL, f.fal_gen
   FROM   r5failures f
 UNION
   SELECT c.cau_code, DECODE(c.cau_gen, 'C', 'C', 'C'),  c.cau_desc, NULL, NULL, c.cau_gen
   FROM   r5causes c
/
