CREATE VIEW R5EVTACT AS SELECT
   e.evt_code         eat_event,
   e.evt_org          eat_event_org,
   a.act_act          eat_act,
   a.act_mrc          eat_mrc,
   a.act_start        eat_start,
   a.act_trade        eat_trade,
   a.act_est          eat_est,
   a.act_persons      eat_persons,
   a.act_duration     eat_duration,
   a.act_project      eat_project,
   a.act_projbud      eat_projbud,
   a.act_matlist      eat_matlist,
   a.act_matlrev      eat_matlrev,
   a.act_hire         eat_hire,
   a.act_ordered      eat_ordered,
   a.act_order        eat_order,
   a.act_order_org    eat_order_org,
   a.act_nt           eat_nt,
   a.act_ot           eat_ot,
   e.evt_desc         eat_desc,
   e.evt_ppm          eat_ppm,
   e.evt_ppmrev       eat_ppmrev,
   e.evt_costcode     eat_costcode,
   e.evt_object       eat_object,
   e.evt_object_org   eat_object_org,
   e.evt_obrtype      eat_obrtype,
   e.evt_obtype       eat_obtype,
   e.evt_location     eat_location,
   e.evt_location_org eat_location_org,
   e.evt_rstatus      eat_rstatus,
   e.evt_completed    eat_completed,
   e.evt_jobtype      eat_jobtype,
   e.evt_enteredby    eat_enteredby
FROM   r5events e,
       r5projects p,
       r5activities a
WHERE  e.evt_code = a.act_event
AND    e.evt_target IS NOT NULL
AND    e.evt_target IS NOT NULL
AND    e.evt_project = p.prj_code(+)
AND  ( p.prj_rstatus IS NULL OR p.prj_rstatus <> 'B')
/
