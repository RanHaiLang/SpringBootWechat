CREATE VIEW R5EVTCOST AS SELECT
   e.evt_code,
   e.evt_desc,
   e.evt_reqm,
   e.evt_action,
   e.evt_completed,
   e.evt_costcode,
   o.eob_object,
   o.eob_object_org,
   o.eob_obtype,
   e.evt_metuom,
   e.evt_failureusage,
   e.evt_cause,
   e.evt_failure,
   e.evt_jobtype
FROM   r5events       e,
       r5eventobjects o
WHERE  e.evt_code    = o.eob_event
AND    e.evt_rstatus = 'C'
AND (  e.evt_rtype   = 'JOB'
    OR e.evt_rtype   = 'PPM' )
AND    o.eob_rollup  = '+'
/
