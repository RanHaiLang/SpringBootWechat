CREATE VIEW R5INVALLOC AS SELECT ina_pk,
       ina_invoice,
       ina_invoice_org,
       ina_invline,
       orl_part,
       orl_part_org,
       ina_origqty,
       ina_remqty,
       ina_price,
       ina_active,
       ina_inactivated
FROM   r5invoicelines,
       r5orderlines,
       r5invoiceallocations
WHERE  ina_invoice     = ivl_invoice
AND    ina_invoice_org = ivl_invoice_org
AND    ina_invline     = ivl_invline
AND    ivl_order       = orl_order
AND    ivl_order_org   = orl_order_org
AND    ivl_ordline     = orl_ordline
/
