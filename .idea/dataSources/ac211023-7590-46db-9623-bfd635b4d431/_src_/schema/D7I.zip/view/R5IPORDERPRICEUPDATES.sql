CREATE VIEW R5IPORDERPRICEUPDATES AS SELECT orl.rowid dtl_rowid,
         cat.rowid cat_rowid,
         rowidtochar(orl.rowid) || rowidtochar(cat.rowid) mp2itemid,
         RPAD(orl.orl_puruom, 50, ' ') uow,
         orl.orl_price unitcost,
         cat.cat_leadtime leadtime,
         cat.cat_desc defaultdescription,
         com_ipvendor defaultvendor,
         cat.cat_ref vendoritemnum,
         uog.uog_user, uog.uog_group, orl.orl_ordline, ord."ORD_CODE",ord."ORD_DESC",ord."ORD_CLASS",ord."ORD_TYPE",ord."ORD_RTYPE",ord."ORD_SUPPLIER",ord."ORD_DATE",ord."ORD_DUE",ord."ORD_APPROV",ord."ORD_STATUS",ord."ORD_RSTATUS",ord."ORD_AUTH",ord."ORD_CONTRACT",ord."ORD_DISCPERC",ord."ORD_DISCOUNT",ord."ORD_PRICE",ord."ORD_CURR",ord."ORD_EXCH",ord."ORD_ORIGIN",ord."ORD_STORE",ord."ORD_PRINTED",ord."ORD_BUYER",ord."ORD_PAYMENTTERMS",ord."ORD_FREIGHTTERMS",ord."ORD_SHIPVIA",ord."ORD_FOBPOINT",ord."ORD_DFLTAUTH",ord."ORD_REVISION",ord."ORD_REVISED",ord."ORD_BLANKETORDER",ord."ORD_SOURCESYSTEM",ord."ORD_SOURCECODE",ord."ORD_INTERFACE",ord."ORD_BLANKETRELEASE",ord."ORD_EXCHTODUAL",ord."ORD_EXCHFROMDUAL",ord."ORD_DELADDRESS",ord."ORD_ORG",ord."ORD_CLASS_ORG",ord."ORD_SUPPLIER_ORG",ord."ORD_CREDITCARD",ord."ORD_CONTROLNO",ord."ORD_PAYBYMETHOD",ord."ORD_IPTRANSMITTED",ord."ORD_UPDATECOUNT",ord."ORD_CREATED",ord."ORD_UPDATED",ord."ORD_ACD",ord."ORD_JECATEGORY",ord."ORD_JESOURCE",ord."ORD_ATTENTIONTO",ord."ORD_UDFCHAR01",ord."ORD_UDFCHAR02",ord."ORD_UDFCHAR03",ord."ORD_UDFCHAR04",ord."ORD_UDFCHAR05",ord."ORD_UDFCHAR06",ord."ORD_UDFCHAR07",ord."ORD_UDFCHAR08",ord."ORD_UDFCHAR09",ord."ORD_UDFCHAR10",ord."ORD_UDFCHAR11",ord."ORD_UDFCHAR12",ord."ORD_UDFCHAR13",ord."ORD_UDFCHAR14",ord."ORD_UDFCHAR15",ord."ORD_UDFCHAR16",ord."ORD_UDFCHAR17",ord."ORD_UDFCHAR18",ord."ORD_UDFCHAR19",ord."ORD_UDFCHAR20",ord."ORD_UDFCHAR21",ord."ORD_UDFCHAR22",ord."ORD_UDFCHAR23",ord."ORD_UDFCHAR24",ord."ORD_UDFCHAR25",ord."ORD_UDFCHAR26",ord."ORD_UDFCHAR27",ord."ORD_UDFCHAR28",ord."ORD_UDFCHAR29",ord."ORD_UDFCHAR30",ord."ORD_UDFNUM01",ord."ORD_UDFNUM02",ord."ORD_UDFNUM03",ord."ORD_UDFNUM04",ord."ORD_UDFNUM05",ord."ORD_UDFDATE01",ord."ORD_UDFDATE02",ord."ORD_UDFDATE03",ord."ORD_UDFDATE04",ord."ORD_UDFDATE05",ord."ORD_UDFCHKBOX01",ord."ORD_UDFCHKBOX02",ord."ORD_UDFCHKBOX03",ord."ORD_UDFCHKBOX04",ord."ORD_UDFCHKBOX05",ord."ORD_LASTSTATUSUPDATE",ord."ORD_REVISIONREASON",ord."ORD_PACKAGETRACKINGNUMBER"
    FROM r5orders ord,
         r5orderlines orl,
         r5companies com,
         r5ippermissions ipp,
         r5ipgrouppermissions ipg,
         r5userorganization uog,
         r5catalogue cat
   WHERE ord.ord_code = orl.orl_order
     AND ord.ord_org = orl.orl_order_org
     AND ord.ord_supplier = com.com_code
     AND ord.ord_supplier_org = com.com_org
     AND orl.orl_rstatus = 'U'
     AND orl.orl_rtype IN ( 'PS', 'PD' )
     AND com_ipvendor IS NOT NULL
     AND orl.orl_ref IS NOT NULL
     AND ord.ord_org = uog.uog_org
     AND uog.uog_group = ipg.ipg_group
     AND ipp_mnemonic = 'PMPORD'
     AND ipg_permission = ipp.ipp_code
     AND cat.cat_part = orl.orl_part
     AND cat.cat_part_org = orl.orl_part_org
     AND cat.cat_ref = orl.orl_ref
     AND ipp.ipp_function = 5
/
