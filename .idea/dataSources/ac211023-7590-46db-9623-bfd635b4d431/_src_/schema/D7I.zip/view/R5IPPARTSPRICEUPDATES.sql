CREATE VIEW R5IPPARTSPRICEUPDATES AS SELECT   par.rowid dtl_rowid,
         cat.rowid cat_rowid,
         rowidtochar(par.rowid) || rowidtochar(cat.rowid) mp2itemid,
         RPAD(cat.cat_puruom, 50, ' ') uow,
         cat.cat_purprice unitcost,
         cat.cat_leadtime leadtime,
         cat.cat_desc defaultdescription,
         com_ipvendor defaultvendor,
         cat.cat_ref vendoritemnum,
         uog.uog_user, uog.uog_group, par."PAR_CODE",par."PAR_DESC",par."PAR_CLASS",par."PAR_UOM",par."PAR_BYASSET",par."PAR_BYLOT",par."PAR_CATEGORY",par."PAR_BASEPRICE",par."PAR_AVGPRICE",par."PAR_LASTPRICE",par."PAR_STDPRICE",par."PAR_PREFSUP",par."PAR_PREFSUPPRICE",par."PAR_PREFUOM",par."PAR_COMMODITY",par."PAR_SUBCOMMODITY",par."PAR_TAX",par."PAR_BUYER",par."PAR_SOURCESYSTEM",par."PAR_SOURCECODE",par."PAR_INTERFACE",par."PAR_NOTUSED",par."PAR_TRACKTYPE",par."PAR_TRACKRTYPE",par."PAR_TOOL",par."PAR_WARDAYS",par."PAR_ORG",par."PAR_CLASS_ORG",par."PAR_PREFSUP_ORG",par."PAR_INSPECT",par."PAR_INSMETHOD",par."PAR_CODESTRUCTURE",par."PAR_COREVALUE",par."PAR_REPAIRABLE",par."PAR_CREATED",par."PAR_CREATEDBY",par."PAR_UPDATED",par."PAR_UPDATEDBY",par."PAR_UPDATECOUNT",par."PAR_SAVEHISTORY",par."PAR_CALSTANDARD",par."PAR_PREVENTREORDERS",par."PAR_FUGITIVEEMISSIONGAS",par."PAR_SYSLEVEL",par."PAR_ASMLEVEL",par."PAR_COMPLEVEL",par."PAR_LASTSTATUSUPDATE",par."PAR_UDFCHAR01",par."PAR_UDFCHAR02",par."PAR_UDFCHAR03",par."PAR_UDFCHAR04",par."PAR_UDFCHAR05",par."PAR_UDFCHAR06",par."PAR_UDFCHAR07",par."PAR_UDFCHAR08",par."PAR_UDFCHAR09",par."PAR_UDFCHAR10",par."PAR_UDFCHAR11",par."PAR_UDFCHAR12",par."PAR_UDFCHAR13",par."PAR_UDFCHAR14",par."PAR_UDFCHAR15",par."PAR_UDFCHAR16",par."PAR_UDFCHAR17",par."PAR_UDFCHAR18",par."PAR_UDFCHAR19",par."PAR_UDFCHAR20",par."PAR_UDFCHAR21",par."PAR_UDFCHAR22",par."PAR_UDFCHAR23",par."PAR_UDFCHAR24",par."PAR_UDFCHAR25",par."PAR_UDFCHAR26",par."PAR_UDFCHAR27",par."PAR_UDFCHAR28",par."PAR_UDFCHAR29",par."PAR_UDFCHAR30",par."PAR_UDFNUM01",par."PAR_UDFNUM02",par."PAR_UDFNUM03",par."PAR_UDFNUM04",par."PAR_UDFNUM05",par."PAR_UDFDATE01",par."PAR_UDFDATE02",par."PAR_UDFDATE03",par."PAR_UDFDATE04",par."PAR_UDFDATE05",par."PAR_UDFCHKBOX01",par."PAR_UDFCHKBOX02",par."PAR_UDFCHKBOX03",par."PAR_UDFCHKBOX04",par."PAR_UDFCHKBOX05",par."PAR_KIT",par."PAR_SAFETYREVIEWREQUIRED",par."PAR_SAFETYREVIEWED",par."PAR_SAFETYREVIEWEDBY",par."PAR_SAFETYREVIEWEDNAME",par."PAR_SAFETYREVIEWEDTYPE",par."PAR_TRACKBYCONDITION",par."PAR_PARENTPART",par."PAR_CONDITIONTPL",par."PAR_CONDITIONTPL_ORG",par."PAR_CONDITION",par."PAR_LONGDESCRIPTION"
    FROM r5parts par,
         r5companies com,
         r5ippermissions ipp,
         r5ipgrouppermissions ipg,
         r5userorganization uog,
         r5catalogue cat
   WHERE cat.cat_part = par.par_code
     AND cat.cat_part_org = par.par_org
     AND cat.cat_supplier = com.com_code
     AND cat.cat_supplier_org = com.com_org
     AND com_ipvendor IS NOT NULL
     AND par_org = uog.uog_org
     AND uog.uog_group = ipg.ipg_group
     AND ipp_mnemonic = 'SMPART'
     AND ipg_permission = ipp_code
     AND ipp.ipp_function = 5
/
