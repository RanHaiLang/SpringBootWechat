CREATE VIEW R5IPREQLINEAVAIL AS SELECT rql.ROWID rql_rowid,
       site.des_text SITENAME,
       mp5i.des_text COMPANYNAME,
       mp5i.des_text FROM_LOCATIONID,
       ipv.ipv_desc  TO_LOCATIONID,
       NVL(reqd.adr_address1, NVL(rqed.adr_address1, NVL(strd.adr_address1, deli.adr_address1 ))) SHIPTO_ADDRESS1,
       DECODE(reqd.adr_address1, NULL, DECODE(rqed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_address2, strd.adr_address2),rqed.adr_address2) , reqd.adr_address2  ) SHIPTO_ADDRESS2,
       DECODE(reqd.adr_address1, NULL, DECODE(rqed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_address3, strd.adr_address3),rqed.adr_address3) , reqd.adr_address3 ) SHIPTO_ADDRESS3,
       DECODE(reqd.adr_address1, NULL, DECODE(rqed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_city, strd.adr_city),rqed.adr_city) , reqd.adr_city ) SHIPTO_CITY,
       DECODE(reqd.adr_address1, NULL, DECODE(rqed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_state, strd.adr_state),rqed.adr_state) , reqd.adr_state ) SHIPTO_STATE,
       DECODE(reqd.adr_address1, NULL, DECODE(rqed.adr_address1, NULL, DECODE(strd.adr_address1,NULL, deli.adr_zip, strd.adr_zip),rqed.adr_zip) , reqd.adr_zip ) SHIPTO_ZIP
  FROM r5requisitions req,
       r5requislines rql,
       r5companies com,
       r5descriptions mp5i,
       r5descriptions site,
       r5ipvendors ipv,
       r5address rqed, --Requisition entity delivery address
       r5address strd,
       r5address reqd,   --Requisition code delivery address
       r5address deli,
       r5entities ent
WHERE  req.req_code = rql.rql_req
   AND rql.rql_supplier = com.com_code
   AND rql.rql_supplier_org = com.com_org
   AND com.com_ipvendor = ipv.ipv_code
   AND ent.ent_table = 'R5REQUISITIONS'
   AND mp5i.des_rentity = 'COMP'
   AND mp5i.des_code = '*'
   AND mp5i.des_org = com.com_org
   AND mp5i.des_rtype = '*'
   AND mp5i.des_lang = 'EN'
   AND site.des_rentity = 'ORG'
   AND site.des_code = req.req_org
   AND site.des_org = '*'
   AND site.des_lang = 'EN'
   AND site.des_rtype = '*'
   AND deli.adr_code (+) = '*#' || com.com_org
   AND deli.adr_rentity (+) = 'COMP'
   AND deli.adr_rtype (+) = 'D'
   AND strd.adr_code (+)  = req.req_tocode
   AND strd.adr_rentity  (+)  = 'STOR'
   AND strd.adr_rtype (+)  = 'D'
   AND rqed.adr_code (+) = ent.ent_rentity
   AND rqed.adr_rentity (+) = 'ENT'
   AND rqed.adr_rtype (+) = 'D'
   AND reqd.adr_code (+) = req.req_code
   AND reqd.adr_rentity (+) = 'REQ'
   AND reqd.adr_rtype (+) = 'D'
   AND NOT (deli.adr_code IS NULL AND rqed.adr_code IS NULL AND strd.adr_code IS NULL AND reqd.adr_code IS NULL)
   AND req_rstatus = 'U'
   AND rql_rtype IN ('PD', 'PS')
/
