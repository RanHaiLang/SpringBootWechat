CREATE VIEW R5IPREQUISITIONPRICEUPDATES AS SELECT rql.rowid dtl_rowid,
         cat.rowid cat_rowid,
         rowidtochar(rql.rowid) || rowidtochar(cat.rowid) mp2itemid,
         RPAD(rql.rql_uom, 50, ' ') uow,
         rql.rql_price unitcost,
         cat.cat_leadtime leadtime,
         cat.cat_desc defaultdescription,
         com_ipvendor defaultvendor,
         cat.cat_ref vendoritemnum,
         uog.uog_user,
         uog.uog_group,
         rql.rql_reqline,
         req_code,
         req_desc,
         req_class,
         req_date,
         req_status,
         req_rstatus,
         req_auth,
         req_origin,
         req_fromentity,
         req_fromrentity,
         req_fromtype,
         req_fromrtype,
         req_fromcode,
         req_toentity,
         req_torentity,
         req_totype,
         req_tortype,
         req_tocode,
         req_type,
         req_rtype,
         req_event,
         req_act,
         req_costcode,
         req_printed,
         req_dfltauth,
         req_acd,
         req_interface,
         req_deladdress,
         req_org,
         req_class_org,
         req_fromcode_org,
         req_sourcecode,
         req_enteredby,
         req_rejectreason
    FROM r5requisitions req,
         r5requislines rql,
         r5companies com,
         r5ippermissions ipp,
         r5ipgrouppermissions ipg,
         r5userorganization uog,
         r5catalogue cat
   WHERE req.req_code = rql.rql_req
     AND rql_supplier = com_code
     AND rql_supplier_org = com_org
     AND rql_rstatus = 'U'
     AND rql_rtype IN ( 'PS', 'PD' )
     AND com_ipvendor IS NOT NULL
     AND rql.rql_ref IS NOT NULL
     AND req_org = uog.uog_org
     AND uog.uog_group = ipg.ipg_group
     AND ipp_mnemonic = 'SMREQS'
     AND ipg_permission = ipp_code
     AND cat.cat_part = rql.rql_part
     AND cat.cat_part_org = rql.rql_part_org
     AND cat.cat_ref = rql.rql_ref
     AND ipp.ipp_function = 5
/
