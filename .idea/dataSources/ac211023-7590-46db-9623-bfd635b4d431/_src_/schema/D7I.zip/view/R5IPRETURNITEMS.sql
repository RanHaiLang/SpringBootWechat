CREATE VIEW R5IPRETURNITEMS AS SELECT tra.ROWID tra_rowid,
         mp5i.des_text FROM_LOCATIONID,
         mp5i.des_text CUSTOMERNUM,
         tra.tra_order PONUM,
         ord.ord_supplier VENDORID,
         otr.otr_controlnum POCONFIRMATIONNUM,
         ipv.ipv_desc TO_LOCATIONID,
         trl.trl_ordline ITEMID,
         trl.trl_part ITEMNUM,
         des.des_text DESCRIPTION,
         trl.trl_qty QUANTITYRETURNED,
         ord.ord_org ORDORG,
         ord.ord_supplier_org VENDORORG,
         trl.trl_part_org ITEMORG,
         trl.trl_rejectreason REASON,
         ord.ord_date ORDERDATE
    FROM r5transactions tra,
         r5translines trl,
         r5orders ord,
         r5descriptions mp5i,
         r5descriptions des,
         r5companies com,
         r5ipvendors ipv,
         r5ordertracking otr
   WHERE tra.tra_code =trl.trl_trans
     AND tra_rstatus = 'A'
     AND tra_rtype = 'RETN'
     AND tra.tra_order = ord.ord_code
     AND tra.tra_order_org = ord.ord_org
     AND ord.ord_supplier = com.com_code                     -- join to MP5i supplier record
     AND ord.ord_supplier_org = com.com_org                  -- join to MP5i supplier record
     AND com.com_ipvendor = ipv.ipv_code
     AND mp5i.des_rentity = 'COMP' -- join to descriptions to retrieve customer name (from org)
     AND mp5i.des_code = '*'
     AND mp5i.des_org = com.com_org
     AND mp5i.des_lang = 'EN'
     AND mp5i.des_rtype = '*'
     AND ord.ord_code = otr.otr_order
     AND ord.ord_org  = otr.otr_order_org
     AND otr.otr_tracktype = 'POTR'
     AND des.des_rentity = 'PART'
     AND des.des_code = trl.trl_part
     AND des.des_org = trl.trl_part_org
     AND des.des_lang = 'EN'
     AND des.des_rtype = '*'
     AND NOT EXISTS( SELECT 'x'
                     FROM   r5ordertracking otr2
                     WHERE  ord.ord_code = otr2.otr_order
                     AND    ord.ord_org  = otr2.otr_order_org
                     AND    otr2.otr_tracktype = 'POTR'
                     AND    otr2.otr_gendate > otr.otr_gendate )
/
