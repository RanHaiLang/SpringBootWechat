CREATE VIEW R5MATCOST AS SELECT t.tra_tocode,
       SUM( NVL( l.trl_price, 0 ) * NVL( l.trl_qty, 0 ) ) -
       r5returnonevent ( t.tra_tocode )
FROM   r5translines    l,
       r5transactions  t
WHERE  l.trl_trans       = t.tra_code
AND    t.tra_torentity   = 'EVNT'
AND    t.tra_fromrentity = DECODE( l.trl_rtype,
                                   'RECV', 'COMP', t.tra_fromrentity )
AND    l.trl_rtype IN ( 'I', 'RR', 'RECV' )
GROUP BY t.tra_tocode
/
