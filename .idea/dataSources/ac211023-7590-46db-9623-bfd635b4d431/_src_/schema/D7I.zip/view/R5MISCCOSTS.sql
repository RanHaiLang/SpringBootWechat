CREATE VIEW R5MISCCOSTS AS SELECT trl_event,
       trl_act,
       trl_desc,
       trl_type,
       trl_rtype,
       NVL( trl_origqty, trl_qty ),
       trl_price,
       NVL( trl_origqty, trl_qty ) * trl_price,
       trl_date,
       trl_splittrans
FROM   r5translines
WHERE  trl_desc IS NOT NULL
AND    trl_qty <> 0
UNION ALL
SELECT boo_event,
       boo_act,
       boo_desc,
       boo_octype,
       boo_ocrtype,
       NVL( boo_orighours, boo_hours ),
       boo_rate,
       NVL( boo_orighours, boo_hours ) * boo_rate,
       boo_date,
       boo_splithours
FROM   r5bookedhours
WHERE  boo_misc = '+'
AND    boo_hours <> 0
/
