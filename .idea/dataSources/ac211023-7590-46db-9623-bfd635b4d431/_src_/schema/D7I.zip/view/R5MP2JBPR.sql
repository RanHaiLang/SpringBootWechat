CREATE VIEW R5MP2JBPR AS SELECT dtc_upcode uco_upcode, uco_entity, uco_code
    FROM r5ucodes, r5dataconversion
   WHERE uco_rentity = 'JBPR'
     AND uco_code <> '*'
/
