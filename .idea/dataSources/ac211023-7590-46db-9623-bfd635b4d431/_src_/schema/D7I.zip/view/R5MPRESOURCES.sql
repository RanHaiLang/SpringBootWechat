CREATE VIEW R5MPRESOURCES AS SELECT  mto_mpproj,
        mto_code,
        mto_desc,
        mto_org,
        mto_resourcetype,
        mto_msresourcetype,
        r5mpavailabilityList(r5mpavailability(null,NULL,null))
FROM r5mptool
UNION ALL
SELECT mpp_mpproj,
       mpp_code,
       mpp_desc,
       mpp_org,
       mpp_resourcetype,
       mpp_msresourcetype,
       CAST(MULTISET( select mpv_resinitial, mpv_date,mpv_hours from r5mpavailabilities
                      where mpv_resinitial= mpp_code)
           AS r5mpavailabilityList)
FROM r5mppersonnel
UNION ALL
SELECT meq_mpproj,
       meq_code,
       meq_desc,
       meq_org,
       meq_resourcetype,
       meq_msresourcetype,
       r5mpavailabilityList(r5mpavailability(null,NULL,null))
FROM r5mpequipment
UNION ALL
SELECT mtd_mpproj,
       mtd_code,
       mtd_desc,
       mtd_org,
       mtd_resourcetype,
       mtd_msresourcetype,
       r5mpavailabilityList(r5mpavailability(null,NULL,NULL))
FROM r5mptrade
UNION ALL
SELECT msp_mpproj,
       msp_code,
       msp_desc,
       msp_org,
       msp_resourcetype,
       msp_msresourcetype,
       r5mpavailabilityList(r5mpavailability(null,NULL,NULL))
FROM r5mpsupplier
/
