CREATE VIEW R5MULTIORGPARTLIST AS SELECT par_code, par_org, par_desc, par_class, par_category, par_tool, par_uom, par_buyer, par_prefsup,
       par_tracktype, par_wardays, par_commodity, par_subcommodity, par_tax, par_codestructure, par_insmethod,
       par_prefsupprice, par_prefuom, par_byasset, par_bylot, par_notused, par_inspect, obj_code, obj_mrc,
       obj_class, obj_manufact, obj_manufactmodel, obj_manufactrevnum, obj_variable1, obj_variable2,
       obj_variable3, obj_variable4, obj_variable5, obj_variable6, uog_user, ppr_baseprice, ppr_avgprice,
       ppr_lastprice, ppr_stdprice, ppr_pricetype, ppr_credit, ppr_corevalue
FROM   r5partprices,
       r5objects,
       r5organization,
       r5userorganization u1,
       r5install,
       r5parts
WHERE  par_code <> '*'
AND    par_code = ppr_part
AND    par_org  = ppr_part_org
AND    par_code = obj_part (+)
AND    par_org  = obj_part_org (+)
AND    'I'      = obj_obrtype (+)
AND    par_org  = org_code
AND    ins_code = 'DEFORG'
AND    ( u1.uog_default = '+' OR ( u1.uog_org = ins_desc AND NOT EXISTS
       ( SELECT 'x'
         FROM   r5userorganization u2
         WHERE  u2.uog_user = u1.uog_user
         AND    u2.uog_default = '+' ) ) )
AND    DECODE( org_common, '-', par_org,
       DECODE( u1.uog_common, '-', u1.uog_org, 'x' ) ) = ppr_org
UNION
SELECT par_code, par_org, par_desc, par_class, par_category, par_tool, par_uom, par_buyer, par_prefsup,
       par_tracktype, par_wardays, par_commodity, par_subcommodity, par_tax, par_codestructure, par_insmethod,
       par_prefsupprice, par_prefuom, par_byasset, par_bylot, par_notused, par_inspect, obj_code, obj_mrc,
       obj_class, obj_manufact, obj_manufactmodel, obj_manufactrevnum, obj_variable1, obj_variable2,
       obj_variable3, obj_variable4, obj_variable5, obj_variable6, uog_user, TO_NUMBER(null),
       TO_NUMBER(null), TO_NUMBER(null), TO_NUMBER(null), NULL, TO_NUMBER(null), TO_NUMBER(null)
FROM   r5objects,
       r5organization,
       r5userorganization u1,
       r5install,
       r5parts
WHERE  par_code <> '*'
AND    par_code = obj_part (+)
AND    par_org  = obj_part_org (+)
AND    'I'      = obj_obrtype (+)
AND    par_org  = org_code
AND    ins_code = 'DEFORG'
AND    ( u1.uog_default = '+' OR ( u1.uog_org = ins_desc AND NOT EXISTS
       ( SELECT 'x'
         FROM   r5userorganization u2
         WHERE  u2.uog_user = u1.uog_user
         AND    u2.uog_default = '+' ) ) )
AND    ((DECODE( org_common, '-', '-',
         DECODE( u1.uog_common, '-', '-', '+' ) ) = '+')
OR     (NOT EXISTS ( SELECT 'x'
                     FROM   r5partprices
                     WHERE  ppr_part     = par_code
                     AND    ppr_part_org = par_org
           AND    ppr_org = DECODE( org_common, '-', par_org,
                                      DECODE( u1.uog_common, '-', u1.uog_org, 'x' ) ))))
ORDER BY par_code
/
