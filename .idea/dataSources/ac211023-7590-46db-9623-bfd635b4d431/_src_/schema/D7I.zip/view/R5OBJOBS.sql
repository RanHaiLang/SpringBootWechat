CREATE VIEW R5OBJOBS AS SELECT o.eob_event,
       e.evt_org,
       e.evt_type,
       o.eob_obtype,
       o.eob_object,
       o.eob_object_org,
       e.evt_target,
       e.evt_reqm,
       e.evt_action,
       e.evt_desc,
       e.evt_metuom,
       e.evt_failureusage,
       e.evt_cause,
       e.evt_failure,
       e.evt_jobtype
FROM   r5events        e,
       r5eventobjects  o
WHERE  o.eob_event     = e.evt_code
AND    e.evt_rstatus   > 'C'
UNION
SELECT e.evt_code,
       e.evt_org,
       e.evt_type,
       o.obj_obtype,
       o.obj_code,
       o.obj_org,
       e.evt_target,
       e.evt_reqm,
       e.evt_action,
       e.evt_desc,
       e.evt_metuom,
       e.evt_failureusage,
       e.evt_cause,
       e.evt_failure,
       e.evt_jobtype
FROM   r5events   e,
       r5objects  o
WHERE  e.evt_object     = o.obj_position
AND    e.evt_object_org = o.obj_org
AND    e.evt_obrtype    = 'P'
AND    e.evt_rstatus    > 'C'
/
