CREATE VIEW R5ONORDER_DETAILS AS SELECT
   o.orl_req,
   o.orl_reqline,
   o.orl_order,
   o.orl_order_org,
   o.orl_ordline,
   o.orl_type,
   o.orl_store,
   o.orl_part,
   o.orl_part_org,
   NVL( o.orl_ordqty, 0 ) - NVL( o.orl_recvqty, 0 ) - NVL( o.orl_scrapqty, 0 ),
   o.orl_due,
   r.rql_quotflag,
   'COMP',
   o.orl_puruom,
   d.ord_buyer
FROM   r5orders d,
       r5requislines r,
       r5orderlines o
WHERE  d.ord_code = o.orl_order
AND    d.ord_org  = o.orl_order_org
AND    r.rql_req (+) = o.orl_req
AND    r.rql_reqline (+) = o.orl_reqline
AND    o.orl_active = '+'
AND    NVL( o.orl_ordqty, 0 ) - NVL( o.orl_recvqty, 0 ) - NVL( o.orl_scrapqty, 0 ) > 0
UNION
SELECT
   r.rql_req,
   r.rql_reqline,
   TO_CHAR( NULL ),
   TO_CHAR( NULL ),
   TO_NUMBER( NULL ),
   r.rql_type,
   e.req_tocode,
   r.rql_part,
   r.rql_part_org,
   NVL( r.rql_qty, 0 ) - NVL( r.rql_recvqty, 0 ) - NVL( r.rql_scrapqty, 0 ),
   r.rql_due,
   r.rql_quotflag,
   e.req_fromrentity,
   TO_CHAR( NULL ),
   r.rql_buyer
FROM   r5requislines  r,
       r5requisitions e
WHERE  e.req_code     = r.rql_req
AND    r.rql_rstatus  IN ('A', 'U')
AND    NVL( r.rql_qty, 0 ) - NVL( r.rql_recvqty , 0 ) - NVL( r.rql_scrapqty, 0 ) > 0
AND    NOT EXISTS (SELECT 'x'
		   FROM   r5orderlines d
		   WHERE  d.orl_req     = r.rql_req
		   AND    d.orl_reqline = r.rql_reqline )
/
