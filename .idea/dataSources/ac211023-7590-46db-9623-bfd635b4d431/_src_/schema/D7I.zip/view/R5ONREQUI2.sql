CREATE VIEW R5ONREQUI2 AS SELECT
   r.rql_part,
   r.rql_part_org,
   q.req_tocode,
   SUM( DECODE( r.rql_rtype,
               'PS', r.rql_qty - NVL( r.rql_recvqty, 0 ) - NVL( r.rql_scrapqty, 0 ),
               NVL((SELECT SUM(rpb_qty) FROM r5repairbins WHERE rpb_part = r.rql_part AND rpb_part_org = r.rql_part_org AND rpb_req = r.rql_req AND rpb_reqline = r.rql_reqline), 0) ) )
FROM     r5requislines  r,
         r5requisitions q
WHERE    q.req_code = r.rql_req
AND      r.rql_rstatus IN ( 'U', 'R', 'A' )
AND      r.rql_rtype IN ( 'PS', 'RE' )
AND      r.rql_active = '+'
AND NOT EXISTS ( SELECT 'x'
                 FROM   r5orderlines o
                 WHERE  o.orl_req     = r.rql_req
                 AND    o.orl_reqline = r.rql_reqline )
GROUP BY q.req_tocode,
         r.rql_part,
         r.rql_part_org
/
