CREATE VIEW R5OPGRAPHCORRKEYS AS SELECT
   ogc_id,
   ogc_cid
FROM r5opgraphcorr
WHERE ogc_id =
 ( SELECT MAX( ogc_id )
   FROM r5opgraphcorr )
/
