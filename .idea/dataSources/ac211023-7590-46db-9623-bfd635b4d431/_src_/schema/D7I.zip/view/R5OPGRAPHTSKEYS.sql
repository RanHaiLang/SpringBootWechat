CREATE VIEW R5OPGRAPHTSKEYS AS SELECT
   ogt_id,
   ogt_cid
FROM  r5opgraphts
WHERE ogt_id =
 ( SELECT MAX( ogt_id )
   FROM r5opgraphts )
/
