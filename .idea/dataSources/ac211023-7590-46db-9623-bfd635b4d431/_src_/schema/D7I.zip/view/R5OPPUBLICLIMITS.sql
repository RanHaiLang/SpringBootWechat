CREATE VIEW R5OPPUBLICLIMITS AS SELECT
   a.opl_audituser,
   a.opl_audittimestamp,
   a.opl_varid,
   a.opl_mth,
   a.opl_dailymin,
   a.opl_dailymax,
   a.opl_weeklymin,
   a.opl_weeklymax,
   a.opl_monthlymin,
   a.opl_monthlymax,
   a.opl_quarterlymin,
   a.opl_quarterlymax,
   a.opl_semiannualmin,
   a.opl_semiannualmax,
   a.opl_annualmin,
   a.opl_annualmax
FROM r5oplimits a,
     r5opvardesc b
WHERE a.opl_varid    = b.ovd_varid
AND   b.ovd_varscope = 2
/
