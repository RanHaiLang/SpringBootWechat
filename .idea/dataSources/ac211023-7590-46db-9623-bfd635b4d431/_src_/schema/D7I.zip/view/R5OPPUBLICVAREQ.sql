CREATE VIEW R5OPPUBLICVAREQ AS SELECT
   a.oeq_audituser,
   a.oeq_audittimestamp,
   a.oeq_datestamp,
   a.oeq_eqinfix,
   a.oeq_eqpostfix,
   a.oeq_varid
FROM r5opvareq a,
     r5opvardesc b
WHERE a.oeq_varid=b.ovd_varid AND (b.ovd_varscope=2)
/
