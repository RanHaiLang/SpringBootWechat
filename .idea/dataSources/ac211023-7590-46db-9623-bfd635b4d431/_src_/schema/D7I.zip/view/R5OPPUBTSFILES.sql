CREATE VIEW R5OPPUBTSFILES AS SELECT
   a.ogf_audituser,
   a.ogf_audittimestamp,
   a.ogf_id,
   a.ogf_dirname,
   a.ogf_filename,
   a.ogf_filedata,
   b.ogt_id,
   b.ogt_org
FROM r5opfiles a,
     r5opgraphts b
WHERE UPPER( a.ogf_filename ) = 'TS' || b.ogt_id ||'.GSP'
AND   b.ogt_ispublic          = '+'
AND   a.ogf_dirname           = 'GRAPHS'
/
