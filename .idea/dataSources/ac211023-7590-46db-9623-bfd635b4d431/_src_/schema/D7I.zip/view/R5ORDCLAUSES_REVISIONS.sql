CREATE VIEW R5ORDCLAUSES_REVISIONS AS SELECT 0,
          ORC_ORDER,
          ORC_ORDER_ORG,
          ORC_CLAUSE
   FROM   r5ordclauses
   UNION
   SELECT OCR_REVISION,
          OCR_ORDER,
          OCR_ORDER_ORG,
          OCR_CLAUSE
   FROM   r5ordclauserevs
/
