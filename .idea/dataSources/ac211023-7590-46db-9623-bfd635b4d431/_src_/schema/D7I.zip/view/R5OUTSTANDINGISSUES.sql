CREATE VIEW R5OUTSTANDINGISSUES AS SELECT tra_pers, trl_part, trl_part_org, par_kit, trl_object, trl_object_org, SUM( trl_qty ), trl_lot
FROM   r5parts, r5transactions, r5translines, r5events, r5personnel
WHERE  trl_trans = tra_code
AND    trl_part = par_code
AND    trl_part_org = par_org
AND    trl_rtype = 'I'
AND    tra_torentity = 'EVNT'
AND    tra_pers IS NOT NULL
AND    evt_object = per_object
AND    evt_object_org = per_object_org
AND    tra_tocode = evt_code
AND    per_code = tra_pers
GROUP BY tra_pers, trl_part, trl_part_org, par_kit, trl_object, trl_object_org, trl_lot
HAVING SUM( trl_qty ) > 0
/
