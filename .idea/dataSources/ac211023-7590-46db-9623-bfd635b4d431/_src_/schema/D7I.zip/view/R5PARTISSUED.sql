CREATE VIEW R5PARTISSUED AS SELECT SUM( NVL( NVL( l.trl_origqty, l.trl_qty ), 0 ) ),
	 l.trl_event,
       l.trl_act,
	 l.trl_part,
       l.trl_part_org
FROM   r5translines l
WHERE  l.trl_rtype = 'I'
AND    l.trl_io    = -1
GROUP BY l.trl_event,
         l.trl_act,
         l.trl_part,
         l.trl_part_org
/
