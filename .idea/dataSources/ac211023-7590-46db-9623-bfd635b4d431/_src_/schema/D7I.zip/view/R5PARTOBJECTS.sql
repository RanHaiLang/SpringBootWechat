CREATE VIEW R5PARTOBJECTS AS SELECT e.epa_part, e.epa_part_org, o.obj_code, o.obj_org,
       o.obj_obrtype, e.epa_qty, e.epa_uom
FROM  r5objects o, r5entityparts e
WHERE epa_rentity = 'OBJ'
AND   epa_code    = obj_category
AND   obj_obrtype <> 'C'
AND   obj_notused = '-'
UNION
SELECT e.epa_part, e.epa_part_org, o.obj_code, o.obj_org,
       o.obj_obrtype, e.epa_qty, e.epa_uom
FROM  r5objects o, r5entityparts e
WHERE epa_rentity = 'OBJ'
AND   epa_code    = obj_code||'#'||obj_org
AND   obj_obrtype <> 'C'
AND   obj_notused = '-'
/
