CREATE VIEW R5PARTSUPPRETN AS select d.tra_code,
	d.trl_order,
	d.trl_order_org,
	d.trl_ordline,
	d.trl_part,
	d.trl_part_org,
	d.trl_price,
	d.trl_object,
	d.trl_object_org,
	(CASE WHEN d.orl_rtype = 'PD'THEN o7matret( trl_order||'#'||d.trl_order_org||'#'||d.trl_ordline, d.orl_event, tra_fromrentity, trl_part, trl_part_org, trl_lot,d.orl_relatedwo, d.tra_advice)
		ELSE (CASE WHEN (CASE WHEN qty > (StockQty-ReservedQty) THEN (StockQty-ReservedQty)
						ELSE qty
						END) > NVL(BinStockQty,0) THEN NVL(BinStockQty,0)
				ELSE (CASE WHEN qty > (StockQty-ReservedQty) THEN (StockQty-ReservedQty)
					ELSE qty
					END)
				END)
		END) trl_qty,
	ordline.orl_curr,
	ordline.orl_ordqty,
	d.trl_bin,
	d.trl_lot,
	par_byasset,
	par_uom,
	(CASE d.orl_rtype WHEN 'PD' THEN '+' ELSE '-' END ) orl_direct,
	BinStockQty,
	d.orl_rtype,
	d.org_curr,
	d.orl_relatedwo,
	DECODE( NVL( e1.evt_multiequip, '-' ), '-', NULL,
	        DECODE( ordline.orl_relatedwo, NULL, 'All', d.orl_event, 'Header', e2.evt_object ) )
from
( select c.*,
	(SELECT NVL( SUM( r.res_allqty ), 0)
		FROM r5reservations r
		WHERE r.res_part = trl_part
		AND r.res_part_org = trl_part_org
		AND r.res_store = tra_fromcode
		AND ( orl_act IS NULL
		OR r.res_event <> orl_event
		OR r.res_act <> orl_act )) ReservedQty,
			(SELECT NVL( s.sto_qty, 0 )
				FROM   r5stock s
				WHERE  s.sto_part      = trl_part
				AND    s.sto_part_org  = trl_part_org
				AND    s.sto_store     = tra_fromcode) StockQty,
					(SELECT NVL( s.bis_qty,0 )
					FROM   r5binstock s
					WHERE s.bis_part = trl_part
					AND s.bis_part_org = trl_part_org
					AND s.bis_store = tra_fromcode
					AND s.bis_bin = NVL(trl_bin, '*')
					AND s.bis_lot = NVL(trl_lot, '*')) BinStockQty
from
( select
	tra_code,
	tra_fromcode,
	tra_fromrentity,
	trl_order,
	trl_order_org,
	trl_ordline,
	trl_part,
	trl_part_org,
	trl_price,
	trl_object,
	trl_object_org,
	SUM( decode(trl_rtype, 'RECV',1, -1) * trl_qty ) qty,
	NVL(trl_bin, CASE orl_rtype WHEN 'PS' THEN '*' ELSE NULL END)  trl_bin,
	NVL(trl_lot,CASE orl_rtype WHEN 'PS' THEN '*'ELSE NULL END) trl_lot,
	par_byasset,
	par_uom,
	(CASE orl_rtype WHEN 'PD' THEN '+' ELSE '-' END ) orl_direct,
	orl_act,
	orl_event,
	orl_relatedwo,
	orl_rtype,
	org_curr,
	tra_advice
from
( SELECT
	tra_code,
	tra_org,
	tra_fromrentity,
	tra_order,
	tra_order_org,
	tra_fromcode,
	tra_advice,
	tra_relatedwo
    FROM r5transactions) A,
( SELECT
	trl_order,
	trl_order_org,
	trl_ordline,
	trl_part,
	trl_line,
	trl_part_org,
	trl_price,
	trl_object,
	trl_object_org,
	orl_curr,
	orl_ordqty,
	orl_costcode,
	orl_project,
	orl_projbud,
	orl_event,
	orl_act,
	orl_relatedwo,
	NVL(obj_bin, trl_bin) trl_bin,
	NVL(obj_lot, trl_lot) trl_lot,
	orl_rtype,
	par_byasset,
	par_uom,
	orl_req,
	orl_reqline,
	obj_rstatus,
	obj_parent,
	obj_location,
	obj_store,
        obj_code,
        obj_org,
	orl_order_org,
	orl_order,
	trl_qty,
	trl_rtype,
	org_curr
FROM   r5orderlines,
	r5parts,
	r5objects,
	r5translines,
	r5transactions,
	r5organization
	WHERE  orl_part = par_code
	AND orl_part_org = par_org
	AND orl_order = trl_order
	AND orl_order_org = trl_order_org
	AND orl_ordline = trl_ordline
	AND orl_rtype IN ('PD', 'PS', 'RE' )
	AND  trl_object = obj_code (+ )
	AND trl_object_org  = obj_org ( + )
	AND tra_code  = trl_trans
	AND tra_org = org_code
	AND tra_rstatus = 'A') B
where
	orl_order = A.tra_order
	AND orl_order_org   = a.tra_order_org
	AND ((orl_event  = (select coalesce(evt_parent, evt_code) from r5events where evt_code =A.tra_fromcode)
	AND a.tra_fromrentity =  'EVNT' )
	OR ( A.tra_fromrentity <> 'EVNT' ) )
	AND  NVL( tra_advice, '%' ) LIKE NVL( A.tra_advice, '%' )
	AND ( ( par_byasset = '+' AND obj_rstatus = 'B' AND obj_store = A.tra_fromcode)
	OR (par_byasset = '+' AND obj_rstatus =  'C' AND obj_store = A.tra_fromcode )
	OR (par_byasset = '+' AND obj_rstatus =  'T' AND EXISTS
              ( SELECT 'x' FROM r5transtock WHERE  tst_object = obj_code
                AND tst_object_org = obj_org AND tst_store = a.tra_fromcode AND tst_torentity  = 'EVNT' ) )
	OR ( par_byasset = '+'
	AND obj_rstatus ='I'
	AND obj_parent IS NULL
	AND obj_location IS NULL )
	 OR par_byasset= '-' )
	AND coalesce(A.tra_relatedwo,'#') = decode(a.tra_fromrentity,'STOR', '#',coalesce(orl_relatedwo, '#'))
GROUP BY
	tra_code,
	trl_order,
	trl_order_org,
	trl_ordline,
	trl_part,
	trl_line,
	trl_part_org,
	trl_bin,
	trl_lot,
	trl_price,
	trl_object,
	trl_object_org,
	orl_curr,
	orl_ordqty,
	orl_costcode,
	orl_project,
	orl_projbud,
	orl_event,
	orl_act,
	orl_relatedwo,
	orl_rtype,
	par_byasset,
	par_uom,
	orl_req,
	orl_reqline,
	tra_fromrentity,
	tra_fromcode,
	org_curr,
	tra_advice
HAVING  SUM( DECODE( trl_rtype, 'RECV', 1, -1 ) * trl_qty )>= 0
) C
) D,
r5orderlines ordline, r5events e1, r5events e2
WHERE trl_order = ORL_ORDER
AND trl_order_org = ORL_ORDER_ORG
AND trl_ordline = ORL_ORDLINE
AND ordline.orl_event = e1.evt_code (+)
AND ordline.orl_relatedwo = e2.evt_code (+)
/
