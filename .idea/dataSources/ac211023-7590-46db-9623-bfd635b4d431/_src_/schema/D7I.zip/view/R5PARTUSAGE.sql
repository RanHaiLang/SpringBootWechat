CREATE VIEW R5PARTUSAGE AS SELECT
   e.evt_code,
   e.evt_jobtype,
   o.eob_obtype,
   o.eob_object,
   o.eob_object_org,
   l.trl_date,
   l.trl_part,
   l.trl_part_org,
   sum( l.trl_qty ),
   l.trl_price,
   e.evt_metuom,
   e.evt_failureusage
FROM    r5events        e,
        r5eventobjects  o,
        r5transactions  t,
        r5translines    l
WHERE   t.tra_rtype     = 'I'
AND     e.evt_code      = t.tra_tocode
AND     t.tra_code      = l.trl_trans
AND     o.eob_event     = e.evt_code
GROUP BY
   e.evt_code,
   e.evt_jobtype,
   o.eob_obtype,
   o.eob_object,
   o.eob_object_org,
   l.trl_date,
   l.trl_part,
   l.trl_part_org,
   l.trl_price,
   e.evt_metuom,
   e.evt_failureusage
UNION
SELECT
   e.evt_code,
   e.evt_jobtype,
   o.eob_obtype,
   o.eob_object,
   o.eob_object_org,
   l.trl_date,
   l.trl_part,
   l.trl_part_org,
   sum( DECODE (t.tra_rtype, 'RETN', l.trl_qty * -1, l.trl_qty)),
   l.trl_price,
   e.evt_metuom,
   e.evt_failureusage
FROM    r5events        e,
        r5eventobjects  o,
        r5transactions  t,
        r5translines    l
WHERE ( t.tra_rtype     = 'RECV' AND  t.tra_torentity = 'EVNT'   AND e.evt_code      = t.tra_tocode
    OR  t.tra_rtype     = 'RETN' AND  t.tra_fromrentity = 'EVNT' AND e.evt_code      = t.tra_fromcode )
AND     t.tra_code      = l.trl_trans
AND     o.eob_event     = e.evt_code
GROUP BY
   e.evt_code,
   e.evt_jobtype,
   o.eob_obtype,
   o.eob_object,
   o.eob_object_org,
   l.trl_date,
   l.trl_part,
   l.trl_part_org,
   l.trl_price,
   e.evt_metuom,
   e.evt_failureusage
/
