CREATE VIEW R5PERQUALIFICATIONS AS SELECT  DISTINCT p.per_code   pqu_person,
                 q.qua_code   pqu_qualification,
                 q.qua_desc   pqu_desc,
                 p.per_org    pqu_org,
                 p.per_class  pqu_class,
                 p.per_trade  pqu_trade,
                 t.trd_class  pqu_tradeclass,
                 per_mrc      pqu_mrc,
                 NULL         pqu_task,
                 0            pqu_revision
FROM
   r5tradequalifications tq,
   r5personnel p,
   r5qualifications q,
   r5trades t
WHERE  q.qua_code   = tq.trq_qualification
AND    tq.trq_trade = p.per_trade
AND    t.trd_code   = p.per_trade
AND    tq.trq_qualification NOT IN(
   SELECT pq.pqu_qualification
   FROM r5personnelqualifications pq
   WHERE p.per_code = pq.pqu_person
   AND  ( NVL( pq.pqu_tempdisqualified, '-' ) = '-'
          AND  SYSDATE <= pq.pqu_expiration ) )
UNION
SELECT  DISTINCT p.per_code     pqu_person,
                 q.qua_code     pqu_qualification,
                 q.qua_desc     pqu_desc,
                 p.per_org      pqu_org,
                 p.per_class    pqu_class,
                 p.per_trade    pqu_trade,
                 tr.trd_class   pqu_tradeclass,
                 per_mrc        pqu_mrc,
                 tskq.tqu_task  pqu_task,
                 tskq.tqu_revision  pqu_revision
FROM
   r5tradequalifications tq,
   r5personnel p,
   r5qualifications q,
   r5tasks t,
   r5taskqualifications tskq,
   r5trades tr
WHERE  q.qua_code = tskq.tqu_qualification
AND    t.tsk_trade = p.per_trade
AND    t.tsk_code = tskq.tqu_task
AND    t.tsk_revision = tskq.tqu_revision
AND    tr.trd_code = p.per_trade
AND    tskq.tqu_revision = (
   SELECT MAX( tq1.tqu_revision )
   FROM   r5taskqualifications tq1
   WHERE  tq1.tqu_task          = tskq.tqu_task
   AND    tq1.tqu_qualification = tskq.tqu_qualification
   GROUP BY tq1.tqu_task )
AND    tskq.tqu_qualification NOT IN (
   SELECT pq1.pqu_qualification
   FROM   r5personnelqualifications pq1
   WHERE  p.per_code                         = pq1.pqu_person
   AND  ( NVL(pq1.pqu_tempdisqualified, '-') = '-'
          AND  SYSDATE                      <= pq1.pqu_expiration) ) 
/
