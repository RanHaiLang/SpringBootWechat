CREATE VIEW R5PICKLISTANDPARTS AS SELECT i.pip_part,
       i.pip_part_org,
       i.pip_qty,
       l.pic_code,
       l.pic_event,
       l.pic_act,
       l.pic_object,
       l.pic_object_org,
       l.pic_required,
       l.pic_origin,
       l.pic_store,
       l.pic_printdate,
       DECODE( l.pic_printdate, NULL, '-', '+' ),
       l.pic_status,
       l.pic_rstatus,
       p.par_desc,
       p.par_uom
FROM   r5parts p,
       r5picklists l,
       r5picklistparts i
WHERE  l.pic_code     = i.pip_picklist(+)
AND    i.pip_part     = p.par_code(+)
AND    i.pip_part_org = p.par_org (+)
/
