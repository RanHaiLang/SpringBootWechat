CREATE VIEW R5PPMWINDOWS AS (
       SELECT  e.evt_code, e.evt_ppm, e.evt_ppmrev, e.evt_obtype, e.evt_object,
	         e.evt_object_org, e.evt_target, e.evt_meterdue, e.evt_jobtype,
               e.evt_status, e.evt_priority,
               DECODE(
		      GREATEST(NVL(TRUNC(e.evt_okwinend),
			       TO_DATE('01-01-1910','DD-MM-YYYY')),
		      TRUNC(SYSDATE) ),
                      TRUNC(e.evt_okwinend), '+', '-'
		     ),
               DECODE(
		      GREATEST( TRUNC(e.evt_nearwinstart), TRUNC(SYSDATE) ) -
                      LEAST(TRUNC(e.evt_genwinstart) - 1,
		      TRUNC(SYSDATE)), 0, '+', '-'
		     ),
               DECODE(
		      GREATEST( TRUNC(e.evt_genwinstart), TRUNC(SYSDATE) ),
	              TRUNC(SYSDATE), '+', '-'
		     ),
               DECODE(
		      GREATEST(NVL(e.evt_okwinendval,0), NVL(o.oud_totalusage,0)),
		      DECODE(NVL(e.evt_okwinendval,0),0,-99,e.evt_okwinendval),
                      '+', '-'
		     ),
               DECODE(
		      GREATEST(NVL(e.evt_nearwinbegval,0), NVL(o.oud_totalusage,0)) -
                      LEAST(NVL(e.evt_genwinbegval,0) - 1, NVL(o.oud_totalusage,0)),
		      0, '+', '-'
		     ),
               DECODE(
		      GREATEST(NVL(e.evt_genwinbegval,0), NVL(o.oud_totalusage,0)),
                      DECODE( NVL(o.oud_totalusage,0), 0, -99, o.oud_totalusage ),
		      '+', '-'
		     ),
               DECODE(
		      GREATEST(NVL(e.evt_okwinendval2,0), NVL(o2.oud_totalusage,0)),
		      DECODE(NVL(e.evt_okwinendval2,0),0,-99,e.evt_okwinendval2),
                      '+', '-'
		     ),
               DECODE(
		      GREATEST(NVL(e.evt_nearwinbegval2,0), NVL(o2.oud_totalusage,0)) -
                      LEAST(NVL(e.evt_genwinbegval2,0) - 1, NVL(o2.oud_totalusage,0)),
		      0, '+', '-'
		     ),
               DECODE(
		      GREATEST(NVL(e.evt_genwinbegval2,0), NVL(o2.oud_totalusage,0)),
                      DECODE( NVL(o2.oud_totalusage,0), 0, -99, o2.oud_totalusage ),
		      '+', '-'
		     )
       FROM  r5events e,
             r5objusagedefs o,
             r5objusagedefs o2
       WHERE e.evt_metuom     = o.oud_uom (+)
       AND   e.evt_object     = o.oud_object (+)
       AND   e.evt_object_org = o.oud_object_org (+)
       AND   e.evt_metuom2    = o2.oud_uom (+)
       AND   e.evt_object     = o2.oud_object (+)
       AND   e.evt_object_org = o2.oud_object_org (+)
       AND   e.evt_rstatus   <> 'C'
   )
/
