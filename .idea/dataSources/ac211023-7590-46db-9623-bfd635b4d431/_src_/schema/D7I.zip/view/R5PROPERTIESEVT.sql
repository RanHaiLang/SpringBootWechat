CREATE VIEW R5PROPERTIESEVT AS (
select a."APR_PROPERTY",a."APR_CLASS",a."APR_CLASS_ORG",a."PRO_TYPE",a."PRO_DESC",a."APR_UOM",a."PRO_CODE",a."DES_LANG",a."APR_RENTITY",a."R5_DEFORG",a."PCODE", v.PRV_VALUE, V.PRV_NVALUE, V.PRV_DVALUE
from (
SELECT   a.apr_property,
                 a.apr_class,
                 a.apr_class_org,
                 p.pro_type,
                 NVL(d.des_text, p.pro_text) pro_desc,
                 a.apr_uom,
                 p.pro_code,
		d.des_lang, a.apr_rentity,
		i.ins_desc R5_DEFORG
		,E.EVT_CODE PCODE
FROM R5INSTALL I, R5ADDPROPERTIES A , R5PROPERTIES P, R5EVENTS E,
		R5DESCRIPTIONS D
WHERE I.INS_CODE = 'DEFORG'
AND	  A.APR_RENTITY = 'EVNT'
AND	  a.apr_wodisp     = '+'
AND	  p.pro_code     = a.apr_property
AND	  d.des_rentity (+) = 'PROM'
AND	  d.des_code (+) = p.pro_code
AND	   (    ( a.apr_class = '*' AND a.apr_class_org = I.INS_DESC )   OR
              ( a.apr_class = '*' AND a.apr_class_org = E.EVT_org )    OR
              ( a.apr_class = '*' AND a.apr_class_org = E.EVT_class_org )  OR
              ( a.apr_class = E.EVT_class AND a.apr_class_org = E.EVT_class_org ) )
) A, R5PROPERTYVALUES v
where
	 (A.APR_PROPERTY = V.PRV_PROPERTY (+) AND A.APR_RENTITY = V.PRV_RENTITY (+) AND
		    A.APR_CLASS = V.PRV_CLASS (+) AND A.APR_CLASS_ORG = V.PRV_CLASS_ORG (+) AND
		    A.PCODE = V.PRV_CODE(+) )
)
/
