CREATE VIEW R5PROPERTIESOBJ AS (
SELECT A."APR_PROPERTY",A."APR_CLASS",A."APR_CLASS_ORG",A."PRO_TYPE",A."PRO_DESC",A."APR_UOM",A."PRO_CODE",A."DES_LANG",A."APR_RENTITY",A."R5_DEFORG",A."PCODE", V.PRV_VALUE, V.PRV_NVALUE, V.PRV_DVALUE
FROM (
SELECT   a.apr_property,
                 a.apr_class,
                 a.apr_class_org,
                 p.pro_type,
                 NVL(d.des_text, p.pro_text) pro_desc,
                 a.apr_uom,
                 p.pro_code,
		d.des_lang, a.apr_rentity,
		i.ins_desc R5_DEFORG,
		O.OBJ_CODE||'#'||O.OBJ_ORG PCODE
--		,V.PRV_VALUE, V.PRV_NVALUE, V.PRV_DVALUE
FROM R5OBJECTS O, R5INSTALL I, R5ADDPROPERTIES A , R5PROPERTIES P,
		R5DESCRIPTIONS D --, R5PROPERTYVALUES V
WHERE I.INS_CODE = 'DEFORG'
AND	  A.APR_RENTITY = 'OBJ'
AND	  a.apr_wodisp     = '+'
AND	  p.pro_code     = a.apr_property
AND	  d.des_rentity (+) = 'PROM'
AND	  d.des_code (+) = p.pro_code
AND	   (    ( a.apr_class = '*' AND a.apr_class_org = I.INS_DESC )   OR
              ( a.apr_class = '*' AND a.apr_class_org = O.OBJ_org )    OR
              ( a.apr_class = '*' AND a.apr_class_org = O.OBJ_class_org )  OR
              ( a.apr_class = O.OBJ_class AND a.apr_class_org = O.OBJ_class_org ) )
) A, R5PROPERTYVALUES v
where
	 (A.APR_PROPERTY = V.PRV_PROPERTY (+) AND A.APR_RENTITY = V.PRV_RENTITY (+) AND
		    A.APR_CLASS = V.PRV_CLASS (+) AND A.APR_CLASS_ORG = V.PRV_CLASS_ORG (+) AND
		    A.PCODE = V.PRV_CODE(+) )
)
/
