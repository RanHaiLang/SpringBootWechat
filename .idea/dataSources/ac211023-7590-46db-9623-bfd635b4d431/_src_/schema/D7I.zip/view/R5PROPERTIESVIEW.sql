CREATE VIEW R5PROPERTIESVIEW AS SELECT pro_code, pro_type, pro_text, MIN( apr_line )
FROM   r5addproperties,
       r5properties
WHERE  pro_code = apr_property
GROUP BY pro_code, pro_type, pro_text
/
