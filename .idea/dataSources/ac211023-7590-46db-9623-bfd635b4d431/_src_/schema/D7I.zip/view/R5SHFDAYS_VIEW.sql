CREATE VIEW R5SHFDAYS_VIEW AS SELECT shd_shift,
       shd_day,
       0,
       SUM( shd_hours )
FROM   r5shfdays
GROUP BY shd_shift, shd_day
/
