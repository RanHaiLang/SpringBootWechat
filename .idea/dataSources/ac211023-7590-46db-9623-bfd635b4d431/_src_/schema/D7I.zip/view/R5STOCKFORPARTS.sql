CREATE VIEW R5STOCKFORPARTS AS SELECT  bis_store, des_text, bis_part, bis_part_org, bis_bin, bis_lot, bis_qty, null assetid, des_lang
FROM    r5binstock, r5descriptions
WHERE   des_code = bis_store
AND     des_rentity = 'STOR'
UNION
SELECT  obj_store, des_text, obj_part, obj_part_org, obj_bin, obj_lot, 1, obj_code, des_lang
FROM    r5objects, r5descriptions
WHERE   obj_parent IS NULL
AND     des_code = obj_store
AND     des_rentity = 'STOR'
/
