CREATE VIEW R5STOCKISSUED AS SELECT SUM( l.trl_qty * l.trl_price ),
       l.trl_store
FROM   r5translines l
WHERE  l.trl_rtype = 'I'
AND    l.trl_io    = -1
AND    l.trl_date > ADD_MONTHS( sysdate, -12 )
GROUP BY l.trl_store
/
