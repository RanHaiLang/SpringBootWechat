CREATE VIEW R5TEMPREPXFERORD AS (SELECT e.ord_code, e.ord_org ,0 , 'PTORDF' , '-',
ord_store, ord_rstatus, nvl(ord_buyer,'_'), to_char(ord_date,'yyyy-mm-dd'), to_char(ord_revision), ord_printed
FROM r5orders e
UNION
SELECT ord_code, ord_org,trx_session, trx_function, '+',
ord_store, ord_rstatus, nvl(ord_buyer,'_'), to_char(ord_date,'yyyy-mm-dd'), to_char(ord_revision), ord_printed
FROM  r5temprepxfer t, r5orders e
WHERE trx_rowid = e.rowid and
trx_function = 'PTORDF'
)
/
