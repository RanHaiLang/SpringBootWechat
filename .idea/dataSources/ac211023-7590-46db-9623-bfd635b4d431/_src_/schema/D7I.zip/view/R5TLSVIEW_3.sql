CREATE VIEW R5TLSVIEW_3 AS SELECT
   DECODE(SUBSTR(r5tlsview_2.lrf_re_objcode,1,2),'##', NULL,r5tlsview_2.lrf_re_objcode) childe,
   r5tlsview_2.tls_distance distance ,
   r5tlsview_2.tls_sessionid sessionid,
   r5tlsview_1.lrf_id lrf_id,
   r5tlsview_1.lrf_objcode parente,
   r5tlsview_1.lrf_objorg parentorg,
   DECODE(SUBSTR(r5tlsview_2.lrf_re_objorg,1,2),'##', NULL,r5tlsview_2.lrf_re_objorg) childorg,
   r5tlsview_1.lrf_refrtype childreftype,
   r5tlsview_1.lrf_reftype parentreftype,
   r5tlsview_1.lrf_refdesc childdesc,
   r5tlsview_1.obj_desc parentdesc
FROM  r5tlsview_1, r5tlsview_2
WHERE r5tlsview_1.lrf_re_objcode = r5tlsview_2.lrf_re_objcode
AND   r5tlsview_1.lrf_re_objorg  = r5tlsview_2.lrf_re_objorg
AND   r5tlsview_1.tls_distance   = r5tlsview_2.tls_distance
AND   r5tlsview_1.tls_sessionid  = r5tlsview_2.tls_sessionid
AND   r5tlsview_1.lrf_id = ( SELECT MIN( lrf_id )
                             FROM  r5tlsview_1
                             WHERE r5tlsview_1.lrf_re_objcode = r5tlsview_2.lrf_re_objcode
                             AND   r5tlsview_1.lrf_re_objorg  = r5tlsview_2.lrf_re_objorg
                             AND   r5tlsview_1.tls_distance   = r5tlsview_2.tls_distance
                             AND   r5tlsview_1.tls_sessionid  = r5tlsview_2.tls_sessionid )
/
