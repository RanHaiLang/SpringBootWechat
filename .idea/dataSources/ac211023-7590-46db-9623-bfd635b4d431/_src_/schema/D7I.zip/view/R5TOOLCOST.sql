CREATE VIEW R5TOOLCOST AS SELECT
   t.tou_event
  ,NVL( SUM(  t.tou_hours ) , 0 )
  ,NVL( SUM( t.tou_cost  ), 0 )
FROM r5toolusage t
GROUP BY t.tou_event
/
