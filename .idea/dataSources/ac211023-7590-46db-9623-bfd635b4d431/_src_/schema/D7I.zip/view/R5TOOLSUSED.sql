CREATE VIEW R5TOOLSUSED AS SELECT tou_event,
       tou_act,
       tou_tool,
       SUM( tou_cost ),
       SUM( tou_tariff ),
       SUM( tou_hours * tou_qty )
FROM   r5toolusage
GROUP BY tou_event,
         tou_act,
         tou_tool
/
