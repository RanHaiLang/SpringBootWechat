CREATE VIEW R5USER_JOBS AS select job, what, this_date
from user_jobs
/
