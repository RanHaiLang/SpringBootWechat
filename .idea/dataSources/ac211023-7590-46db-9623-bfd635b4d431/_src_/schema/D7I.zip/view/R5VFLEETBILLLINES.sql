CREATE VIEW R5VFLEETBILLLINES AS SELECT fbl_bill,
       fbl_costcode,
       fbl_object,
       fbl_object_org,
       fbl_adjustment,
       fbl_fuel,
       fbl_mileage,
       fbl_usage,
       fbl_insurance,
       fbl_nonmaintenance,
       fbl_maintenance,
       fbl_exceptions,
       fbl_total
FROM   r5fleetbilllines
UNION ALL
SELECT tfb_session,
       tfb_costcode,
       tfb_object,
       tfb_object_org,
       tfb_adjustment,
       tfb_fuel,
       tfb_mileage,
       tfb_usage,
       tfb_insurance,
       tfb_nonmaintenance,
       tfb_maintenance,
       tfb_exceptions,
       tfb_total
FROM   r5tempbilllines
/
