CREATE VIEW R5VIOLATIONSVW AS SELECT
   vio_user,
   vio_password,
   TO_CHAR(VIO_DATE,'YYYY-MM-DD HH24:MI:SS') vio_date,
   vio_osuser,
   vio_osmachine
FROM
r5violations
/
