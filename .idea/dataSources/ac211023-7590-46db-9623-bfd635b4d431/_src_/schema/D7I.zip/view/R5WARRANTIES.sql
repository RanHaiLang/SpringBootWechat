CREATE VIEW R5WARRANTIES AS (
       SELECT   w.wcv_warranty,
                w.wcv_obtype,
                w.wcv_object,
                w.wcv_object_org,
                d.doc_desc,
                d.doc_supplier,
                d.doc_supplier_org,
                d.doc_warstart,
                d.doc_expir
       FROM     r5warcoverages w,
                r5documents d
       WHERE    d.doc_code     = w.wcv_warranty
   )
/
