CREATE VIEW U5SELSTOBYPART AS select
sto.sto_part,sto.sto_store, par.par_desc,par.par_uom,par.par_class,cls.cls_desc,par.PAR_UDFCHAR01,sto_qty,sto.sto_avgprice,STO_MINLEV,STO_MAXQTY,NVL(STO_MINLEV,0)-NVL(sto_qty,0) bc

from
r5stock sto
left join r5parts par on sto.sto_part=par.par_code
left join r5classes cls on par.par_class=cls.cls_code and cls.cls_entity='PART'
--where sto_store='SHWY-CK1'
/
