CREATE VIEW U5SELSTOBYPART2 AS select
sto.sto_part, par.par_desc,par.par_uom,par.par_class,cls.cls_desc,PAR_UDFCHAR01,--par.par_category,--obj.obj_desc,PAR_UDFCHAR03,
--PAR_UDFCHAR04,PAR_UDFCHAR05,PAR_UDFCHAR06,
sto.sto_store,sto.sto_qty,sto.sto_avgprice,
nvl(sto.sto_qty*sto.sto_avgprice,0) summoney,
--最近出库信息
A.tra_code ck_code,
A.tra_date ck_date,
--最近入库信息
B.tra_code rk_code,
B.tra_date rk_date
from
r5stock sto
left join r5parts par on sto.sto_part=par.par_code
left join r5classes cls on par.par_class=cls.cls_code and cls.cls_entity='PART'
left join r5objects obj  on par.par_category=obj.obj_code-- and   obj.obj_class='W000'
--最近出库信息
left join
(
select
ctx.*
from
(
SELECT
tra.TRA_CODE,  --事务代码
tra.TRA_DATE,  --事务日期
tra.tra_fromcode,
trl.trl_part,
rank() over(partition by tra_fromcode,trl_part order by TRA_DATE desc) as rowTag
FROM R5TRANSLINES TRL   ---事务行
LEFT JOIN R5TRANSACTIONS TRA ON TRA.TRA_CODE = TRL.TRL_TRANS --事务
where
tra_type = 'I'  and tra_fromcode<>tra_tocode--and tra_fromentity ='STOR' AND tra_toentity = 'EVNT' and trl_qty > 0
) ctx
where rowTag = 1
) A on A.trl_part = sto.sto_part and A.Tra_Fromcode = sto.sto_store
--最近入库信息
left join
(
select
ctx.*
from
(
SELECT
tra.TRA_CODE,  --事务代码
tra.TRA_DATE,  --事务日期
tra.tra_tocode,
trl.trl_part,
rank() over(partition by tra_tocode,trl_part order by TRA_DATE desc) as rowTag
FROM R5TRANSLINES TRL   ---事务行
LEFT JOIN R5TRANSACTIONS TRA ON TRA.TRA_CODE = TRL.TRL_TRANS --事务
where
tra_type = 'RECV' and tra_fromcode<>tra_tocode
--and tra_fromentity ='COMP' AND tra_toentity = 'STOR' and tra_dckcode is not null
) ctx
where rowTag = 1
) B on B.trl_part = sto.sto_part and B.Tra_tocode = sto.sto_store
/
