CREATE VIEW U5WRPMJH AS SELECT
		T3.OBJ_ORG,
		t2.ppm_code,
		t2.ppm_desc,
		'yibiao'  zhanwei,
		t2.ppm_meter  num1,
		t2.ppm_metuom uom,
		t1.ppo_ppm,
		t1.ppo_object,
		t3.obj_code,
		t3.obj_desc,
		t3.obj_class,
		t3.obj_category,
		t3.obj_mrc
	from
		r5ppmobjects t1,
		r5ppms  t2,
		r5objects t3
	where
		t1.ppo_ppm=t2.ppm_code
		and t1.ppo_object=t3.obj_code
		and t2.ppm_meter is  not NULL 
		--AND t1.PPO_OBJECT_ORG = T3.OBJ_ORG 
		AND T2.PPM_ORG = T1.PPO_ORG 		
union all
	SELECT
		T3.OBJ_ORG,
		t2.ppm_code,
		t2.ppm_desc,
		'riqi'  zhanwei,
		t2.ppm_freq   num1,
		t2.ppm_perioduom  uom,
		t1.ppo_ppm,
		t1.ppo_object,
		t3.obj_code,
		t3.obj_desc,
		t3.obj_class,
		t3.obj_category,
		t3.obj_mrc
	from
		r5ppmobjects t1,
		r5ppms  t2,
		r5objects t3
	where
		t1.ppo_ppm=t2.ppm_code
		and t1.ppo_object=t3.obj_code
		and t2.ppm_meter is NULL
		--AND t2.PPM_ORG = T1.PPO_ORG
		AND t1.PPO_OBJECT_ORG = T3.OBJ_ORG
/
