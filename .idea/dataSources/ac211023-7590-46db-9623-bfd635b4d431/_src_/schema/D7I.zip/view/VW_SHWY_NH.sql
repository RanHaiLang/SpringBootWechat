CREATE VIEW VW_SHWY_NH AS SELECT 
  t0.rea_date,
  SUM(DECODE(t0.rea_uom,'JWD',NVL(t0.REA_DIFF,0),0)) "JWD",--温度
  SUM(DECODE(t0.rea_uom,'JSD',NVL(t0.REA_DIFF,0),0)) "JSD",--湿度
  SUM(DECODE(t0.rea_uom,'JZDL',NVL(t0.REA_DIFF,0),0)) "JZDL",--总用电量
  SUM(DECODE(t0.rea_uom,'JZDE',NVL(t0.REA_DIFF,0),0)) "JZDE",--总用电额
  SUM(DECODE(t0.rea_uom,'JZRL',NVL(t0.REA_DIFF,0),0)) "JZRL",--总用气量
  SUM(DECODE(t0.rea_uom,'JZRE',NVL(t0.REA_DIFF,0),0)) "JZRE",--总用气额
  SUM(DECODE(t0.rea_uom,'JZSL',NVL(t0.REA_DIFF,0),0)) "JZSL",--总用水量
  SUM(DECODE(t0.rea_uom,'JZSE',NVL(t0.REA_DIFF,0),0)) "JZSE"--总用水额
FROM
  R5READINGS t0
WHERE
  t0.REA_OBJECT_ORG='SHWY'
GROUP BY
  t0.rea_date
ORDER BY
  t0.rea_date
/
