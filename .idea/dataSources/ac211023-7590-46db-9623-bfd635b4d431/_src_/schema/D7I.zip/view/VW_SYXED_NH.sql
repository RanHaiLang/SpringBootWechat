CREATE VIEW VW_SYXED_NH AS SELECT 
  t0.rea_date,
 SUM(DECODE(t0.rea_uom,'JWD',NVL(t0.REA_DIFF,0),0)) "JWD",--温度
 SUM(DECODE(t0.rea_uom,'JSD',NVL(t0.REA_DIFF,0),0)) "JSD",--湿度
 SUM(DECODE(t0.rea_uom,'JKFJ',NVL(t0.REA_DIFF,0),0)) "JKFJ",--入住房间数
 SUM(DECODE(t0.rea_uom,'JKRS',NVL(t0.REA_DIFF,0),0)) "JKRS",--入住人数
 SUM(DECODE(t0.rea_uom,'JKRL',NVL(t0.REA_DIFF,0),0)) "JKRL",--入住率
 SUM(DECODE(t0.rea_uom,'JCRS',NVL(t0.REA_DIFF,0),0)) "JCRS",--就餐人数
 SUM(DECODE(t0.rea_uom,'JLRS',NVL(t0.REA_DIFF,0),0)) "JLRS",--客人数
 SUM(DECODE(t0.rea_uom,'JKRSY',NVL(t0.REA_DIFF,0),0)) "JKRSY",--日收益
 SUM(DECODE(t0.rea_uom,'JCRSY',NVL(t0.REA_DIFF,0),0)) "JCRSY",--日收益
 SUM(DECODE(t0.rea_uom,'JKLSY',NVL(t0.REA_DIFF,0),0)) "JKLSY",--日收益
 SUM(DECODE(t0.rea_uom,'JZRSY',NVL(t0.REA_DIFF,0),0)) "JZRSY",--日收益
 SUM(DECODE(t0.rea_uom,'JZDL',NVL(t0.REA_DIFF,0),0)) "JZDL",--总用电量
 SUM(DECODE(t0.rea_uom,'JZDE',NVL(t0.REA_DIFF,0),0)) "JZDE",--总用电额
 SUM(DECODE(t0.rea_uom,'JZSL',NVL(t0.REA_DIFF,0),0)) "JZSL",--总用水量
 SUM(DECODE(t0.rea_uom,'JZSE',NVL(t0.REA_DIFF,0),0)) "JZSE",--总用水额
 SUM(DECODE(t0.rea_uom,'JZRL',NVL(t0.REA_DIFF,0),0)) "JZRL",--总用燃气量
 SUM(DECODE(t0.rea_uom,'JZRE',NVL(t0.REA_DIFF,0),0)) "JZRE",--总用燃气额
 SUM(DECODE(t0.rea_uom,'JTDL',NVL(t0.REA_DIFF,0),0)) "JTDL",--空调用电量
 SUM(DECODE(t0.rea_uom,'JSDL',NVL(t0.REA_DIFF,0),0)) "JSDL",--SPA用电量
 SUM(DECODE(t0.rea_uom,'JCDL',NVL(t0.REA_DIFF,0),0)) "JCDL",--厨房用电量
 SUM(DECODE(t0.rea_uom,'JXDL',NVL(t0.REA_DIFF,0),0)) "JXDL",--洗衣房用电量
 SUM(DECODE(t0.rea_uom,'JBDL',NVL(t0.REA_DIFF,0),0)) "JBDL",--沙滩吧用电量
 SUM(DECODE(t0.rea_uom,'JCRL',NVL(t0.REA_DIFF,0),0)) "JCRL",--餐饮
 SUM(DECODE(t0.rea_uom,'GERL',NVL(t0.REA_DIFF,0),0)) "GERL",--员工厨房
 SUM(DECODE(t0.rea_uom,'GXRL',NVL(t0.REA_DIFF,0),0)) "GXRL",--西厨房
 SUM(DECODE(t0.rea_uom,'GPRL',NVL(t0.REA_DIFF,0),0)) "GPRL",--比萨
 SUM(DECODE(t0.rea_uom,'GZRL',NVL(t0.REA_DIFF,0),0)) "GZRL",--中厨房
 SUM(DECODE(t0.rea_uom,'GSRL',NVL(t0.REA_DIFF,0),0)) "GSRL",--烧腊间
 SUM(DECODE(t0.rea_uom,'GBRL',NVL(t0.REA_DIFF,0),0)) "GBRL",--冰源
 SUM(DECODE(t0.rea_uom,'GYRL',NVL(t0.REA_DIFF,0),0)) "GYRL",--宴会
 SUM(DECODE(t0.rea_uom,'GSLS',NVL(t0.REA_DIFF,0),0)) "GSLS",--生活热水
 SUM(DECODE(t0.rea_uom,'GYLS',NVL(t0.REA_DIFF,0),0)) "GYLS",--泳池
 SUM(DECODE(t0.rea_uom,'GXLS',NVL(t0.REA_DIFF,0),0)) "GXLS",--洗衣房
 SUM(DECODE(t0.rea_uom,'GMLS',NVL(t0.REA_DIFF,0),0)) "GMLS",--马桶
 SUM(DECODE(t0.rea_uom,'GTLS',NVL(t0.REA_DIFF,0),0)) "GTLS",--冷却塔
 SUM(DECODE(t0.rea_uom,'JYDQ',NVL(t0.REA_DIFF,0),0)) "JYDQ",--用电效率
 SUM(DECODE(t0.rea_uom,'JYSQ',NVL(t0.REA_DIFF,0),0)) "JYSQ",--用水效率
 SUM(DECODE(t0.rea_uom,'JRQQ',NVL(t0.REA_DIFF,0),0)) "JRQQ",--燃气效率
 SUM(DECODE(t0.rea_uom,'JRCQL',NVL(t0.REA_DIFF,0),0)) "JRCQL"--餐饮用气效率

FROM
  R5READINGS t0
WHERE
  t0.REA_OBJECT_ORG='SYXED' 
GROUP BY
  t0.rea_date
ORDER BY
  t0.rea_date
/
